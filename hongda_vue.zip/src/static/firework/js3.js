$('.hovertree').fireworks({
    sound: true, // sound effect
    opacity: 0.9, 
    width: '100%', 
    height: '100%' 
  });