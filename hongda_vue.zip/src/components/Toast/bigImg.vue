<template>
  <div class="mask" @click="visible = false" v-if="visible">
      <i @click="visible = false" class="el-icon-close fff"></i>
      <img class="img" :src="img" alt="">
  </div>
</template>

<script>
export default {
  data() {
    return {
      img:"",
      visible:false
    }
  },
  computed: {},
  components: {},
  created() {},
  mounted() {}
};
</script>
<style lang="scss" scoped>
.mask{
  position: fixed;
  z-index: 999999999;
  left: 0;
  top: 0;
  height: 100%;
  width: 100%;
  overflow: hidden;
  background-color: rgba(0, 0, 0,0.5);
}
.img{
  position: absolute;
  left: 50%;
  top: 50%;
  transform: translate(-50%,-50%);
}
.fff {
  position: absolute;
  font-size: 30px;
  right: 100px;
  top: 100px;
  color: #fff;
}
.last{
  color: #fff;
  position: absolute;
  top: 50%;
  transform: translateY(-50%);
  left: 3%;
  font-size: 50px;
}
.next{
  color: #fff;
  position: absolute;
  top: 50%;
  transform: translateY(-50%);
  right: 3%;
  font-size: 50px;
}
.view_img_list{
  display: flex;
  color: #fff;
  position: absolute;
  left: 50%;
  transform: translateX(-50%);
  bottom: 3%;
  li{
    width: 100px;
    height: 120px;
    background-color: aquamarine;
    margin-left: 10px;
  }
}
</style>