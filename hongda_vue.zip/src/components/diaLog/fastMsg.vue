<template>
  <div class="">
    <el-dialog
      title="快捷消息"
      :visible.sync="dialogVisible"
      @close="closeFastMsg"
      center=""
      width="600px"
    >
      <div class="textarea_class">
          <el-button @click="showAddDialog" type="primary"  size="mini">添加</el-button>
        <el-table :data="tableData" style="width: 100%">
          <el-table-column label="快捷短语" width="180">
            <template slot-scope="scope">
                <p>{{ scope.row.content }}</p>
            </template>
          </el-table-column>
          <el-table-column label="操作">
            <template slot-scope="scope">
              <el-button
                size="mini"
                @click="sendFastMsg(scope.row)"
                >发送</el-button
              >
              <el-button
                size="mini"
                type="danger"
                @click="delFast(scope.row)"
                >删除</el-button
              >
            </template>
          </el-table-column>
        </el-table>
      </div>
    </el-dialog>

<!-- 添加快捷消息 -->
    <el-dialog title="添加"
               :visible.sync="showAdd"
               center
               width="300px">

        <div class="taxtar">
            <textarea class="textarea" v-model="fastMsg" id="" cols="30" rows="10"></textarea>
        </div>



      <span slot="footer"
            class="dialog-footer">
        <el-button @click="showAdd = false">取 消</el-button>
        <el-button type="primary"
                   @click="addFastMsg">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import {sendImMsgApi,getFastListgApi,addFastListgApi,delHistoryMsgApi} from "@/apis/index.js";
import { EventBus } from "@/tools/EventBus";
export default {
  data() {
    return {
      dialogVisible: true,
      showAdd:false,
      fastMsg: "",
       tableData: []
    };
  },
  computed: {},
  methods: {
    closeFastMsg() {
      this.$emit("closeFastMsg");
    },
    async sendFastMsg (item) {
            let content = item.content// 发送的内容
            if (!content) return this.$toast('内容不能为空')
 
                        let msgData = {
              content,
              msg_type: 1,
              send_nickname: this.userInfo.nick_name,
              send_uid: this.userInfo.id,
              is_read:0
            }
            this.$store.commit('addHistoryMsg',msgData)
            this.$store.commit('topChatList',this.chatInfo)
            EventBus.$emit('updateHistoryMsgScroll')

                       let reqdata = {
              friend_id:this.chatInfo.id,
              content,
              msg_type : 1,
            }
           const {data:res} = await sendImMsgApi (reqdata)
      this.$emit("closeFastMsg");
           if (res.code !=200) return this.$toast(res.msg)


    },
    async addFastMsg () {
        let reqdata = {
            content: this.fastMsg
        }
        const {data:res} = await addFastListgApi(reqdata)
        if (res.code == 200) {
            this.showAdd = false
            this.getFastList()
        }
    },
    showAddDialog () {
        this.showAdd = true
    },
    delFast (item) {
        let reqdata= {
            id :item.id
        }
       delHistoryMsgApi(reqdata).then(({data:res})=>{
           if (res.code == 200) this.getFastList()
       })
    },
    getFastList () {
        getFastListgApi().then( ({data:res})=>{
            this.tableData = res.data
      } )
    }
  },
  components: {},
  created() {
    this.getFastList()
  },
  mounted() {},
};
</script>
<style lang="scss" scoped>
.textarea_class {
  width: 100%;
  padding: 20px;
  textarea {
    outline: none;
    padding: 5px;
  }
}
.taxtar{
      width: 100%;
  padding: 20px;
    textarea {
    outline: none;
    padding: 5px;
  }
}
</style>