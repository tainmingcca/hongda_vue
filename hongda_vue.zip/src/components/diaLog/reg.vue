<template>
    <div style="position: absolute;top: 15vh;width:100%;">
        <div
            id="regForm"
            style="display: block; z-index: 2"
            class="layer_pageContent"
        >
            <div class="reg_title">
                用户注册
                <i
                    class="el-icon-close close_btn"
                    @click="$emit('closeReg')"
                ></i>
            </div>
            <div style="padding: 15px 0" >
                <table class="reg_table" border="0" cellspacing="0" cellpadding="0">
                    <tbody>
                        <tr>
                            <td align="right">登陆账户：</td>
                            <td>
                                <input v-model="regForm.user_name" type="text" class="input val" required />&nbsp;<span style="color: red">必填</span>
                            </td>
                        </tr>
                        <tr>
                            <td align="right">个人昵称：</td>
                            <td>
                                <input v-model="regForm.nick_name" type="text" class="input val" required />&nbsp;
								<span style="color: red">必填</span>
                            </td>
                        </tr>
                        <tr>
                            <td align="right">手机号：</td>
                            <td>
                                <input v-model="regForm.mobile" type="text" class="input val" required/>&nbsp;
								<span style="color: red">必填</span>
                            </td>
                        </tr>
                        <tr>
                            <td align="right">QQ ：</td>
                            <td>
                                <input v-model="regForm.user_qq" type="text" class="input val" required/>&nbsp;
								<span style="color: red">必填</span>
                            </td>
                        </tr>
                        <tr>
                            <td align="right">登录密码：</td>
                            <td>
                                <input v-model="regForm.passwd" type="password" class="input val" required/>&nbsp;
								<span style="color: red">必填</span>
                            </td>
                        </tr>
                        <tr>
                            <td align="right">确认密码：</td>
                            <td>
                                <input v-model="regForm.repasswd" type="password" class="input val" required/>&nbsp;
								<span style="color: red">必填</span>
                            </td>
                        </tr>
                        <tr>
                            <td align="right">邀请码：</td>
                            <td>
                                <input v-model="regForm.invitation" type="password" class="input val" required/>&nbsp;
								<span style="color: red">选填</span>
                            </td>
                        </tr>

                        <tr>
                            <td colspan="2" style="text-align: center">
                                <div @click="regCount" style="width: 200px; margin-left: 80px" class="btn_input us_input">提交</div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
		     <reg-red @click.native="showregres = true" @closeRegRed="showRegRedDialog = false" v-if="showRegRedDialog"></reg-red>
		     <redResult :invitation_url="invlink" :money="money"  v-if="showregres" @close="showregres = false" />
    </div>
</template>


<script>
import { regApi } from "@/apis/index.js";
import RegRed from '@/components/diaLog/regred.vue'
export default {
    data() {
        return {
            regForm: {
                user_name: "",
                nick_name: "",
                passwd: "",
                repasswd: "",
				invitation:"",
                mobile: "",
                user_qq: "",
            },
			showRegRedDialog:false, // 注册成功展示红包
			showregres:false, // 注册红包
			money:"", // 红包金额
			invlink:"" ,//邀请链接
            lock: false,
        };
    },
	    components: {
	         RegRed,
	         redResult: () => import("@/components/diaLog/redResult.vue"),
	    },
    methods: {

        async regCount() {
            // for (const key in this.regForm) {
            //     if (!this.regForm[key]) return this.$toast("请输入完整信息");
            // }
            let reqdata = this.regForm;
            this.lock = true;
            const { data: res } = await regApi(reqdata);
            this.lock = false;
            // this.$emit("closeReg");

            if (res.code == 200) {
				let reaData = {
					isReload:false,
					token: res.data
					
				}
				this.$store.commit("addUserToken", reaData);
                this.$toast(res.msg);
				this.invlink = res.invitation
				this.money = res.money
				this.showRegRedDialog  = true
            } else {
                return this.$toast(res.msg);
            }
        },
    },
	mounted() {
		      this.regForm.invitation = this.$route.query.invitation
	}
};
</script>



<style lang="scss" scoped>
.layer_pageContent {
    background-color: #fff;
}
.reg_table {
    border-collapse: collapse;
    border-spacing: 0;
    width: 450px;
    margin: 0 auto;
}
.reg_title {
    font-size: 18px;
    text-align: center;
    // background-color: rgb(55, 0, 255);
    padding: 10px 0;
    position: relative;
    cursor: move;
}
.close_btn {
    position: absolute;
    right: 10px;
    top: 10px;
    cursor: pointer !important;
}
</style>