<template>
    <div style="position: absolute; top: 15vh; width: 100%">
        <div class="us_mian">
            <div class="clse_box">
                <i class="el-icon-close close_btn" @click="$emit('closeLogin')"></i>
            </div>
            <div class="us_mian_title">用户登录</div>
            <ul
                class="us_con"
                style="width: 100%; cursor: default !important"
            >
                <li style="width: 250px">
                    <input
                        v-model="loginForm.user_name"
                        type="text"
                        placeholder="帐号"
                        style="width: 250px; margin: 20px 0 0 70px"
                        class="text_input us_input val"
                    />
                </li>
                <li style="width: 250px">
                    <input
                        v-model="loginForm.passwd"
                        type="password"
                        placeholder="密码"
                        style="width: 250px; margin: 10px 0 0 70px"
                        class="text_input us_input val"
                    />
                </li>
                <li style="width: 250px; height: 48px">
                    <div
                        @click="login"
                        class="btn_input us_input"
                        style="
                            text-align: center;
                            cursor: pointer;
                            margin-left: 70px;
                        "
                    >
                        登 录
                    </div>
                </li>
            </ul>
        </div>
    </div>
</template>

<script>
import { loginApi } from "@/apis/index.js";
export default {
    data() {
        return {
            loginForm: {
                user_name: "",
                passwd: "",
            },
        };
    },
    methods: {
        async login() {
            for (const key in this.loginForm) {
                if (!this.loginForm[key]) return this.$toast("请输入完整信息");
            }
            const { data: res } = await loginApi(this.loginForm);
            if (res.code == 200) {
				let  resData = {
					token: res.data,
					isReload:true
				}
                this.$store.commit("addUserToken", resData);
                this.$emit("closeLogin");
            } else {
                this.$toast(res.msg);
            }
        },
    },
};
</script>


<style lang="scss" scoped>
.us_mian {
  margin:0 auto;
    z-index: 99;
    .us_mian_title {
        font-size: 18px;
        border-bottom: 1px solid #f0f0f0;
        text-align: center;
        padding-bottom: 15px;
    }
    cursor: move;
}
.clse_box{
    position: relative;
}
.close_btn {
    position: absolute;
    font-size: 25px;
    cursor: pointer;
    color: #000;
    right: 20px;
    top: -20px;
}
</style>