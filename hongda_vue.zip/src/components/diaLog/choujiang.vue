<template>
    <div class="">
        <el-dialog
            center=""
            :visible.sync="dialogVisible"
            @close="closeChouJiang"
            custom-class=" noheader"
            :show-close="false"
            top="80px"
            width="320px"
        >

        <img src="@/assets/img/mh2.gif" alt="" height="600px" @click="showLoading">

        <div v-loading ="isloading" v-if="isloading"     element-loading-text="抽奖中..." class="loading"> </div>
        </el-dialog>
    </div>
</template>

<script>
import { MessageBox } from "element-ui";
export default {
    data() {
        return {
            dialogVisible: true,
            isloading:false
        };
    },
    computed: {},
    methods: {
        closeChouJiang() {
            this.$emit("closeChouJiang");
        },
        showLoading () {
            this.isloading = true
            setTimeout(()=>{
                this.isloading = false
                            MessageBox.confirm(
                "恭喜您，抽奖成功，请立即联系在线助理查看奖品！",
                "温馨提示",
                {
                    confirmButtonText: "确定",
                    cancelButtonText: "取消",
                    type: "success",
                }
            )
                .then(() => {
                    this.$emit("closeChouJiang");
                })
                .catch(() => {});
            },3000)
        }

    },
    components: {},
    created() {
    },
    mounted() {},
};
</script>
<style lang="scss" scoped>
.loading {
    position: absolute;
    left: 50%;
    transform: translateX(-50%);
    top: 50%;
    background-color: #fff;
    width: 150px;
    height: 150px;
    display: flex;
    justify-content: center;
    align-items: center;
}
</style>