<template>
  <div class="">
      <el-dialog custom-class="noheader" :visible.sync="dialogVisible" :close-on-click-modal="false" @close="closeRegRed" center top="80px" width="350px">
           <img src="../../assets/img/regred.gif" alt="" style="width:350px;">
      </el-dialog>
  </div>
</template>

<script>
import { Alert, MessageBox } from "element-ui";
export default {
  data() {
    return {
            dialogVisible:true,

    };
  },

  computed: {},
  methods: {
      closeRegRed () {
          this.$emit('closeRegRed')
      },
    
  },
  components: {},

  mounted() {}
};
</script>
<style lang="scss" scoped>
.tac {
  text-align: center;
}
::v-deep.el-dialog{width:750px;}
::v-deep.el-dialog__header{padding: 15px 0;}
</style>