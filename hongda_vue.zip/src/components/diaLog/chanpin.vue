<template>
  <div >
      <el-dialog title="产品介绍" center :visible.sync="dialogVisible" @close="closeChanPin" width="1020px" top="80px">
          <iframe class="productIdrem" scrolling="auto" :src="url" frameborder="0"></iframe>
      </el-dialog>
  </div>
</template>

<script>
import {getNavApi} from '@/apis/index.js'
export default {
  data() {
    return {
            dialogVisible:true,
            url:"",
    };
  },
  computed: {},
  methods: {
      closeChanPin () {
          this.$emit('closeChanPin')
      }
  },
  components: {},
  async created() {
    let reqdata = {
      type:"product"
    }
    const {data:res} = await getNavApi (reqdata)
    this.url = res.data.url
  }
};
</script>
<style lang="scss" scoped>
.productIdrem {
    width: 100%;
  height: 547px;
}
 
</style>