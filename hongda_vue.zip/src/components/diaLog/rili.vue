<template>
  <div class="">
      <el-dialog title="财经日历"
                  center
                 :visible.sync="dialogVisible"
                 @close="closeRiLi"
                 width="800px" top="80px">

         <iframe scrolling="auto" :src="url" frameborder="0"></iframe>

      </el-dialog>
  </div>
</template>

<script>
import {getNavApi} from '@/apis/index.js'
export default {
  data() {
    return {
            dialogVisible:true,
            url:""
    };
  },
  computed: {},
  methods: {
      closeRiLi () {
          this.$emit('closeRiLi')
      }
  },
  components: {},
  async created() {
    let reqdata = {
      type:"caijing"
    }
    const {data:res} = await getNavApi(reqdata)
    this.url = res.data.url
  },
  mounted() {}
};
</script>
<style lang="scss" scoped>
::v-deep.el-dialog__header{padding: 15px 0;}
iframe{
  width: 100%;
  height: 600px;
}
</style>