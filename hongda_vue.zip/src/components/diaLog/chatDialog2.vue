<template>

<div class="drag-box flex_box" v-drag :class="isMax?'maxClass':'minClass'" ref="chatListWidth" id="drag" >
<div class="chatList"  @mousedown="returnDefault($event)"  > 
    <input type="text" class="seachInput" placeholder="搜索" v-model="searchText" @input="filterChat">
    <div  class="chat_box " :style="{height: isMax ? chatListHeight2 : chatListHeight}">
      <!-- item.friend_id==chatInfo.id ?'chat_current':'' -->
    <!-- <div v-for="(item, index) in 3000" :key="index"> -->
              <div class="chat_item" :class="chatInfo.id == item.id?'chat_current':''" v-for="(item, index) in filterChatList" :key="index" @click="changeChatList(item)">
            <el-badge :value="item.noReadCount" :hidden="item.noReadCount == 0" :max="99"><img :class="item.is_online == 0 ? 'grayImg' : ''" :src="item.head_img" alt="" ></el-badge>
            <div class="chat_item_info">
              <div class="nickname">{{item.nick_name}}</div>
              <div class="last_msg">{{item.sign}}</div>
            </div>
        </div>
    <!-- </div> -->
    </div>


</div>
<div :class="isMax?'widthBox100':'widthBox'" >
  <div v-if="chatInfo.id">
        <div class="header" id="dragBox"  @mousedown="isMove($event)">
      <img :src="chatInfo.head_img" alt="">
      <div class="nick_name">{{chatInfo.nick_name}} <br>  <span style="color : green; font-size: 14px;font-weight: 400;">{{chatInfo.sign ? chatInfo.sign : '1.32.251.255 中国香港 香港移动'}}</span> </div>
      <img class="poab1" style="height:20px;width:20px; cursor:pointer;"  @click="$store.commit('getIsShowChat',false)" src="@/assets/fontPng/min.png" alt="">
    </div>
    <div  @mousedown="returnDefault($event)" @scroll="loadMoerMsg($event)" id="list" class="chat_main chatContent" :class="isMax?'':'chat_main_min'" ref="scrollContant" >
            <div v-for="(item, index) in historylist" :key="index"  class="pore" :class="item.send_uid == userInfo.id?' my_msg_detail ':' msg_detail   '">
            <img :src="item.send_uid != userInfo.id ? item.send_headimg  : userInfo.head_img" width="40px" height="40px" style="border-radius: 50%;">
            <!-- 文本 -->
              <div class="nick_name_class" :class="item.send_uid == userInfo.id?' my_poab_nick_name ':'   poab_nick_name'" ><span>{{item.create_time}}</span> {{item.send_nickname}} </div>
              <div  v-html="item.content.replace(/\#[\u4E00-\u9FA5]{1,3}\;/gi, emotion)" v-if="item.msg_type == 1" class="text_body"></div>
            <!-- /文本 -->

            <!-- 图片 -->
            <div v-if="item.msg_type == 2" class="image_body">
                <el-image  @click="$bigImg(item.content)"  fit="scale-down" :src="item.content" @load="scrollBottom"></el-image>
            </div>
            <!-- /图片 -->

            <!-- 已读 未读 -->
            <div class="read_box" v-show="item.send_uid == userInfo.id">
                <span :class="item.send_uid != userInfo.id?' other_style':' my_style'"  class="wzdu_item" v-if="item.is_read== 0">未读</span>
                <span :class="item.send_uid != userInfo.id?' other_style':' my_style'"  class="yidu_item"  v-else>已读</span>
            </div>
            <!-- 已读 未读 -->


        </div>
    </div>
    <div  @mousedown="returnDefault($event)" class="chat_footer">
      <div class="sendToll">
            <i @click="isShowFace = !isShowFace" class="iconfont icon-biaoqing chat_icon_tooll"></i>
        <el-upload  :auto-upload="false" action="" :on-change="fileAdress" :show-file-list="false" accept="image/gif,image/jpeg,image/jpg,image/png">
            <i class="iconfont icon-tupian chat_icon_tooll"></i>
        </el-upload>
        <i v-if="userInfo.user_type == 1"  @click="showWelcomeDialog = true" class="iconfont icon-huanyingye chat_icon_tooll"></i>
          <i @click="addFastMsg" class="iconfont icon-xiaoxi chat_icon_tooll" v-if="userInfo.user_type == 1"></i>
        <div class="poab_qq_face" v-show="isShowFace">
          <img class="imgBox" @click="closeqqFace(item.alt)" v-for="(item, index) in qqFaceList.emojiList" :key="index" :src="item.url" alt=""/>
        </div>
      </div>
      <div class="send_input_class" @paste="getPritContend($event)" id="sendImInput" @keydown.enter.exact="sendMsg($event)"  ref="sendTextArea" contenteditable="true" style=""></div>
      <el-button class="poab" style="mini" plain @click="sendMsg($event)" :loading="sendLoading" >发 送</el-button>
    </div>
  </div>
  <div class="select_friend_box" v-else>
    <img @mousedown="returnDefault($event)" :src="roomInfo.index_dialog_img" alt="">
    <i  @click="$store.commit('getIsShowChat',false)" class="el-icon-close clseo_btn"></i>
  </div>
</div>

<welcomeDiagLog v-if="showWelcomeDialog" @closeWelcome="showWelcomeDialog = false" />
<fastMsg v-if="showFastMsgDialog" @closeFastMsg="closeFastMsgs" />
</div>


</template>

<script>
import emojiList from "@/assets/js/emjoy";
import {sendImMsgApi,getHistoryMsgApi,getOssApi } from '@/apis/index'

import { EventBus } from "@/tools/EventBus";
EventBus.$on("updateHistoryMsgScroll", () => {
  setTimeout(() => {
    let scroll = document.getElementById("list");
    try {
      scroll.scrollTop = scroll.scrollHeight;
    } catch (error) {}
  }, 13);
});
export default {
	data(){
		return {
      isShowFace:false,
      searchText:"",
      flag:true,
      qqFaceList:emojiList,
      chatListHeight:"", // 常规高度
      chatListHeight2:"", // 加长高度
      isMax:false,
      sendLoading:false,
      showWelcomeDialog:false,
      showFastMsgDialog:false,
		}
	},
  methods: {
    addFastMsg () {
      this.showFastMsgDialog = true
    },
    closeFastMsgs () {
      this.showFastMsgDialog = false
    },
    returnDefault (e) {
      e.stopPropagation()
      // e.preventDefault()
    },
    async getPritContend (e) {
            const cbd = e.clipboardData;
      const ua = window.navigator.userAgent;
      if (!(e.clipboardData && e.clipboardData.items)) return;
      if ( cbd.items && cbd.items.length === 2 && cbd.items[0].kind === "string" && cbd.items[1].kind === "file" && cbd.types && cbd.types.length === 2 && cbd.types[0] === "text/plain" && cbd.types[1] === "Files" && ua.match(/Macintosh/i) && Number(ua.match(/Chrome\/(\d{2})/i)[1]) < 49) return
      for (let i = 0; i < cbd.items.length; i++) {
        let item = cbd.items[i];
        if (item.kind == "file") {
          if (this.userInfo.user_type == 2) {
          e.preventDefault()
            return false
          }
          const blob = item.getAsFile();
      // const {data:res} = await getOssApi ('im')
          const formData = new FormData()
          // formData.append("policy", res.data.policy);
          // formData.append("OSSAccessKeyid", res.data.accessid);
          // formData.append("signature", res.data.signature);
          // formData.append("success_action_status", 200);
          // formData.append("key", res.data.dir + blob.lastModified+blob.name);
          formData.append("file", blob);
          formData.append("dir", 'im');
          document.getElementById('sendImInput').innerHTML = ""
          const {data:res} =   await  this.$upload.post('/upload', formData)
      let content = res.data.src
             let reqdata = {
              friend_id:this.chatInfo.id,
              content,
              msg_type : 2
            }
         await sendImMsgApi (reqdata)
          let msgData = {
              content,
              msg_type: 2,
              send_nickname: this.userInfo.nick_name,
              send_uid: this.userInfo.id,
              is_read:'0'
            }
        this.$store.commit('addHistoryMsg',msgData)
        this.$store.commit('topChatList',this.chatInfo)
        this.$nextTick(()=>{
            this.$refs.scrollContant.scrollTop = this.$refs.scrollContant.scrollHeight;
           document.getElementById('sendImInput').innerHTML = ""

        })
        }
      }
    },
   async fileAdress (file) {
      let content = await this.getOssSrc(file,'im')
             let reqdata = {
              friend_id:this.chatInfo.id,
              content,
              msg_type : 2
            }
           const {data:res2} = await sendImMsgApi (reqdata)
            let msgData = {
              content,
              msg_type: 2,
              send_nickname: this.userInfo.nick_name,
              send_uid: this.userInfo.id,
              is_read:'0'
            }
          this.$store.commit('addHistoryMsg',msgData)
            this.$store.commit('topChatList',this.chatInfo)
        this.$nextTick(()=>{
        this.$refs.scrollContant.scrollTop = this.$refs.scrollContant.scrollHeight;
        })
    },
          closeqqFace (item) {
            this.isShowFace = false
            this.$refs.sendTextArea.innerHTML += item;
          },
          filterChat () {
              console.log( this.filterChatList);
          },
          async changeChatList (item) {
            if (item.id == this.chatInfo.id) return
            this.$store.commit('getChatInfo',item)
            this.$store.dispatch('getHistoryMsgApi',item)
          },
          async sendMsg (event) {
            event.cancelBubble=true;
            event.preventDefault();
            event.stopPropagation();
            let content = this.$refs.sendTextArea.innerText// 发送的内容
            if (!content) return this.$toast('内容不能为空')
     
            this.$refs.sendTextArea.innerHTML= ""
            let msgData = {
              content,
              msg_type: 1,
              send_nickname: this.userInfo.nick_name,
              send_uid: this.userInfo.id,
              is_read:0
            }
            this.$store.commit('addHistoryMsg',msgData)
              let reqdata = {
              friend_id:this.chatInfo.id,
              content,
              msg_type : 1
            }
           const {data:res} = await sendImMsgApi (reqdata)
            if (res.code !=200) return this.$toast(res.msg)
            this.$store.commit('topChatList',this.chatInfo)
            this.$refs.sendTextArea.innerText= ""
            this.$nextTick(()=>{
                  this.$refs.scrollContant.scrollTop = this.$refs.scrollContant.scrollHeight;
              })
          },
          autoHeight () {
            this.isMax = !this.isMax
            this.$nextTick (()=>{
            let height =  this.$refs.chatListWidth.clientHeight - 58 + 'px'
            if (!this.chatListHeight2) {
              this.chatListHeight2  = height
            }
            if (this.isMax) {
              this.$refs.chatListWidth.style.left = 0
              this.$refs.chatListWidth.style.top = 0
            }
            }) 
          },
       async loadMoerMsg (e) {
           if (this.historylist.length == 0) return false
            let scrollTop =  e.target.scrollTop
            if (scrollTop == 0){
            let reqdata= {
                friend_id: this.chatInfo.id,
                last_time:this.historylist[0].last_time
            }
            if (!this.flag) return false
            this.flag = true
            const {data:res} =  await getHistoryMsgApi(reqdata)

            if (res.code != 200) return this.$toast(res.msg)
                if (res.data.length == 0) {
                    this.flag = false
                    // this.recordLoading = false
                }else{
                 let hst = e.target.scrollHeight;
                this.$store.commit('mergeHistTotyList',res.data.reverse())
                this.$nextTick(()=>{
                    e.target.scrollTop = e.target.scrollHeight - hst
                })
                }
     
            
            } 
        },
        scrollBottom () {
                this.$refs.scrollContant.scrollTop = this.$refs.scrollContant.scrollHeight;
                this.$nextTick(()=>{
                this.$refs.scrollContant.scrollTop = this.$refs.scrollContant.scrollHeight;
                })
        },
        isMove (e) {
          if (this.isMax) {
                e.stopPropagation()
          }else {
            return false
          }
        },
        // 测试发送时候回车问题
        testSend (e) {
          console.log();
        }
  },
  components:{
        welcomeDiagLog: ()=>import('@/components/diaLog/welcomeDiagLog.vue'),
        fastMsg: ()=>import('@/components/diaLog/fastMsg.vue')
  },
  computed: {

        filterChatList () {
          if (this.chatFriendList.length == 0) return []
          let onlineArr = [] // 在线的人
          let offlineArr = [] // 不在线的人
          let chatList = [] // 合并在线和不在线的人
          let arr = [] // 搜索到的人
          this.chatFriendList.forEach(item => {
            if (item.is_online == 1 || item.noReadCount > 0) {
              onlineArr.push(item)
            }else{
              offlineArr.push(item)
            }
          });
          chatList = onlineArr.concat(offlineArr)
          chatList.filter(item =>{
            if (item.nick_name.includes(this.searchText)){
                    arr.push(item)
            }
          })
                if (arr.length > 0) {
                return arr
            }else{
                return this.chatFriendList
            }
        }
  },

  mounted () {
      try {
                this.$refs.scrollContant.scrollTop = this.$refs.scrollContant.scrollHeight;
                this.$nextTick(()=>{
        this.$refs.scrollContant.scrollTop = this.$refs.scrollContant.scrollHeight;
        })
      } catch (error) {
        
      }
        this.chatListHeight = '550px'

  },
}

</script>

<style lang="scss" scoped>
.drag-box {
    border-radius: 5px;
    box-shadow: 0 4px 12px rgba(0,0,0,.15);
    z-index: 9999;
}
.clseo_btn {
  position: absolute;
  right: 20px;
  top: 20px;
  font-size: 25px;
  color: red;
}
.minClass{
  	position:absolute;
	top: 100px;
  left: 25%;
  // transform: translateX(-50%);
 	width:950px;
}
.maxClass {
    width: 100%;
    left: 0;
    top: 0;
    z-index: 9999;
    position: absolute;
}
.widthBox100 {
  width: 100%;  
}

.header{
  height: 80px;
  width: 100%;
  background-color: #f8f8f8;
  display: flex;
  padding: 15px;
  position: relative;
  cursor: move;
  img {
    width: 50px;
    height: 50px;
    border-radius: 50%;
  }
}
.chat_main{
  width: 100%;
  position: relative;
}

.chat_main_min {
  height: 350px;
}
.chatContent{
    box-sizing: border-box;
    padding: 20px;
    overflow: auto;
    background-color: #fff;
  //  文本css
    .text_body{
      background-color:#5FB878;
      color: #fff;
      max-width: 70%;
      border-radius: 5px;
      padding: 5px 10px;
      font-size: 14px;
      margin: 15px 10px;
      word-break: break-all;
      white-space: pre-wrap;
    }
  // 图片css
  .image_body {
      max-width: 100px;
      max-height: 300px;
      min-width: 20px;
      background-color: #f7f6fc;
      margin: 20px 10px;
  .el-image,
  img {
      max-width: 100px;
      max-height: 300px;
  }
  }
  // 语音css

    .msg_detail{
        display: flex;
    }
    .my_msg_detail{
      display: flex;
      flex-flow: row-reverse;
    }

}
.read_box{
    display: flex;
}
.chat_footer{
  height: 178px;
  background-color: #FFFFFF;
  position: relative;
}

.nick_name{
  line-height: 25px;
  margin-left: 10px;
  color: #000;
}
    .seachInput{
      border: none;
      outline: none;
      width: 298px;
      height: 25px;
      padding-left: 10px;
      background-color: #F8F8F8;
    }
.poab1{
  position: absolute;
  top: 20px;
  right: 25px;
}
.poab2{
  position: absolute;
  top: 10px;
  right: 20px;
}
.sendToll{
  background: #fff;
  border-top: 1px solid #f1f1f1;
  box-sizing: border-box;
  padding:10px 0 0 0;
  position: relative;
  display: flex;
}
.flex_box{
  display: flex;
  z-index: 9999;
  .widthBox{
    border-left: 1px solid #cccccc;
    width: 100%;
    }
  .chatList{
    width: 320px;
    background-color: #fff;
    box-sizing: border-box;
    padding: 10px;
  }
  .chat_box{
    font-size: 14px;
    height: 550px;
    margin-top: 10px;
    overflow: auto;
    cursor: pointer;
  }
}
.chat_current{
    background-color: #F7F8FC;
}
.chat_item{
    display: flex;
    margin: 10px 0;
    width: 100%;
    position: relative;
    img{
        width: 50px;
        height: 50px;
        margin-left: 10px;
    }
    .chat_item_info{
        margin-left: 10px;
        margin-top: 5px;
        .nickname{
            color: #000;
            width: 130px;
            white-space: nowrap;
            text-overflow: ellipsis;
            overflow: hidden;
            word-break: break-all;
        }
    }
    .chat_item_time{
    margin: 20px 10px 0 auto;
  color: #000;
    }
}
.chat_item:hover{
    background-color: #F7F8FC;
}
.last_msg{
  width: 130px;
  white-space: nowrap;
  text-overflow: ellipsis;
  overflow: hidden;
  word-break: break-all;
  color: #000;
}
.poab{
  position: absolute;
right: 14px;
    bottom: 5px;
}
.poab_qq_face{
  position: absolute;
  width: 360px;
  height: 150px;
  left: 18px;
  top: -146px;
  overflow: auto;
  background-color: #fff;
}
.grayImg {
filter: grayscale(100%);
filter: gray;
}
.select_friend_box {
  background-color: #fff;
  position: relative;
  width: 100%;
  height: 100%;
  color: #000;
  display: flex;
  text-align: center;
  img {
    margin-top:65px;
      width: 100%;
      height: 100%;
      opacity: .1;
  }
}
.pore {
  position: relative;
}
.poab_nick_name{
    color: #000;
    position: absolute;
    left: 56px;
    top: -11px;
    display: flex;
    align-items: center;
    flex-direction: row-reverse;
    span{
      margin-left: 20px;
    }
}
.my_poab_nick_name{
    color: #000;
    position: absolute;
    right: 56px;
    top: -11px;
}
.wzdu_item{
    color:#ee3888!important;
        display: flex;
    align-items: center;
}
.yidu_item{
    color:#35CEAB!important;
    display: flex;
    align-items: center;
}
.chat_icon_tooll{
  display: inline-block;
  margin-left: 20px;
  color: #666;
  font-size: 18px;
}
.send_input_class{
  white-space:normal;
  word-break:break-all;
  word-wrap: break-word;
  width: 100%;height: 105px;
  resize:none;
  padding:15px;
  border:none;
  background: #fff;
  outline:none;
  color:#000;
  overflow:auto;
}
.nick_name_class{
  font-size: 12px;
  color: #999999;
  span{
    display: inline-block;
    margin-right: 20px;
  }
}
</style>