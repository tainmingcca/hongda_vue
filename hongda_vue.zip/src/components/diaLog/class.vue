<template>
  <div class="">
      <el-dialog title="课程安排" :visible.sync="dialogVisible" @close="closeClass" center top="80px">
         <div  class="tac" >
           <img :src="url" alt="" style="width:100%;">
         </div>
      </el-dialog>
  </div>
</template>

<script>
import {getNavApi} from '@/apis/index.js'
export default {
  data() {
    return {
            dialogVisible:true,
            url:""
    };
  },
  computed: {},
  methods: {
      closeClass () {
          this.$emit('closeClass')
      }
  },
  components: {},
  async created() {
    let rqddata = {
      type: 'kcb'
    }
    const {data:res} = await getNavApi(rqddata)
    this.url = res.data.url
    console.log(res);
  },
  mounted() {}
};
</script>
<style lang="scss" scoped>
.tac {
  text-align: center;
}
::v-deep.el-dialog{width:750px;}
::v-deep.el-dialog__header{padding: 15px 0;}
</style>