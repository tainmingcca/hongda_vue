<template>
  <div class="">
      <el-dialog title="默认欢迎语"
                 :visible.sync="dialogVisible"
                 @close="closeWelcome"
                 center=""
                 width="300px">
         

           <div class="textarea_class">
                <textarea v-model="welMsg" name="" id="" cols="30" rows="10"></textarea>
           </div>

        <span slot="footer"
              class="dialog-footer">
          <el-button @click="closeWelcome">取 消</el-button>
          <el-button type="primary"
                     @click="setWel">确 定</el-button>
        </span>
      </el-dialog>
  </div>
</template>

<script>
import  {getWelcomeMsgApi,setWelcomeMsgApi} from '@/apis/index.js'
export default {
  data() {
    return {
      dialogVisible:true,
      welMsg:""
    };
  },
  computed: {},
  methods: {
      closeWelcome () {
          this.$emit('closeWelcome')
      },
      setWel () {
          let reqdata= {
              content:this.welMsg
          }
          setWelcomeMsgApi(reqdata).then(({data:res})=>{
              if (res.code == 200) {
                      this.$emit('closeWelcome')
              }
              this.$toast(res.msg)
          })
      }
  },
  components: {},
  created() {
      getWelcomeMsgApi().then(({data:res})=>{
          this.welMsg = res.data
      }) 
  },
  mounted() {}
};
</script>
<style lang="scss" scoped>
.textarea_class{
    width: 100%;
    padding: 20px;
    textarea {
        outline: none;
        padding: 5px;
    }
}
</style>