<template>
    <div class="">
        <el-dialog
            title="名师风采"
            center=""
            :visible.sync="dialogVisible"
            @close="closeTeacher"
            width="800px"
            top="80px"
        >
            <el-tabs type="card" @tab-click="handleClick">
                <el-tab-pane
                    :label="item.nick_name"
                    v-for="(item, index) in teacherList"
                    :key="index"
                >
                    <section class="teacher_box">
                        <div class="teach_image">
                            <img :src="item.head_img" alt="" />
                            <div @click="dianZan(item)" class="dianzan">
                                小伙伴点赞【{{ item.zan_nums }}】次
                            </div>
                        </div>
                        <div class="teacher_info">
                            <div class="teacher_item">
                                <span>名师名称：</span>
                                <span>{{ item.nick_name }}</span>
                            </div>
                            <div class="teacher_item">
                                <span>交易理念：</span>
                                <span>{{ item.jyln }}</span>
                            </div>
                            <div class="teacher_item">
                                <span>从业经历：</span>
                                <span>{{ item.cyjl }}</span>
                            </div>
                            <div class="teacher_item">
                                <span>擅长品种：</span>
                                <span> {{ item.scpz }} </span>
                            </div>
                            <div class="teacher_item">
                                <span>特色课件：</span>
                                <span>{{ item.tskj }}</span>
                            </div>
                        </div>
                    </section>
                </el-tab-pane>
            </el-tabs>

            <!-- <el-tabs v-model="activeName" type="card" @tab-click="handleClick">
    <el-tab-pane label="用户管理" name="first">用户管理</el-tab-pane>
    <el-tab-pane label="配置管理" name="second">配置管理</el-tab-pane>
    <el-tab-pane label="角色管理" name="third">角色管理</el-tab-pane>
    <el-tab-pane label="定时任务补偿" name="fourth">定时任务补偿</el-tab-pane>
  </el-tabs> -->
        </el-dialog>
    </div>
</template>

<script>
import { getTeacherListApi, zanTeacherApi } from "@/apis/index";
export default {
    data() {
        return {
            dialogVisible: true,
            activeName: "1",
            teacherList: [],
            reqLock: false,
        };
    },
    computed: {},
    methods: {
        closeTeacher() {
            this.$emit("closeTeacher");
        },
        handleClick(tab) {
            console.log(this.activeName);
            console.log(tab);
        },
        async dianZan(item) {
            let reqdata = { id: item.id };
            if (this.reqLock) return;
            this.reqLock = true;
            const { data: res } = await zanTeacherApi(reqdata);
            this.reqLock = false;
            if (res.code == 200) {
                item.zan_nums = item.zan_nums + 1;
            }
            this.$toast(res.msg);
        },
    },
    components: {},
    async created() {
        const { data: res } = await getTeacherListApi();
        this.teacherList = res.data;
    },
    mounted() {},
};
</script>
<style lang="scss" scoped>
::v-deep.el-dialog__header{padding: 15px 0;}
.teacher_box {
    display: flex;
    padding:0 10px 10px;
    .teach_image {
        width: 40%;
        margin-right: 10px;
        img {
            width: 100%;
            height: 400px;
        }
        .dianzan {
            height: 50px;
            text-align: center;
            line-height: 50px;
            color: red;
            background-color: #a2d0fc;
            margin: 5px 0;
            margin-right: 0;
            border-radius: 5px;
            cursor: pointer;
        }
    }
    .teacher_info {
        width: 60%;
        .teacher_item {
            line-height: 35px;
            margin: 10px 0;
        }
        .teacher_item span:first-child {
            width: 70px;
            color: #000;
            font-weight: 700;
        }
    }
}
</style>