<template>
    <div class="">
        <el-dialog @close="closeIndex" :visible.sync="dialogVisible">
            <img width="100%" :src="roomInfo.index_dialog_img" alt="" />
        </el-dialog>
    </div>
</template>

<script>
export default {
    data() {
        return {
            dialogVisible: true,
        };
    },
    computed: {},
    methods: {
        closeIndex() {
            this.$emit("closeIndex");
        },
    },
    components: {},
    created() {},
    mounted() {},
};
</script>
<style lang="scss" scoped>
::v-deep.el-dialog{width: 740px;}
::v-deep .el-dialog__header {
    padding: 0;
}
</style>