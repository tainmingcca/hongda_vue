<template>
    <div class="">
        <el-dialog custom-class="noheader" :visible.sync="dialogVisible" @close="closeTimeEnd" center top="200px" width="850px">
            <img src="@/assets/img/time.png" width="850" alt="">
        </el-dialog>
    </div>
  </template>
  
  <script>
  export default {
    data() {
      return {
              dialogVisible:true,
      };
    },
    computed: {},
    methods: {
        closeTimeEnd () {
            this.$emit('closeTimeEnd')
        },

   
    },
    components: {},
  
    mounted() {}
  };
  </script>
  <style lang="scss" scoped>

  
  </style>