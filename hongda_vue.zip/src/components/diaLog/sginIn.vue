<template>
  <el-dialog custom-class="qd_dialog" :show-close="false" center="" :visible.sync="dialogVisible" @close="$emit('closeSignIn')" width="1050px" top="80px">
          <div class="qiandao-warp">
        <div class="qiandap-box">
            <div class="qiandao-con clear">
                <div class="qiandao-left">
                    <div class="qiandao-left-top clear">
                        <!-- <div class="current-date">2016年1月6日</div> -->
                        <div class="qiandao-history qiandao-tran qiandao-radius" id="js-qiandao-history"></div>
                    </div>
                    <div class="qiandao-main" id="js-qiandao-main">
                        <ul class="qiandao-list" id="js-qiandao-list">
                            <!-- 555 -->
                            <!--  -->
                            <li :class="qdArr.find(it=>it==item) ? ['date' + item ,'qiandao'] :'date' + item" v-for="item in dayTimes" :key="item">
                                <div class="qiandao-icon"></div>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="qiandao-right pore">
                    <div class="poab">{{toadyTime}}</div>
                    <div class="qiandao-top">
                        <div class="qd_btn" @click="qianDao" >立即签到</div>
                    </div>
                    <div class="qiandao-bottom" >
                        <div style="margin-top:40px;" class="qiandao-rule-list">
                            <h4>签到规则</h4>
                            <p>1)用户登录签到即可获得10积分,1元现金奖励;</p>
                            <p>2)每天连续签到更会额外获得10积分,10元现金奖励</p>
                        </div>
                        <div class="qiandao-rule-list">
                            <h4>其他说明</h4>
                            <p>1)如果中间有一天间断未签到的,重先开始计算连续签到时间;</p>
                            <p>2)获得的奖励可投资后转让变现。</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    <div class="qiandao-layer qiandao-active" v-if="qdSuccess">
        <div class="qiandao-layer-con qiandao-radius">
            <a @click="qdSuccess=false" class="close-qiandao-layer qiandao-sprits"></a>
            <div class="yiqiandao clear">
                <div class="yiqiandao-icon qiandao-sprits"></div>
            </div>
            <div class="qiandao-jiangli qiandao-sprits">
                <span class="qiandao-jiangli-num"> {{getQdMoney}} <em>积分</em></span>
            </div>
        </div>
        <div class="qiandao-layer-bg"></div>
    </div>
    </div>

  </el-dialog>
</template>

<script>
import {  userSignApi,getSignListApi } from "@/apis/index";
export default {
  data() {
    return {
      dialogVisible: true,
      qdSuccess:false, // 签到成功弹窗
      qdArr:[],//用户已签到月份
      getQdMoney:"",
    };
  },
  computed: {
       dayTimes (){
        let data=new Date(new Date().getFullYear(),new Date().getMonth() + 1,0);
        let day=data.getDate();
        return day;
    },
    toadyTime () {
        const date = new Date();
        const year = date.getFullYear(); // 年
        const month = date.getMonth() + 1; //月
        const day = date.getDate(); // 日
        return year + '-'  + month + '-' + day
    }
 
  },
  methods: {
     async qianDao () {
         const {data:res} = await userSignApi()
         if (res.code ==200) {
             this.qdSuccess = true
             this.getQdMoney = res.data.money
            this.$store.dispatch('getUserInfo')
            this.getSignList()
         }else {
         this.$toast(res.msg)
         }
      },
      async getSignList () {
          const {data:res} = await getSignListApi()
        if (res.data.length > 0) {
            res.data.forEach(item => {
              this.qdArr.push(item.day)
          });
        }
      }
  },
  components: {},
  created() {
    this.getSignList()
  },
  mounted() {},
};
</script>
<style lang="scss" scoped>
::v-deep.el-dialog__header {
  padding-top: 0!important;
}
.qd_btn {
    background-color: #FFEB42;
    color: #B25D06;
    font-size: 18px;
    font-weight: 700;
    padding: 0 10px;
    text-align: center;
    height: 50px;
    margin-top: 30px;
    line-height: 50px;
    margin-bottom: 40px;
    cursor: pointer;
}
.pore {
    position: relative;
    .poab {
        position: absolute;
        left: 90px;
        top: 20px;
        font-size: 18px;
        color: #fff;
        
    }
}
</style>