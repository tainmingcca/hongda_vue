<template>
  <div class="">
    <el-dialog :visible.sync="dialogVisible" title="扫码观看手机直播" @close="closeMobile" width="300px">
      <div class="qr_code" ref="qrCodeUrl"></div>
    </el-dialog>
  </div>
</template>

<script>
import QRCode from 'qrcodejs2'
export default {
  data() {
    return {
      dialogVisible: true,
    };
  },
  computed: {},
  methods: {
    closeMobile() {
      this.$emit("closeMobile");
    },
    creatQrCode () {
          var qrcode = new QRCode(this.$refs.qrCodeUrl, {
      text: window.location.href,
      width: 280,
      height: 280,
      colorDark: '#000000',
      colorLight: '#ffffff',
      correctLevel: QRCode.CorrectLevel.H
 })
 console.log(qrcode);
    }
  },
  components: {},
  created() {},
  mounted() {
      this.$nextTick(()=>{
            console.log(this.$refs.qrCodeUrl);
       this.creatQrCode();
      })
  },
};
</script>
<style lang="scss" scoped>
.qr_code{
    width: 300px;
    height: 300px;
    // background-color: blue;
    padding: 10px;
}
::v-deep.el-dialog__header{padding: 15px 0;}
::v-deep .el-dialog__title {
    display: flex;
    margin-left: 70px;
  }
</style>