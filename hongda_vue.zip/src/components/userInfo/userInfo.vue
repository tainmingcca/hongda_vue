<template>
    <div class="userInfo">
        <div class="user_info_title">
            用户中心
            <i class="el-icon-close poab_user_close" @click="colseUserInfo"></i>
        </div>

        <div class="user_info_info">
            <div class="user_info_heaerImg">
                <img src="/static/default/head_img.png" alt="" />
            </div>
            <div class="user_info_detail">
                <div>账号: {{ userInfo.user_name }}</div>
                <div>昵称: {{ userInfo.nick_name }}</div>
                <div>积分: {{ userInfo.jifen }}</div>
                <div>邀请码: {{ userInfo.invitation }}</div>
                <div>
                    <span @click="showPwdDiaog">修改密码</span> |<span
                        @click="showInfoCener"
                        >个人资料</span
                    >
                   
                </div>
								<el-button size="small" class="poab_logout_btn" @click="showred" type="danger" >邀请红包</el-button>

                <el-button
                    size="small"
                    class="poab_logout_btn"
                    @click="logoutUser"
                    type="warning"
                    >退出登录</el-button
                >
            </div>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {};
    },
    computed: {},
    methods: {
        colseUserInfo() {
            this.$emit("closeUserInfo");
        },
        logoutUser() {
            this.$store.dispatch("logOutApi");
            this.$toast("退出成功");
        },
        showPwdDiaog() {
            this.$emit("closeUserInfo");
            this.$emit("showChangePwd");
        },
        showInfoCener() {
            this.$emit("closeUserInfo");
            this.$emit("showInfoCener");
        },
        goAdminCenter() {
            window.open(`/admin/Login/index/${this.token}`);
        },
		showred () {
			this.$emit("showregred");
			this.$emit("closeUserInfo");
		}
    },
    components: {},
    created() {},
    mounted() {},
};
</script>
<style lang="scss" scoped>
.userInfo {
    width: 500px;
    height: 340px;
    background-color: #fff;
}
.user_info_title {
    padding: 10px 0;
    border-bottom: 1px solid #f0f0f0;
    text-align: center;
    line-height: 30px;
    position: relative;
    .poab_user_close {
        position: absolute;
        right: 10px;
        top: 15px;
        font-size: 20px;
    }
}

.user_info_info {
    background: url("../../assets/img/center.jpg") no-repeat;
    height: calc(300px - 30px);
    display: flex;
    .user_info_heaerImg {
        width: 100px;
        display: flex;
        align-items: center;
        img {
            width: 40px;
            margin-left: 30px;
            margin-bottom: 80px;
        }
    }
    .user_info_detail {
        margin-left: 100px;
        margin-top: 30px;
        position: relative;
        .poab_logout_btn {
        }
    }
    .user_info_detail div {
        margin-bottom: 30px;
        span {
            cursor: pointer;
        }
    }
}
</style>