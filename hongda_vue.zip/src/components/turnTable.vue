<template>
  <div class="LuckyWheel_bg">
    <LuckyWheel
      class="zhuna_pai"
      width="524px"
      height="524px"
      :blocks="blocks"
      :prizes="prizes"
      :fonts="fonts.text"
      @start="startCallBack"
      @end="endCallBack"
      :buttons="buttons"
      ref="myLucky"
    />
    <span @click="$emit('closeTurnTable')" class="el-icon-close prze_close"></span>

  <div class="tzck" v-if ="isZhongJinag" >
    <ul  >
        <span @click="isZhongJinag = false" class="tzck_close">X</span>
        <h1 id="jx_1">恭喜您获得{{prizeInfo.prize}}</h1>
        <li>请核对您的信息:</li>
        <li><font id="jx_2" class="message">用户名：{{prizeInfo.info.nick_name}}</font></li>
        <li :title=" 'QQ:' +prizeInfo.info.user_qq?prizeInfo.info.user_qq:'暂无' "><font id="jx_3" class="message">手机号：{{prizeInfo.info.mobile?prizeInfo.info.mobile:'暂无'}}   QQ：{{prizeInfo.info.user_qq?prizeInfo.info.user_qq:'暂无'}}</font></li>
        <li><font id="jx_5" class="message">中奖时间：{{prizeInfo.info.create_time}}</font></li>
        <li><font class="message">领奖方法：</font>
        <a @click="$store.dispatch('getQQApi')" style="color:red;font-weight:600;cursor:pointer;">点击我 </a>将中奖截图发给客服
        </li>
    </ul>
</div>

  <div class="zhong_jiang_list">
    <vue-seamless-scroll :class-option="optionSingleHeight" :data="listData" class="seamless-warp">
        <ul class="item">
            <li v-for="(item,index) in listData" :key="index">
                <span class="title" v-text="item.nick_name"></span> 抽到 <span class="date" v-text="item.prize"></span>
            </li>
        </ul>
    </vue-seamless-scroll>

  </div>
    <div class="tips">
      温馨提醒： 每个会员可获得一次抽奖机会，奖品将在三个工作日之内发放,中奖后发送手机号和中奖截图给客服,请务必保持手机畅通，方便工作人员核实信息发放奖品。
    </div>
  </div>
</template>

<script>
import { getTurnTableInfoApi, luckDrawApi } from "@/apis/index";
import vueSeamlessScroll from 'vue-seamless-scroll'
export default {
  data() {
    return {
      isZhongJinag:false,

      blocks: [
        {
          imgs: [
            {
              src: "",
              width: "100%",
              rotate: true,
            },
          ],
        },
      ],

      buttons: [
        {
          radius: "50%",
          imgs: [
            {
              src: require("../assets/img/z.png"),
              width: "127px",
              top: "-70px",
            },
          ],
        },
      ],


      prizes: [
        { title: "0" },
        { title: "1" },
        { title: "2" },
        { title: "3" },
        { title: "4" },
        { title: "5" },
        { title: "6" },
        { title: "7" },
        { title: "8" },
        { title: "9" },
        { title: "10" },
        { title: "11" },
      ],
      fonts:[

      ],
      prizeInfo:{},
	  domAudio:null,
      listData: []
    };
  },
  computed: {
    optionSingleHeight () {
      return {
                singleHeight: 26
              }
    }
  },
  methods: {
    async getTurnTableInfo() {
      const { data: res } = await getTurnTableInfoApi();
      if (res.code == 201) return this.$toast(res.msg);
      this.listData = res.data.prizeList
      
      this.blocks[0].imgs[0].src = res.data.turntableInfo.bg_img;
    },
    // 开始转
    async startCallBack() {
      this.$refs.myLucky.init();
      const { data: res } = await luckDrawApi();
      if (res.code !== 200) return this.$toast(res.msg);
      this.$refs.myLucky.play();
      setTimeout((_) => {
        this.$refs.myLucky.stop(res.data.index);
        this.prizeInfo = res.data
        if (res.data.index == -1 ) {
              this.currStatus = 0;
              this.isZhongJinag = true
        }
      }, 2500);
    },
    endCallBack() {
        this.currStatus = 0;
        this.isZhongJinag = true

    },
  },
  components: {
    vueSeamlessScroll
  },
  created() {this.getTurnTableInfo();},
    mounted() {
    	const  audio = document.createElement("AUDIO");
  	this.domAudio = audio
  	audio.src =  require('../assets/audio/zhuanpan.mp3')
  	audio.play()
    },
    beforeDestroy() {
    	this.domAudio.pause()
    }

};
</script>
<style lang="scss" scoped>
.LuckyWheel_bg {
  width: 1000px;
  background: url('../assets/img/s3_bg.png');
}
.prze_close {
  position: absolute;
  right: 50px;
  top: 0;
  font-size: 28px;
  color: red;
  background-color: #fff;
  border-radius: 50%;
}
.zhong_jiang_list{
    position: absolute;
    right: 153px;
    bottom: 111px;
    width: 300px;
    color: #fff;
    text-align: center;
    .seamless-warp{
      width: 100%;
      height: 133px;
      overflow: hidden;
      ul li {
        line-height: 30px;
      }
    }
}
.tips{
    position: absolute;
    bottom: 45px;
    right: 75px;
    color: #fff;
    width: 450px;
    text-indent: 2em;
}
.tzck,.tzck1{position:fixed;width:400px;background:#fff;border:8px solid #f60;top:39%;left:0;right:0;margin:0 auto;text-align:center;height:260px;border-radius:15px;z-index:3}
.tzck h1,.tzck1 h1{margin:15px auto;font:30px "Microsoft Yahei";text-align:center;color:#f60;font-weight:bold;width:380px}
.tzck span,.tzck1 span{position:absolute;right:-10px;height:30px;background:#F60;line-height:23px;width:30px;text-align:center;top:-20px;border:5px solid #fff;border-radius:30px;color:#fff;cursor:pointer}
.tzck li{width:330px;float:left;font-style:normal;list-style:none;height:30px;line-height:30px;text-align:left;padding-left:2em;font:16px "Microsoft Yahei" ; white-space: nowrap;
    text-overflow: ellipsis;overflow: hidden;}
.tzck li .message{color:#f60}

</style>