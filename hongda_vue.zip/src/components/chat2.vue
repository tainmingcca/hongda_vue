<template>
    <div>
        <div id="topic" ref="rightChatBox">
            <div class="notice flex_toll_bar" v-if="bodyWidth > 800">
                <marquee direction="left" id="notice" scrollamount="3">{{ userData.notice}}</marquee>
                <div class="tool_bar" style="background: none; min-width: 138px">
                    <a @click="clearCHatMsg" id="bt_qingping" class="bar_4 bar" >清屏</a>
                    <a @click="changeScroll" id="bt_gundong" class="bar_5 bar" :class="isScroll ? 'bar_true' : ''" >滚动</a >
                </div>
         

            </div>

            <!-- 移动端状态栏 -->
            <div class="m_header" v-if="$store.state.clientType == 'app'" style="padding: 5px 10px">
                <table>
                    <tbody>
                        <tr>
                            <td v-if="userInfo.admin_uid" @click="lianxiKeFu" style="width: 50%; text-align: left"> 
                                
                                <span v-if="!mobileChat">【在线客服】</span>
                                <span v-else><i class="el-icon-arrow-left mobile_icon"></i> </span>
                            
                            </td>
                            <td v-if=" !utoken && $store.state.clientType == 'app' " @click="isShowLogin = true" id="login"> <div class="cfg">登 录</div></td>
                            <td v-if=" !utoken && $store.state.clientType == 'app' " @click="isShowReg = true" id="reg">  <div class="cfg" style="background-color: #f34a1e" >注 册</div></td>
                            <td v-if=" utoken && $store.state.clientType == 'app' " @click="logOut" id="reg"> <div class="cfg" style=" background-color: #f34a1e; width: 100px;"> 退出</div></td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <!-- 移动端状态栏 -->

            <!-- 互动容器 -->
            <div v-if="!mobileChat" @scroll="closeBox()" @click="closeOtherBox" class="chat_conent" id="hd_list" ref="rightChat" :style="{ background: mobileChat ? '#eeeeee' : 'rgba(0, 0, 0, 0.3)',flex: 'auto'}">
                <!-- 互动聊天 -->
                <div id="topicbox" @contextmenu.prevent="rightClick($event, item)" v-for="(item, index) in hdMsgList" :key="index">
                    <div class="talk">
                        <div class="talk_time"> {{ item.send_time }}</div>
                        <img class="roleimg" :src="item.group_icon" alt="" />
                        <span class="talk_name">
                            <span v-if=" userInfo.user_type == 1 && item.admin_nickname != '' " style="color: red; font-weight: 700" >【{{ item.admin_nickname }}】</span>
                            {{ item.nick_name }}
                            <span v-if="userInfo.user_type == 1" :class="item.admin_nickname ? 'whiteCss' : 'redCss' " >({{ item.ip }})</span>
                            <span class="redCss" v-if=" item.status == 0 && userInfo.user_type == 1 ">(待审核)</span>
                        </span>
                        <div v-if="item.is_bao == 0" @click="viewImg(item.content)" v-html=" item.content.replace(/\#[\u4E00-\u9FA5]{1,3}\;/gi,emotion ) " :class="item.is_red == 1 ? 'redCss' : ''" class="talk_content"></div>
                        <!-- <div v-if="item.is_system == 1"  class="talk_content redCss"> {{item.content}} </div> -->
                        <redBao v-if="item.is_bao == 1 " @click.native="openRedResust(item)" :item="item" :class="item.is_red == 1 ? 'redCss' : ''" class="talk_content"  />
                        <div class="clearfix"></div>
                    </div>
                </div>
                <!-- 互动聊天 -->
            </div>

            <!-- 移动端客服聊天 -->
            <div v-if="mobileChat" @scroll="loadMoreKefuMsg($event)" @click="closeOtherBox" id="appScroll" class="chat_conent chat_main chatContent chat_main_min" ref="mobileChat" :style="{ background: mobileChat ? '#eeeeee' : 'rgba(0, 0, 0, 0.3)', flex: 'auto'}">
                <div class="pore" v-for="(item, index) in historylist" :key="index" :class="item.send_uid == userInfo.id ? ' my_msg_detail ' : ' msg_detail  ' ">
                    <img :src=" item.send_uid != userInfo.id ? item.send_headimg : userInfo.head_img" width="40px" height="40px" style="border-radius: 50%" />
                    <!-- 文本 -->
                 <div class="nick_name_class" :class="item.send_uid == userInfo.id?' my_poab_nick_name ':'   poab_nick_name'" ><span>{{item.create_time}}</span> {{item.send_nickname}} </div>
                    <div v-html=" item.content.replace(/\#[\u4E00-\u9FA5]{1,3}\;/gi,emotion) " v-if="item.msg_type == 1" class="text_body"></div>
                    <!-- /文本 -->
                    <!-- 图片 -->
                    <div v-if="item.msg_type == 2" class="image_body"> <el-image fit="scale-down" :src="item.content" @load="scrollBottom"></el-image></div>
                    <div class="read_box" v-show="item.send_uid == userInfo.id">
                        <span :class=" item.send_uid != userInfo.id ? ' other_style' : ' my_style' " class="wzdu_item" v-if="item.is_read == 0" >未读</span>
                        <span :class=" item.send_uid != userInfo.id ? ' other_style' : ' my_style' " class="yidu_item" v-else >已读</span >
                    </div>
                    <!-- /图片 -->
                </div>
                <!-- /移动端客服聊天 -->
            </div>
            <!-- /互动容器 -->

            <!-- 这里是PC端底部聊天 -->
            <div class="chatFooter pore" v-if="!mobileChat">
                <div id="warnmsg">
                    <div @click="getQQ" class="jnpai_zhuli">
                    <img src="@/assets/img/kf1.gif" alt="">
                    </div>
                    <div @click="getQQ" class="jnpai_zhuli">
                    <img src="@/assets/img/kf2.gif" alt="">
                        <!-- <i class="iconfont icon-qq"></i> -->
                        <!-- <span>策略体验</span> -->
                    </div>
                    <div @click="getQQ" class="jnpai_zhuli">
                    <img src="@/assets/img/kf4.gif" alt="">
                        <!-- <i class="iconfont icon-qq"></i> -->
                        <!-- <span>预约战队</span> -->
                    </div>
                    <div @click="getQQ" class="jnpai_zhuli">
                    <img src="@/assets/img/kf5.gif" alt="">

                        <!-- <i class="iconfont icon-qq"></i> -->
                        <!-- <span>联系老师</span> -->
                    </div>
                </div>
                <div id="topicinput">
                    <div class="tool_bar bg_color">
                        <div class="bar_left">
                            <i @click="isShowqqFace = !isShowqqFace" class="iconfont icon-biaoqing" ></i>
                            <i @click="isShowcalTiao = !isShowcalTiao" class="iconfont icon-taiyang_sun61"></i>
                            <el-upload v-if="userInfo.user_type == 1" :auto-upload="false" action="" :on-change="fileAdress" :show-file-list="false" accept="image/gif,image/jpeg,image/jpg,image/png" >
                                <i class="iconfont icon-tupian"></i>
                            </el-upload>
							
						 <img   @click="showAudio = true" style="cursor: pointer;" height="32" v-if="userInfo.user_type == 1" src="@/assets/img/audio.png" alt="">

							
                            <!-- 表情 -->
                            <div class="qqFace" v-show="isShowqqFace">
                                <img class="imgBox" @click="closeqqFace(item.alt)" v-for="( item, index ) in qqFaceList.emojiList" :key="index" :src="item.url" alt="" />
                            </div>
                            <!-- 彩条 -->
                            <div class="ption_a" v-show="isShowcalTiao">
                                <dl style="padding-top: 10px" id="c_pt">
                                    <dd style=" text-align: center; padding-bottom: 10px; " @click="closeCaiTiao(item)" v-for="(item, index) in praiseList" :key="index" >
                                        <img :src="item" />
                                    </dd>
                                </dl>
                            </div>
                        </div>
                        <div class="bar_right" v-if="userInfo.user_type == 1">
                            <select name="robot" id="robot" @change="getRobot">
                                <option :value="0">当前登录账户</option>
                                <option v-for="(item, index) in robotList" :key="index" :value="item.id" >
                                    {{ item.nick_name }} ( {{item.group_name}} )
                                </option>
                            </select>
                            <div class="danmu_btn" style="color: #fff" name="danmu"> <input type="checkbox" @click="setDanMu" :checked="isDanmu" /> 弹幕
                            </div>
                        </div>
                    </div>
                    <div class="input_area bg_color">
                        <div id="sendMsgInput" @paste="getPritContend($event)" @keydown.enter="sendMsg($event)" ref="inputBody" contenteditable="true" class="content1" placeholder="请输入您的持仓代码并说明问题，立即参与到众多投资者的交流中..." ></div>
                        <a class="sub_btn" @click="sendMsg($event)">发送</a>
                    </div>
                </div>
            </div>
            <!-- 这里是PC端底部聊天 -->

            <!-- 这里是移动端底部聊天 -->
            <div v-if="mobileChat" class="chatFooter_mobile">
                <div class="flex_input">
                    <input @keyup.enter="sendMobileMsg" ref="mobileBbody" type="text" />
                    <el-button @click="sendMobileMsg" type="primary"> 发送 </el-button>
                </div>
                <div class="icon_box">
                    <div @click="isShowqqFace = !isShowqqFace"><i class="iconfont icon-biaoqing"></i> </div>
                    <el-upload :auto-upload="false" action="" :on-change="fileAdress2" :show-file-list="false" accept="image/gif,image/jpeg,image/jpg,image/png" >
                        <i class="iconfont icon-tupian"></i>
                    </el-upload>
                    <div class="appqqFace" v-show="isShowqqFace">
                        <img class="imgBox" @click="getFaceByApp(item.alt)" v-for="(item, index) in qqFaceList.emojiList" :key="index" :src="item.url" alt=""/>
                    </div>
                </div>
            </div>
            <!--/ 这里是移动端底部聊天 -->
        </div>

        <ul  v-show="menuVisible" class="menu">
            <li @click="atUser" class="contextmenu__item" name="aite">
                @该用户
            </li>
            <li @click="jinYanUser" class="contextmenu__item" name="jinyan">
                禁言该用户
            </li>
            <li @click="pingbiUser" class="contextmenu__item" name="pingb">
                屏蔽该用户IP
            </li>
            <li @click="delMsg" class="contextmenu__item" name="del">
                删除此消息
            </li>
            <li @click="passMsg" class="contextmenu__item" name="pass">
                通过此消息
            </li>
        </ul>
        <transition name="bounce"
            ><login v-if="isShowLogin" @closeLogin="isShowLogin = false"
        /></transition>
        <transition name="bounce"
            ><reg v-if="isShowReg" @closeReg="isShowReg = false"
        /></transition>
        <transition name="bounce">
            <redDialog v-if="showRedDialog" @openSendRed="showSendRed = true;showRedDialog = false"  @openMyred="showMyRedDialog = true;showRedDialog = false" @closeRed="showRedDialog = false" />
        </transition>
        <transition name="bounce">
            <myRed v-if="showMyRedDialog"  @closeMyRed="showMyRedDialog = false" />
        </transition>
        <transition name="bounce">
            <sendRed v-if="showSendRed" @closeSendRed="showSendRed = false" />
        </transition>
        <transition name="bounce">
            <getRed :redBagData="redBagData" @closeGetRed ="showGetRed = false" v-if="showGetRed"  />
        </transition>

        <el-dialog  :visible.sync="robotdialog" width="240px" top="80px">
            <section class="center_robot">
                <div class="title">请选择领取机器人</div>
                <div @click="tipChange(item.nick_name,item.id)" class="center_robot_list" v-for="(item, index) in robotList" :key="index">
                    <span>{{item.nick_name}}</span>
                    <span>({{item.group_name}})</span>
                </div>
            </section>
        </el-dialog>

        <AudioBox v-if="showAudio" @closeAudio="showAudio=false" />

    </div>
</template>

<script>
import emojiList from "@/assets/js/emjoy";

import {  MessageBox } from "element-ui";
import {
    sendHdMsgApi,
    getOssApi,
    contextMenuApi,
    sendImMsgApi,
    getHistoryMsgApi,
    shouRedBaoApi,
    sendBalloonApi
} from "@/apis/index.js";
import { EventBus } from "@/tools/EventBus";
EventBus.$on("updateHdMsgScroll", () => {
    setTimeout(() => {
        let scroll = document.getElementById("hd_list");
        try {
            scroll.scrollTop = scroll.scrollHeight;
        } catch (error) {}
    }, 13);
});
EventBus.$on("updateHistoryMsgScrollByApp", () => {
    setTimeout(() => {
        let scroll = document.getElementById("appScroll");
        try {
            scroll.scrollTop = scroll.scrollHeight;
        } catch (error) {}
    }, 13);
});
export default {
    data() {
        return {
            isShowcalTiao: false, // 彩条
            isShowqqFace: false, // QQ表情
            isShowKehu: true, //在线客服
            menuVisible: false, //右键菜单
            hdMsgInfo: new Object(), // 点击右键获取的消息
            qqFaceList: emojiList, // QQ表情
            isShowLogin: false, // 登录
            isShowReg: false, // 注册
            robotId: 0, // 是不是机器人
            isDanmu: 0, // 发送类型是否为弹幕
            srcByOss: "", // oss
            flag: true, // 滚动方式多次出发加载历史消息
            showRedDialog:false, // 红包dialog,
            showMyRedDialog:false , // 我的红包弹窗
            showSendRed:false, // 发送红包弹窗
            showGetRed:false, // 抢红包弹窗
            redBagData:new Object,// 消息详情
            robotdialog:false, // 选择机器人弹窗
            robot_id:"",// 领取红包的机器人id
            red_id:"", // 红包id
			showAudio:false,
        };
    },
    computed: {
        praiseList() {
            let arr = [];
            for (var i = 1; i < 7; i++) {
                arr.push(require(`@/assets/img/praise/1.${i}.gif`));
            }
            return arr;
        },
    },
    methods: {

        tipChange (robot,id) {
            MessageBox.confirm(
                `确认选择 ${robot} 领取红包吗`,
                "温馨提示",
                {
                    confirmButtonText: "确定",
                    cancelButtonText: "取消",
                    type: "warning",
                }
            )
                .then(async() => {
                    this.robot_id = id;
                    this.robotdialog = false
            let readata = {id:this.red_id,robot_id:this.robot_id}
            const {data:res} = await shouRedBaoApi(readata)
            this.getRedMethods(res)
                })
                .catch(() => {});
        },
       async openRedResust (item) {
// console.log(this.userInfo.isYk);
        //    return
        if (this.userInfo.isYk) return this.$emit('openLogin')
        let readata = {id:item.id,robot_id:this.robot_id}
        if (this.userInfo.user_type == 1) {
            // 弹窗选择机器人 
            this.red_id = item.id
            this.robotdialog = true
        }else {
            const {data:res} = await shouRedBaoApi(readata)
            this.getRedMethods(res)
        }
     
        },

        getRedMethods(res) {
       if (res.code == 200) {
                this.redBagData.money = res.data
                this.redBagData.id = res.id
                this.redBagData.code = 200
                this.showGetRed = true
                this.$store.dispatch('getUserInfo')
            }else if (res.code == 201) {
                this.redBagData.money = res.data
                this.redBagData.id = res.id
                this.redBagData.code = 201
                this.showGetRed = true
            }else if (res.code == 202) {
                this.redBagData.id = res.data
                this.redBagData.code = 202
                this.showGetRed = true
            }
        },

    openRedDialog () {
        if (this.userInfo.isYk) return this.$emit('openLogin')
        if (this.userInfo.jifen < 0) return this.$toast('积分不足')
         this.showRedDialog = true 
    },

    viewImg (str) {
      try {
        let srcReg = /src=[\'\"]?([^\'\"]*)[\'\"]?/i // 匹配图片中的src
        let src = str.match(srcReg)
        this.$bigImg(src[1])
      } catch (error) {
        console.log(error);          
      }
  },
        logOut() {
            this.$store.dispatch("logOutApi");
        },
        closeBox() {
            this.closeOtherBox();
        },
        // 获取QQ
        async getQQ() {
          this.$store.dispatch("getQQApi");
        },
        lianxiKeFu() {
            if (this.mobileChat) {
                this.$store.commit("showMobileChat", false);
            } else {
                let reqdata = {
                    id: this.userInfo.admin_uid,
                    last_time: "",
                };
                console.log(reqdata);
                this.$store.dispatch("getHistoryMsgApi", reqdata);
                this.$store.commit("showMobileChat", true);
            }
        },
        // @ 功能
        atUser() {
            let font = document.createElement("font");
			font.style.color = "#00A8E4";
            font.style.fontWeight = 700;
            font.innerHTML = `对【${this.hdMsgInfo.nick_name}】 说:`;
            document.getElementById("sendMsgInput").innerHTML = "";
            document.getElementById("sendMsgInput").append(font);
        },
        // 删除消息
         delMsg() {
            this.$store.dispatch("delMsg", this.hdMsgInfo);
        },
        async jinYanUser() {
            let reqdata = {
                type: "jinyan",
                id: this.hdMsgInfo.id,
            };
            const { data: res } = await contextMenuApi(reqdata);
            this.$toast(res.msg);
        },
        async pingbiUser() {
            let reqdata = {
                type: "pingb",
                id: this.hdMsgInfo.id,
            };
            const { data: res } = await contextMenuApi(reqdata);
            this.$toast(res.msg);
        },
        passMsg() {
            this.$store.dispatch("passMsg", this.hdMsgInfo);
        },

        // 获取机器人
        getRobot(e) {
            this.robotId = e.target.value;
        },
        // 是否弹幕
        setDanMu(e) {
            if (this.isDanmu) this.isDanmu = 0;
            else this.isDanmu = 1;
        },
        // oss 图片
        async fileAdress(file) {
            let img = new Image();
            img.src = await this.getOssSrc(file,'chat','image')
            document.getElementById("sendMsgInput").append(img);
        },
        // oss图片2
        async fileAdress2(file) {
            let content =await this.getOssSrc(file,'im')
            let reqdata = {
                friend_id: this.userInfo.admin_uid,
                content,
                msg_type: 2,
            };
        let msgData = {
                content,
                msg_type: 2,
                send_nickname: this.userInfo.nick_name,
                send_uid: this.userInfo.id,
                is_read: 0,
            };
            this.$store.commit("addHistoryMsg", msgData);
            const { data: res2 } = await sendImMsgApi(reqdata);
            if (res2.code !=200) return this.$toast(res.msg)
            this.$nextTick(() => {
                this.$refs.mobileChat.scrollTop =
                    this.$refs.mobileChat.scrollHeight;
            });
        },
        // 情况聊天
        clearCHatMsg() {
            this.$store.commit("clearHdMsgList");
        },
        // 来消息不滚动
        changeScroll() {
            this.$store.commit("changeScroll");
        },
        // 发送消息
        async sendMsg(event) {
            event.cancelBubble = true;
            event.preventDefault();
            event.stopPropagation();
            this.closeOtherBox();
            if (!this.$refs.inputBody.innerHTML) return this.$toast("内容为空");
            let content = this.$refs.inputBody.innerHTML;
            let reqdata = {
                isDanmu: this.isDanmu || "",
                robotId: this.robotId || "",
                content,
            };
            const { data: res } = await sendHdMsgApi(reqdata);
            this.$refs.inputBody.innerText = "";
            if (res.code !== 200) return this.$toast(res.msg);
            this.$nextTick(() => {
                this.$refs.rightChat.scrollTop =
                    this.$refs.rightChat.scrollHeight;
            });
        },
        // 移动端发送消息
        async sendMobileMsg() {
            this.closeOtherBox();
            if (!this.$refs.mobileBbody.value) return this.$toast("内容为空");
            let content = this.$refs.mobileBbody.value;
            let reqdata = {
                friend_id: this.userInfo.admin_uid,
                content,
                msg_type: 1,
            };
            const { data: res } = await sendImMsgApi(reqdata);
            this.$refs.mobileBbody.value = "";

            let msgData = {
                content,
                msg_type: 1,
                send_nickname: this.userInfo.nick_name,
                send_uid: this.userInfo.id,
                is_read: 0,
            };
            this.$store.commit("addHistoryMsg", msgData);
            if (res.code !== 200) return this.$toast(res.msg);

            this.$nextTick(() => {
                this.$refs.mobileChat.scrollTop =
                    this.$refs.mobileChat.scrollHeight;
            });
        },
        // 移动端发送QQ表情
        getFaceByApp(body) {
            this.$refs.mobileBbody.value += body;
        },
        // 移动端加载历史消息
        async loadMoreKefuMsg(e) {
            if (this.historylist.length == 0) return false;
            this.closeOtherBox();
            let scrollTop = e.target.scrollTop;
            if (scrollTop == 0) {
                let reqdata = {
                    friend_id: this.userInfo.admin_uid,
                    last_time: this.historylist[0].last_time,
                };
                if (!this.flag) return false;
                this.flag = true;
                const { data: res } = await getHistoryMsgApi(reqdata);
                if (res.code != 200) return this.$toast(res.msg);
                if (res.data.length == 0) {
                    this.flag = false;
                } else {
                    let hst = e.target.scrollHeight;
                    this.$store.commit("mergeHistTotyList", res.data.reverse());
                    this.$nextTick(() => {
                        e.target.scrollTop = e.target.scrollHeight - hst;
                    });
                }
            }
        },
        // 关闭彩条
        async closeCaiTiao(body) {
         let reqdata = {
                isDanmu: this.isDanmu || "",
                robotId: this.robotId || "",
                content: `<img src="${body}" />`,
            };

            const { data: res } = await sendHdMsgApi(reqdata);
            if (res.code !== 200) return this.$toast(res.msg);
            this.$nextTick(() => {
                this.$refs.rightChat.scrollTop =  this.$refs.rightChat.scrollHeight;
            });
  
        },
        // 关闭QQ表情
        closeqqFace(body) {
            this.$refs.inputBody.innerText += body;
        },
        // 关闭 彩条和表情
        closeOtherBox() {
            this.isShowcalTiao = false; // 彩条
            this.isShowqqFace = false; // QQ表情
        },
        // 展示右键菜单
        rightClick(event, item) {
            if (!this.userInfo.is_audit) return false;
            this.hdMsgInfo = item;
            //   this.testModeCode = row.testModeCode
            this.menuVisible = false; // 先把模态框关死，目的是 第二次或者第n次右键鼠标的时候 它默认的是true
            this.menuVisible = true; // 显示模态窗口，跳出自定义菜单栏
            event.preventDefault(); //关闭浏览器右键默认事件
            //   this.CurrentRow = row
            var menu = document.querySelector(".menu");
            this.styleMenu(menu, event);
        },
        foo() {
            // 取消鼠标监听事件 菜单栏
            this.menuVisible = false;
            document.removeEventListener("click", this.foo); // 关掉监听，
        },
        styleMenu(menu) {
            if (event.clientX > 1800) {
                menu.style.left = event.clientX - 100 + "px";
            } else {
                menu.style.left = event.clientX + 1 + "px";
            }
            document.addEventListener("click", this.foo); // 给整个document新增监听鼠标事件，点击任何位置执行foo方法
            if (event.clientY > 700) {
                menu.style.top = event.clientY - 30 + "px";
            } else {
                menu.style.top = event.clientY - 1 + "px";
            }
        },
        // 图片加载完成滚动到底部
        scrollBottom() {
            this.$refs.mobileChat.scrollTop =
                this.$refs.mobileChat.scrollHeight;
        },
        // 获取剪切板内容
        async getPritContend(e) {
            const cbd = e.clipboardData;
            const ua = window.navigator.userAgent;
            // 如果是 Safari 直接 return
            if (!(e.clipboardData && e.clipboardData.items)) return;
            if (
                cbd.items &&
                cbd.items.length === 2 &&
                cbd.items[0].kind === "string" &&
                cbd.items[1].kind === "file" &&
                cbd.types &&
                cbd.types.length === 2 &&
                cbd.types[0] === "text/plain" &&
                cbd.types[1] === "Files" &&
                ua.match(/Macintosh/i) &&
                Number(ua.match(/Chrome\/(\d{2})/i)[1]) < 49
            )
                return;
            for (let i = 0; i < cbd.items.length; i++) {
                let item = cbd.items[i];
                if (item.kind == "file") {

                    const blob = item.getAsFile();
                    // const { data: res } = await getOssApi("chat");
                    const formData = new FormData();
                    // formData.append("policy", res.data.policy);
                    // formData.append("OSSAccessKeyid", res.data.accessid);
                    // formData.append("signature", res.data.signature);
                    // formData.append("success_action_status", 200);
                    // formData.append("key",res.data.dir + blob.lastModified + blob.name
                    // );
                    formData.append("file", blob);
                    formData.append("dir", 'chat');
                    const { data: res } = await this.$upload.post('/upload', formData);
                    srcByOss = 'https://hushenlive.xyz' + res.data.src
                    let img = new Image();
                    img.src = res.data.src;
                    document.getElementById("sendMsgInput").innerHTML = "";
                    document.getElementById("sendMsgInput").append(img);

                }
            }
        },
    },
    components: {
        login: () => import("@/components/diaLog/login.vue"),
        reg: () => import("@/components/diaLog/reg.vue"),
        redDialog: () => import("@/components/red/redDialog.vue"),
        myRed: () => import("@/components/red/myRed.vue"),
        sendRed: () => import("@/components/red/sendRed.vue"),
        redBao: () => import("@/components/red/redBao.vue"),
        getRed: () => import("@/components/red/getRed.vue"),
		AudioBox:()=>import("@/components/diaLog/AudioBox.vue")
    },
};
</script>


<style lang="scss" scoped>
.pore {
    position: relative;
}
.flex_toll_bar {
    display: flex !important;
}
.flexbox {
    display: flex;
    flex-direction: column; /*定义排列方向为竖排*/
    height: 100%; /*这里也要定义，重要*/
    width: 100%;
    background-color: #fff;
    float: right;
}
.chat_conent {
    flex: 1;
    overflow: auto;
}
.notice {
    height: 40px;
}
.qqFace {
    position: absolute;
    z-index: 1000;
    bottom: 44px;
    width: 372px;
    right: -185px;
}

.bar_true {
    background-position: 4px -361px;
}
.imgBox:hover {
    border: 1px solid #666;
    cursor: pointer;
}
.mobile_chat {
    background-color: #eeeeee;
    height: 100%;
}
.contextmenu__item {
    display: block;
    line-height: 34px;
    text-align: center;
    color: #333333;
}
.contextmenu__item:not(:last-child) {
    border-bottom: 1px solid rgba(0, 0, 0, 0.1);
}
.menu {
    position: absolute;
    background-color: #fff;
    width: 100px;
    /*height: 106px;*/
    font-size: 12px;
    color: #444040;
    border-radius: 4px;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    border-radius: 3px;
    border: 1px solid rgba(0, 0, 0, 0.15);
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.175);
    white-space: nowrap;
    z-index: 1000;
}
.contextmenu__item:hover {
    cursor: pointer;
    background: #66b1ff;
    border-color: #66b1ff;
    color: #fff;
}
.sub_btn:hover {
    background-color: #f46b0a;
    padding: 3px 15px;
    color: #fff;
}
.sub_btn {
    padding: 3px 15px;
    background-color: #f46b0a;
    color: #fff;
}

.header {
    display: flex;
    height: 40px;
    background-color: #36373c;
    color: #fff;
    align-items: center;
    padding-left: 30px;
    font-size: 18px;
}
.header span:first-child {
    margin-right: 30px;
}
.chat_main {
    width: 100%;
}

.chat_main_min {
    height: 660px;
}
.chatContent {
    box-sizing: border-box;
    padding: 20px;
    overflow: auto;
    .text_body {
      background-color:#5FB878;
      color: #fff;
        max-width: 70%;
        border-radius: 5px;
        padding: 10px;
        font-size: 16px;
        margin: 15px 10px;
        word-wrap: break-word;
    }
    // 图片css
    .image_body {
        max-width: 100px;
        max-height: 300px;
        min-width: 20px;
        background-color: #f7f6fc;
        margin: 10px;
        .el-image,
        img {
            max-width: 100px;
            max-height: 300px;
        }
    }
    // 语音css

    .msg_detail {
        display: flex;
    }
    .my_msg_detail {
        display: flex;
        flex-flow: row-reverse;
    }
}
.chatFooter_mobile {
    height: 100px;
    width: 100%;
    background-color: #eeeeee;
    padding: 10px;
    .flex_input {
        display: flex;
        justify-content: space-between;
        input {
            width: 100%;
            outline: none;
            border: none;
            margin-right: 10px;
            padding-left: 10px;
        }
    }
    .icon_box {
        position: relative;
        display: flex;
        margin-top: 4px;
        div {
            width: 30px;
            height: 30px;
            margin-right: 30px;
            i {
                font-size: 30px;
            }
        }
    }
    // .icon_box div:first-child{
    //   background: url('../assets/img/tool.png') no-repeat;
    // }
}
.jnpai_zhuli {
    display: flex;
    align-items: center;
    background-color: #fff;
    width: 85px;
    img {
        width: 100%!important;
    }
    cursor: pointer;
    span {
        color: #3463ad;
    }
    i {
        background-color: #3463ad;
        color: #fff;
        margin-right: 5px;
        height: 100%;
        width: 20px;
        text-align: center;
        line-height: 20px;
    }
}
.jnpai_zhuli:hover {
    background-color: #3463ad;
    span {
        color: #fff;
    }
}
.bg_color {
    background-color: #303f45;
}
#sendMsgInput {
    background-color: #303f45;
    color: #fff;
}
#topicinput {
    background-color: #303f45;
}
.bar_left {
    position: relative;
    display: flex;
    i {
        color: #688fbd;
        font-size: 30px;
        margin-right: 30px;
    }
}
.whiteCss {
    color: #fff;
    font-weight: 700;
}
.redCss {
    color: red;
    font-weight: 700;
}
.ption_a {
    z-index: 1000;
    left: 28px;
    top: -369px;
    background-color: #fff;
}
.appqqFace {
    position: absolute;
    width: 201px !important;
    left: 0;
    bottom: 77px;
    background-color: #fff;
    height: 100px !important;
    overflow: auto;
}
.read_box {
    display: flex;
}
.wzdu_item {
    color: #ee3888 !important;
    display: flex;
    align-items: center;
}
.yidu_item {
    color: #35ceab !important;
    display: flex;
    align-items: center;
}
.mobile_icon{
    color: #fff;
    font-size:20px;
}
.nick_name_class{
  font-size: 12px;
  color: #999999;
  span{
    display: inline-block;
    margin-right: 20px;
  }
}
.my_poab_nick_name{
    color: #000;
    position: absolute;
    right: 56px;
    top: -11px;
}
.poab_nick_name{
    color: #000;
    position: absolute;
    left: 56px;
    top: -11px;
    display: flex;
    align-items: center;
    flex-direction: row-reverse;
    span{
      margin-left: 20px;
    }
}
.pore{
    position: relative;
}

.center_robot {
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 20px 0;
}
.center_robot_list {
    margin-bottom: 10px;
    cursor: pointer;
}
.title {
    font-size: 16px;
    font-weight: 700;
    margin-bottom: 20px;
    color: #000;
}
.center_robot_list:hover{
    background-color: #ccc;
}
</style>