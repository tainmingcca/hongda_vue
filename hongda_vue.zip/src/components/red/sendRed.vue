<template>
  <el-dialog custom-class="red_dialog" :show-close="false" center :visible.sync="dialogVisible" @close="$emit('closeSendRed')" width="300px" top="80px">
      <!-- 发红包 -->
      <section class="red_box">
          <header class="red_header">发红包</header>
          <div class="contend">
              <div class="form_item" style="margin-top:20px;">
                  <span>金额</span>
                  <div>
                    <input type="number" v-model="reqdata.money">
                    <span>元</span>
                  </div>
              </div>

              <div class="form_item">
                  <span>个数</span>
                  <div>
                    <input type="number" v-model="reqdata.num">
                    <span>个</span>
                  </div>
              </div>

              <div class="form_item">
                  <span>备注</span>
                  <div>
                    <input v-model="reqdata.remark" style="text-align: left;" placeholder="恭喜发财" type="text">
                  </div>
              </div>
              <div class="form_item" v-if="userInfo.user_type == 1">
                  <span>发送机器人</span>
                    <input @click="showRobotList = true" v-model="robot_name"  placeholder="选择机器人" readonly style="text-align: left;cursor:pointer"  type="text">
                  <div  class="robot_list" v-show="showRobotList">
                    <div class="robot_list_item" @click="robot_name = item.nick_name;showRobotList=false;reqdata.robot_id=item.id"  v-for="(item, index) in robotList" :key="index">
                      <span>{{item.nick_name}} ({{item.group_name}})</span>
                    </div>
                  </div>
              </div>
          </div>

          <div @click="sendRedBag" :style="{marginTop: marginTop}" class="send_red">发送红包</div>
      </section>
  </el-dialog>
</template>

<script>
import { sendRedBagApi } from "@/apis/index";
export default {
  data() {
    return {
      dialogVisible: true,
      showRobotList:false,
      robot_name:"",
      reqdata :{
          money:"",
          num:"",
          remark:"",
          robot_id:"",
      }
    };
  },
  computed: {

    marginTop () {
      if (this.userInfo.user_type == 1) {
        return  '20px'
      }else{
        return  '50px'
      }
    }
 
  },
  methods: {
    async sendRedBag () {
        if (!this.reqdata.money) return this.$toast('请输入金额')
        if (!this.reqdata.num) return this.$toast('请输入红包个数')
        if (!this.reqdata.remark) this.reqdata.remark = "恭喜发财"
        const {data:res}  = await sendRedBagApi(this.reqdata)
        if (res.code == 200) {
          this.$emit('closeSendRed')
          this.$store.dispatch('getUserInfo')
          return this.$toast(res.msg)
        }else {
          return this.$toast(res.msg)
        }
    },

  },
  components: {},
  created() {
  },
  mounted() {},
};
</script>
<style lang="scss" scoped>
::v-deep.el-dialog__header {
  padding-top: 0!important;
}
.red_box {
        background-color: #ECEDEE;

    height: 400px;
    width: 300px;
    .red_header {
        background-color: #D13D4B;
        color: #fff;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 40px;
    }
    .contend {
        .form_item {
            height: 50px;
            background-color: #fff;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 5px 15px;
            margin-bottom: 20px;
            position: relative;
            input {
                text-align: right;
                height: 30px;
                border: none;
                padding: 0 10px;
            }
            .robot_list {
              position: absolute;
              left: 80px;
              top: 50px;
              height: 150px;
              width: 220px;
              background-color: #fff;
              overflow-y: auto;
              box-shadow: 0 2px 4px rgba(0, 0, 0, .12), 0 0 6px rgba(0, 0, 0, .04);
              padding: 10px;
            }
            .robot_list_item {
              display: flex;
              cursor: pointer;
              width: 220px;
              margin-bottom: 10px;
              padding: 5px;
            }
            .robot_list_item:hover {
              background-color: #ccc;
            }
            .robot_list::-webkit-scrollbar { width: 0 !important }
            input[type=number] {

    &::-webkit-outer-spin-button,
    &::-webkit-inner-spin-button {
        -webkit-appearance: none;
    }
    -moz-appearance: textfield;
    
}
        }
    }
}
.send_red {
    background-color: #D13D4B;
    color: #fff;
    margin: 0 50px;
    height: 40px;
    display: flex;
    justify-content: center;
    align-items: center;
    border-radius: 5px;
    margin-top: 20px;
    cursor: pointer;
}
</style>