<template>
  <el-dialog
    custom-class="red_dialog"
    :show-close="false"
    center
    :visible.sync="dialogVisible"
    @close="$emit('closeGetRed')"
    width="320px"
    top="80px"
  >
    <section>
      <div class="center">
        <img src="@/assets/img/list.png" alt="" />
        <img class="hb_icon" src="@/assets/img/hb3.png" alt="">
        <div class="center_title">
          <span class="center_title_1" v-if="redBagData.code == 201">您已领取</span>
          <span class="center_title_1" v-if="redBagData.code == 202">红包已领完</span>
          <span v-if="redBagData.code != 202"> <span class="center_title_2">{{redBagData.money}}</span> 元</span>
          <span v-if="redBagData.code == 202 && myGetMoney"> <span class="center_title_2">  {{myGetMoney}} </span> 元</span>

        </div>
        <div class="getred_list" >
          <div class="red_record" v-for="(item, index) in redLog" :key="index">
            <div class="red_record_info">
              <!-- <img src="@/assets/img/skype1.png" alt="" /> -->
              <div class="user_info">
                <span>{{item.nick_name}}</span>
                <span>2020:11:11</span>
              </div>
            </div>
            <div> {{item.money}} 元</div>
          </div>
        </div>
      </div>
    </section>
  </el-dialog>
</template>

<script>
import { getRedBagLogApi } from "@/apis/index";
export default {
  data() {
    return {
      dialogVisible: true,
      redLog:[]
    };
  },
  computed: {
    myGetMoney () {
      let userMoney =  this.redLog.find(item=>item.uid == this.userInfo.id)
      if (userMoney) {
        return  userMoney.money
      }else {
        return false
      }
    }
  },
  props:['redBagData'],
  methods: {
    // openMyred() {},
  async  getredLog () {
        let reqdata = {id:this.redBagData.id}
        const {data:res} =await getRedBagLogApi(reqdata)
        this.redLog = res.data
    }
  },
  components: {},
  created() {

      this.getredLog()
  },
  mounted() {},
};
</script>
<style lang="scss" scoped>
::v-deep.el-dialog__header {
  padding-top: 0 !important;
}
//
// .el-dialog, .
.center {
  display: flex;
  justify-content: center;
  position: relative;
  .hb_icon {
      position: absolute;
     left: 140px;
    top: 48px;
    width: 50px;
    height: 50px;
  }
  .center_title {
    position: absolute;
    top: 100px;
    display: flex;
    flex-direction: column;
    align-items: center;
    .center_title_1 {
      font-size: 16px;
      color: #000;
      margin-bottom: 10px;
    }
    .center_title_2 {
      font-size: 26px;
      color: red;
    }
  }
  .getred_list {
    position: absolute;
    top: 170px;
    background-color: #f0f0f0;
    width: 318px;
    height: 279px;
    overflow-y: auto;
    padding: 10px;
  }
}
.red_btn_group {
  display: flex;
  position: absolute;
  bottom: 50px;
}
.red_record {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin: 10px 0;
    .red_record_info {
        display: flex;
        img {
            width: 50px;
            height: 50px;
            border-radius: 10px;
        }
        .user_info {
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            margin-left: 20px;
            padding: 5px 0;
        }
    }
}
</style>