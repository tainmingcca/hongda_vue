<template>
  <div class="red_bag" >
      <div>
          <img width="30px" src="@/assets/img/hb_icon.png" alt="">
      </div>
      <div class="hb_remark">
          {{item.remark || '恭喜发财'}}
      </div>
  </div>
  <!-- <div class="red_bag opaticy" v-else>
      <div>
          <img width="30px" src="@/assets/img/hb_icon.png" alt="">
      </div>
      <div class="hb_remark">
          红包已领完
      </div>
  </div> -->
</template>

<script>
export default {
  props:['item'],
  data() {
    return {
      
    };
  },
  computed: {},
  methods: {},
  components: {},
  created() {},
  mounted() {}
};
</script>
<style lang="scss" scoped>
.red_bag {
    width: 200px;
    height: 50px;
    background-color: #D59148!important;
    margin: 10px  0;
    display: flex;
    align-items: center;
    cursor: pointer;
    .hb_remark {
        flex: 1;
        text-align: center;
        color: #fff;
    }
}
.opaticy {
  filter: grayscale(.4);
}
</style>