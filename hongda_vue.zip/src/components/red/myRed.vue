<template>
  <el-dialog custom-class="red_dialog" :show-close="false" center :visible.sync="dialogVisible" @close="$emit('closeMyRed')" width="320px" top="80px">
      <section>
          <div class="center">
              <img src="@/assets/img/list.png" alt="">
              <img class="hb_icon" src="@/assets/img/hb_icon.png" alt="">
              <div class="center_title">
                <span class="center_title_1">共收到 {{redData.count}} 个红包</span>
                <span> <span class="center_title_2">{{redData.total}}</span> 元</span>
              </div>
              <div class="getred_list" @scroll="loadMoreData($event)">
                <div v-for="(item, index) in redData.list" :key="index">
                  <div class="flex_box">
                    <span>{{item.create_time}}</span>
                    <span>{{item.money}}</span>
                  </div>
                </div>
              </div>
          </div>
      </section>
  </el-dialog>
</template>

<script>
import { getUserBagLogApi } from "@/apis/index";
export default {
  data() {
    return {
      dialogVisible: true,
      redData:[],
      page:2,
      reqLoading:false
    };
  },
  computed: {

 
  },
  methods: {
     async getUserLog () {
      const {data:res} = await getUserBagLogApi()        
      this.redData = res.data
      console.log('getUserBagLogApi',res.data);
      },
      async loadMoreData (e) {
            let scrollHeight = e.target.scrollHeight
      let scrollTop = e.target.scrollTop
      let clientHeight = e.target.clientHeight
      let scrollBottom = scrollHeight - scrollTop - clientHeight
      if (scrollBottom < 10) {
        let reqdata = {
          page:this.page++
        }
        if ( this.reqLoading) return
        this.reqLoading = true
        const {data:res} = await getUserBagLogApi(reqdata)        
        this.redData.list = [...this.redData.list,...res.data.list]
        console.log(res.data.list);
        if (res.data.length >= 15) {
        this.reqLoading = false
        }
          

      }
      }
  },
  components: {},
  created() {
    this.getUserLog()
  },
  mounted() {},
};
</script>
<style lang="scss" scoped>
::v-deep.el-dialog__header {
  padding-top: 0!important;
}
// 
// .el-dialog, .
.center {
    display: flex;  
    justify-content: center;
    position: relative;
    .center_title {
      position: absolute;
      top: 100px;
      display: flex;
      flex-direction: column;
      align-items: center;
      .center_title_1 {
        font-size: 16px;
        color: #000;
        margin-bottom: 10px;
      }
      .center_title_2 {
        font-size: 16px;
        color:red;
      }
    }
    .getred_list {
      position: absolute;
      top: 170px;
      background-color: #F0F0F0;
    width: 318px;
    height: 279px;
    overflow-y: auto;
    }
} 
.red_btn_group {
    display: flex;
    position: absolute;
    bottom: 50px;
  
}
.flex_box {
  display: flex;
  justify-content: space-between;
  padding: 10px;
}
  .hb_icon {
      position: absolute;
     left: 140px;
    top: 48px;
    width: 50px;
    height: 50px;
  }
</style>