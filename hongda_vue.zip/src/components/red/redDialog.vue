<template>
  <el-dialog custom-class="red_dialog" :show-close="false" center :visible.sync="dialogVisible" @close="$emit('closeRed')" width="800" top="80px">
      <section>
          <div class="center">
              <img src="@/assets/img/index.png" alt="">
              <div class="red_btn_group">
                  <span @click="$emit('openSendRed')" class="red_btn">发红包</span>
                  <span @click="$emit('openMyred')" class="red_btn">我的红包</span>
              </div>
          </div>
      </section>
  </el-dialog>
</template>

<script>
// import {  } from "@/apis/index";
export default {
  data() {
    return {
      dialogVisible: true,
    };
  },
  computed: {

 
  },
  methods: {
    openMyred () {}
  },
  components: {},
  created() {
  },
  mounted() {},
};
</script>
<style lang="scss" scoped>
::v-deep.el-dialog__header {
  padding-top: 0!important;
}
// 
// .el-dialog, .
.center {
    display: flex;
    justify-content: center;
    position: relative;
} 
.red_btn_group {
    display: flex;
    position: absolute;
    bottom: 50px;
    .red_btn {
        background-color: #F0D23A;
        color: #D12A1E;
        padding: 10px 20px;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 10px;
        width: 96px;
        cursor: pointer;
        border-radius: 10px;
    }
}
</style>