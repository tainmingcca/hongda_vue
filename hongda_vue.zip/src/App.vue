<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<script>
import {indexApi,getOnlineInfoApi} from '@/apis/index.js'
import { EventBus } from "@/tools/EventBus";
EventBus.$on("sendDanMu", (data) => {
    let marquee = document.createElement('marquee')
    marquee.setAttribute('id','danmu')
    marquee.className = 'Barrage'
    marquee.setAttribute('direction','left')
    marquee.setAttribute('scrollamount','10')
    marquee.setAttribute('loop','2')
    marquee.innerHTML = data
    marquee.addEventListener('onfinish',()=>{
    })
  document.getElementById('app').append(marquee)
});
export default {

  methods: {
    getClientType () {
      var sUserAgent = navigator.userAgent.toLowerCase();
      var bIsIpad = sUserAgent.match(/ipad/i) == "ipad";
      var bIsIphoneOs = sUserAgent.match(/iphone os/i) == "iphone os";
      var bIsMidp = sUserAgent.match(/midp/i) == "midp";
      var bIsUc7 = sUserAgent.match(/rv:1.2.3.4/i) == "rv:1.2.3.4";
      var bIsUc = sUserAgent.match(/ucweb/i) == "ucweb";
      var bIsAndroid = sUserAgent.match(/android/i) == "android";
      var bIsCE = sUserAgent.match(/windows ce/i) == "windows ce";
      var bIsWM = sUserAgent.match(/windows mobile/i) == "windows mobile";
      if (bIsIpad || bIsIphoneOs || bIsMidp || bIsUc7 || bIsUc || bIsAndroid || bIsCE || bIsWM) {
      this.$store.commit("getBodyWidth", 750);
      this.$store.commit("getClientType", 'app');
      } else {
      this.$store.commit("getBodyWidth", 1080);
      this.$store.commit("getClientType", 'pc');
      }
    },

  },
  mounted () {
    this.getClientType()
    let that = this
        window.onresize = function () {
      let bodyWidth = document.getElementById("app").clientWidth 
      that.$store.commit("getBodyWidth", bodyWidth);
    };
    EventBus.$on('toast',(msg)=>{
      this.$toast(msg)
    })

    
},
  created () {
    indexApi().then(({data:res})=>{
          if (res.code == 200) {
              this.$store.commit('addYkToken',res.data)
              require('@/tools/socket')
              this.$store.commit('getDjsTime',res.data.userInfo.djs_time)
              this.$store.dispatch('getFriendList')
              document.title = res.data.roomInfo.room_name
                      getOnlineInfoApi().then(({ data: res }) => {
            this.$store.commit("getOnlineData", res.data);
            if (res.code == 200) {
                this.$store.dispatch("getHdMsgListApi");
            }
        });
            let meta1 = document.createElement('meta')
              meta1.setAttribute('name','description')
              meta1.setAttribute('content',`${res.data.roomInfo.room_keywords}`)
              document.getElementsByTagName('head')[0].append(meta1)

            let meta2 = document.createElement('meta')
              meta2.setAttribute('name','keywords')
              meta2.setAttribute('content',`${res.data.roomInfo.room_desc}`)
              document.getElementsByTagName('head')[0].append(meta2)
          }

    })
},
components:{
}
}
</script>

<style lang="scss">
#app{width: 100%;height: 100%;}
</style>
