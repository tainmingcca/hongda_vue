import axios from '@/tools/http'
export const indexApi = () => {return axios.get('/api/index')} 
export const getOnlineInfoApi = () => {return axios.get('/api/getOnlineUser')} 
export const getHdMsgApi = () => {return axios.get('/api/get_hdmsg')} 
export const getFriendListApi = () => {return axios.get('/api/im_friendList')} 
export const getHistoryMsgApi = (data) => {return axios.get('/api/im_historyMsg', {params: data})} 
export const sendHdMsgApi = (data) => {return axios.post('/api/send_hdMsg',data)}  // content robotId isDanmu
export const sendImMsgApi = (data) => {return axios.post('/api/im_sendMsg',data)}  // friend_id content msg_type
export const loginApi = (data) => {return axios.post('/api/login',data)}  // friend_id content msg_type
export const regApi = (data) => {return axios.post('/api/reg',data)}  // friend_id content msg_type
export const logOutApi = () => {return axios.get('/api/logOut')}
export const getOssApi = (path) => {return axios.post(`/api/get_oss_policy/${path}`)}  // friend_id content msg_type
export const getNavApi = (data) => {return axios.get('/api/get_nav', {params: data})} //  kcb product service caijing
export const getTeacherListApi = (data) => {return axios.get('/api/teacherList', {params: data})} //  kcb product service caijing
export const zanTeacherApi = (data) => {return axios.get('/api/zanTeacher', {params: data})} //  kcb product service caijing
export const editPwdApi = (data) => {return axios.post(`/api/editPass`,data)}  // pwd pwd1 pwd2
export const profileApi = (data) => {return axios.post(`/api/profile`,data)}  // pwd pwd1 pwd2
export const contextMenuApi = (data) => {return axios.post(`/api/contextMenu`,data)}  // jinyan pingb del pass
export const getWelcomeMsgApi = () => {return axios.get('/api/im_setWelcomeMsg')}
export const setWelcomeMsgApi = (data) => {return axios.post(`/api/im_setWelcomeMsg`,data)}  //content
export const getFastListgApi = () => {return axios.get('/api/im_getKjhf')}
export const addFastListgApi = (data) => {return axios.post(`/api/im_addKjhf`,data)}  //content
export const delHistoryMsgApi = (data) => {return axios.get('/api/im_delKjhf', {params: data})}  // id
export const getTurnTableInfoApi = (data) => {return axios.get('/api/getTurnTableInfo')}  // 获取大转盘信息
export const luckDrawApi = (data) => {return axios.post(`/api/luckDraw`,data)}  //content
export const getQQApi = () => {return axios.get('/api/getQQ')}
export const userSignApi = () => {return axios.get('/api/userSign')}
export const getSignListApi = () => {return axios.get('/api/getSignList')}
export const sendRedBagApi = (data) => {return axios.post(`/api/sendRedBag`,data)}  //content
export const shouRedBaoApi = (data) => {return axios.get('/api/shouRedBao', {params: data})} //  kcb product service caijing
export const getRedBagLogApi = (data) => {return axios.get('/api/redBagLog', {params: data})} //  kcb product service caijing
export const getUserBagLogApi = (data) => {return axios.get('/api/getUserBagLog', {params: data})} //  kcb product service caijing
export const getUserInfoApi = (data) => {return axios.get('/api/getUserInfo', {params: data})} //  更新用户积分
export const sendBalloonApi = (data) => {return axios.get('/api/sendBalloon', {params: data})} //  更新用户积分
export const sendMusicApi = (data) => {return axios.get('/api/sendMusic', {params: data})} //  发送语音



