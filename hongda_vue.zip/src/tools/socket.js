const LOG_DEBUG = true;
import router from '@/router'
import store from "@/store/index";
import {Notification} from 'element-ui'
const $notify = Notification 
import {
  EventBus
} from "@/tools/EventBus";
let audio = document.createElement("audio"); // 创建audio标签
setTimeout(() => {
  audio.src = store.state.audioSrc; // 引入路径
  
}, 1000);

var ishttps = 'https:' == document.location.protocol ? true: false;
let palyAudio = true;
var timer = 0;
class socketPc {
  constructor() {
    this.userId = ""; // 用户id
    this.socket = { readyState: 3 }; //socket链接对象  {"CLOSED": 3,"CLOSING": 2,"CONNECTING": 0,"OPEN": 1,"readyState": 1}
    this.heartTime = 40; //心跳间隔
    this.heartTimer = null;
    this.init("init"); // 初始化链接
  }
  //初始化/重连
  async init(type = "reconnect") {
    //重连前一定先获取用户id
    // this.userId = store.state.userInfo.id || false;
    //重连先关闭心跳
    if (this.heartTimer != null) clearInterval(this.heartTimer);
    const socketUrl = this.getSocketUrl();
    if (socketUrl === false) {
      if (this.socket.readyState == 1) this.closeSocket();
      setTimeout(() => {
        this.init(type);
      }, 5 * 1000);
    } else if (this.socket.readyState != 1) {
      //&& type == 'reconnect'
      if (type == "init") {
        this.connect(socketUrl);
      } else {
        setTimeout(() => {
          this.connect(socketUrl);
        }, 5 * 1000);
      }
    }
  }
  //真正的链接socket
  connect(socketUrl) {
    this.socket = new WebSocket(socketUrl);
    this.socket.onopen = (e) => {
    this.sendMsg({type: "login", token: store.state.utoken ? store.state.utoken :store.state.yktoken}); 
      this.heartTimer = setInterval(() => {
        this.sendHeartbeat();
      }, this.heartTime * 1000);
      LOG_DEBUG && console.log("通讯建立成功");
    };
    this.socket.onclose = (e) => {
      console.log("WebSocket 被关闭！",e);
    };
    this.socket.onerror = (e) => {
      console.log("WebSocket 连接发生错误",e);
      this.init("reconnect");
    };
    this.socket.onmessage = (res) => {
      try {
        if (res == undefined) return false;
        var msg = JSON.parse(res.data);
        this.listenOnMessage(msg);
        
      } catch (err) {
        console.log("接受消息处理逻辑错误：" + err);
      }
    };
  }
  //获取链接地址
  getSocketUrl() {
    let  socketUrl  = ""
    let yuming = document.domain
      if (ishttps) {
        socketUrl = `wss://${yuming}/socket.io`;
    }else{
        socketUrl = `ws://${yuming}/socket.io`;
    }
    if (process.env.NODE_ENV === "development") {
      // socketUrl = `ws://com/socket.io`;
    }
     return socketUrl;
  }
  //主动关闭socket
  closeSocket() {
    //重新new之前把之前的所有定时器都清理掉
    if (this.heartTimer != null) clearInterval(this.heartTimer);
    this.socket.readyState == 1 && this.socket.close();
  }
  //发送心跳
  sendHeartbeat() {
    if (this.socket.readyState != 1) {
      //发送失败清除心跳，然后重连
      console.log("发送心跳前发现断开，开始重连");
      this.init("reconnect");
      return false;
    }
    console.log("[ 发送心跳 ]");
    this.sendMsg({type: "ping"});
  }
  //发送消息
  sendMsg(msg) {
    let data = JSON.stringify(msg);
    this.socket.send(data);
  }

   listenOnMessage(msg) {
    console.log("收到服务端消息", msg);
    if (msg.type === 'hd_msg') {
      // create_time
      store.commit('addHdMsg',msg.data)
      // 是否更新滚动条
      if (!store.state.isScroll) EventBus.$emit('updateHdMsgScroll')
    }else if (msg.type === 'imMsg') {
      if (!store.state.isShowChat) {

        let chatInfo = {
          head_img:msg.data.send_headimg,
          id:msg.data.send_uid,
          nick_name:msg.data.send_nickname,
        }
        let data = {
          chatInfo,
          msgData:msg.data
        }
        if (store.state.userData.userInfo.user_type == 2) {
        store.commit('getIsShowChat',true)
          store.commit('getChatInfo',chatInfo)
          store.dispatch('getHistoryMsgApiByPositioner',data)
        }
      }
      // 聊天对象

      // 是否追加消息
      if (store.state.chatInfo.id == msg.data.send_uid || store.state.clientType =='app') {
       store.commit('addHistoryMsg',msg.data)
       store.commit('readMsg',msg.data)
     }
     store.commit('addChatFriendList',msg.data)
     EventBus.$emit('updateHistoryMsgScroll') // 更新滚动条




    if (store.state.clientType === 'pc') {
      Notification.info( {
        title: msg.data.send_nickname,
        message: msg.data.content,
        onClick: function () {
      
        }
      })
    }
    }else if (msg.type === 'online_status') {
      
      if (msg.data.online_status == "offline") {
        msg.data.is_online = 0
      }else{
        msg.data.is_online = 1
        let str =  
        `<div style="position: relative;" class="pore_style">
        <img src='${store.state.welcomePng}'>
        <span style="position: absolute;left: 104px;top: 22px;color: #E5E501;font-size: 18px;" >${msg.data.content}</span>
       </div>`
       if (store.state.clientType === 'pc') {
        $notify({ message: str, position: 'bottom-left', duration:1500, dangerouslyUseHTMLString: true, customClass:"my_custom_class", showClose:false});
       }
      }
      store.commit('updateChatlist',msg.data)
      
    }else if (msg.type === 'danmu') {
      EventBus.$emit('sendDanMu',msg.data.content)
    }else if (msg.type === 'del_hd_msg') {
      store.commit('delMsgFromHistorylist',msg.data)
    }
	else if (msg.type === 'audio') {
		  switch (Number(msg.data.type)) {
        case 1:
          audio.src = require("../assets/audio/liuqiang.mp3");
          break;
        case 2:
          audio.src = require("../assets/audio/chencheng.mp3");
          break;
        case 3:
          audio.src = require("../assets/audio/luming.mp3");
          break;
        case 4:
          audio.src = require("../assets/audio/limingze.mp3");
          break;
        case 5:
          audio.src = require("../assets/audio/zhouhongming.mp3");
          break;
        case 6:
          audio.src = require("../assets/audio/caoxuanhua.mp3");
          break;
        case 7:
          audio.src = require("../assets/audio/xiamaitishi.mp3");
          break;
        case 8:
          audio.src = require("../assets/audio/anquantishi.mp3");
          break;
		  }
		audio.play();
		}




    return
        timer = setTimeout(() => { palyAudio = true}, 3000);
        if (!palyAudio) return false;
        palyAudio = false;
        audio.play();
  }
}

const socket = new socketPc();
export default socket;
