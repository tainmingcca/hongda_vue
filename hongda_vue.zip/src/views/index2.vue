<template>
    <div class="bg_imgs" 
       :style="{ background: `url('${roomInfo.default_bg}') center center / 100% 100% no-repeat`}" 
     ref="bgImg">
        <input type="hidden" id="user_type" value="2" />
        <header>
            <div
                class="bo_logo f_left"
                id="headlogo"
                :style="{
                    background: `url('${roomInfo.logo_url}') center center / 100% 80% no-repeat`,
                }"
            ></div>
            <div class="f_left save_desktop" @click="saveDesktop" id="favlink">
                <i class="iconfont icon-yunzhuomian"></i>
                保存到桌面
            </div>
            
		<!-- <a class="f_left media_hide" href="/soft/Skype_8.75.0.140.exe">
			   <img src="@/assets/img/down.png" alt="" /> 软件下载3
		   </a>	 -->
			
            <div v-if=" userData.turnopen != 0 && userData.turnopen" class="f_left media_hide hover_gray" @click="openDaZhuanPan">
                <img src="@/assets/img/dzp.png" alt="" /> 幸运转盘
            </div>
         <a class="f_left media_hide" href="/soft/Skype_8.75.0.140.exe">
                <img src="@/assets/img/skype1.png" alt="" /> skype
            </a>
            <a class="f_left media_hide hover_gray"  @click="openQianDao">
              <img src="@/assets/img/qd.png" alt="" />   签到
            </a>
            <div  class="f_left media_hide felx_red" @click="openChatModelsRedDialog"  >
                <img src="@/assets/img/btn_right_redbag.png" alt="">
                <div v-if="!userInfo.isYk" class="jifen">{{userInfo.jifen}}</div>
            </div>
            <div  class="f_left media_hide " @click="openMh"  >
                <img src="@/assets/img/mh.gif" width="60px" alt="">
            </div>
            <div :class="utoken ? '  is_login_f_right ' : ' f_right'" id="loginstatus" >
                <div style="cursor: pointer; line-height: 35px" class="item" @click="headMenu2Click(1)">
                    <img style=" width: 40px; height: 40px; margin-top: -4px; margin-right: 10px;" :src="userInfo.head_img"/>{{ userInfo.nick_name }}
                </div>
                <div v-if="!utoken" style="cursor: pointer" class="item" @click="headMenu2Click(3)" >
                    <img src="@/assets/img/login2.png" class="login_reg" />
                </div>
                <div v-if="!utoken" style="cursor: pointer" class="item" @click="headMenu2Click(4)" >
                    <img src="@/assets/img/register2.png" class="login_reg" />
                </div>
            </div>
            <userInfo   @showregred="showregreds" class="poab_user_info" v-if="showUserInfo&&userInfo.isYk != 1" @showInfoCener="showInfoCeners" @showChangePwd="showChangePwds" @closeUserInfo="closeUserInfos"/>
            <div class="clearfix"></div>
        </header>

        <div id="main" class="clearfix ption_r" style="">
            <!-- 用户列表模块开始 -->
            <div id="user_use" class="f_left">
                <div class="flex_box">
                    <div
                        class="item"
                        @click="showDialog(item)"
                        v-for="(item, index) in applyList"
                        :key="index"
                    >
                        <i class="fn35" :class="item.icon"></i> {{ item.title }}
                    </div>
                </div>
                <!--  在线用户-->

                <div id="user_list">
                    <!-- <div class="user_ti clearfix">
                        <span id="user_cutover"
                            ><span id="usertotal"> </span
                            >在线人数:({{roomInfo.online_num}})</span
                        >
                    </div> -->

                    <!-- 用户列表 -->
                    <div
                        id="list_u"
                        class="scroll_styles"
                        style="overflow: auto; flex: 2"
                    >
                        <ul id="all">
                            <li
                                v-for="(item, index) in onLineData.list"
                                :key="index"
                            >
                                <span><img :src="item.head_img" alt="" /> </span
                                ><a class="f_left">{{ item.nick_name }}</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <!-- /用户列表模块结束 -->

            <!-- 视频模块开始 -->
            <div id="me_use" class="pore">
                <div style="display: flex; flex-direction: column; flex: 2">
                    <div class="sp_ti">
                        <span><a>视频直播</a></span>
                        <a style="margin-right: 20px" @click="reloadPage">刷新</a>
                        <!-- <marquee direction="left"   id="livenotice" scrollamount="3" >直播啦 直播啦 直播啦</marquee> -->
                        <div
                            style="float: right; color: red; margin-right: 10px"
                        >
                            <em id="look_time" style="font-style: normal">{{
                                look_times
                            }}</em>
                        </div>
                    </div>
                    <div
                        v-if="roomInfo.video_url"
                        id="shiping"
                        v-html="roomInfo.video_url"
                        :style="{
                            background: `url(${this.roomInfo.index_dialog_img}) center center / 100% 100% no-repeat `,
                        }"
                    ></div>
                    <div
                        v-else
                        id="shiping"
                        :style="{
                            background: `url(${this.roomInfo.index_dialog_img}) center center / 100% 100% no-repeat`,
                            opacity: '0.5',
                        }"
                    >
                        <div v-if="!roomInfo.video_url" class="regTip">
                            您的试看时间已满，请您
                            <span
                                @click="openReg"
                                style="color: red; cursor: pointer"
                                >注册</span
                            >
                            后顺畅观看
                        </div>
                    </div>
                </div>
                <div id="kefu" style="height: 160px">
                    <!-- 轮播图开始 -->
                    <el-carousel :interval="3000" arrow="always">
                        <el-carousel-item
                            v-for="item in bannerList"
                            :key="item.id"
                            style="width: 100%"
                        >
                            <img
                                :src="item.ad_url"
                                style="width: 100%; height: 160px"
                            />
                        </el-carousel-item>
                    </el-carousel>
                    <!-- /轮播图结束 -->
                </div>
            </div>
            <!-- /视频模块结束 -->

            <!-- 聊天模块开始 -->
            <chat @openLogin="isShowLogin = true" ref="chatModels" /><!-- /聊天模块结束 -->

            <div class="clearfix"></div>
        </div>
        <footer v-show="bodyWidth > 880">
            分析师所发表言论只代表个人观点，仅供参考，投资有风险，入市需谨慎。
        </footer>

        <!--在线客服工具条-->
        <!-- <div v-if="!isShowChat" @click="showChatMethods" class="imkf layui-anim layui-anim-scale min_none" style="z-index:10;"><i class="iconfont icon-liaotian"></i>在<br>线<br>客<br>服</div> -->
        <!--5分钟提醒-->
        <div class="marsk" v-if="isShowMask"></div>
        <div class="dialog5minute" v-if="isLoignTip">
            <img src="@/assets/img/qzzc.png" alt="" />
            <div class="absolute">
                <div @click="regMethods" class="item dialog5minute_reg"></div>
                <div
                    @click="loginMethdos"
                    class="item dialog5minute_login"
                ></div>
            </div>
        </div>

        <div id="welcome"></div>
        <!-- <div id="think_page_trace_open" style="height:30px;float:right;text-align:right;overflow:hidden;position:fixed;bottom:0;right:0;color:#000;line-height:30px;cursor:pointer;">
        <div style="background:#232323;color:#FFF;padding:0 6px;float:right;line-height:30px;font-size:14px">0.159276s </div>
        <img width="30" style="" title="ShowPageTrace" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyBpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMC1jMDYwIDYxLjEzNDc3NywgMjAxMC8wMi8xMi0xNzozMjowMCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNSBXaW5kb3dzIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOjVERDVENkZGQjkyNDExRTE5REY3RDQ5RTQ2RTRDQUJCIiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOjVERDVENzAwQjkyNDExRTE5REY3RDQ5RTQ2RTRDQUJCIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6NURENUQ2RkRCOTI0MTFFMTlERjdENDlFNDZFNENBQkIiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6NURENUQ2RkVCOTI0MTFFMTlERjdENDlFNDZFNENBQkIiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz5fx6IRAAAMCElEQVR42sxae3BU1Rk/9+69+8xuNtkHJAFCSIAkhMgjCCJQUi0GtEIVbP8Qq9LH2No6TmfaztjO2OnUdvqHFMfOVFTqIK0vUEEeqUBARCsEeYQkEPJoEvIiELLvvc9z+p27u2F3s5tsBB1OZiebu5dzf7/v/L7f952zMM8cWIwY+Mk2ulCp92Fnq3XvnzArr2NZnYNldDp0Gw+/OEQ4+obQn5D+4Ubb22+YOGsWi/Todh8AHglKEGkEsnHBQ162511GZFgW6ZCBM9/W4H3iNSQqIe09O196dLKX7d1O39OViP/wthtkND62if/wj/DbMpph8BY/m9xy8BoBmQk+mHqZQGNy4JYRwCoRbwa8l4JXw6M+orJxpU0U6ToKy/5bQsAiTeokGKkTx46RRxxEUgrwGgF4MWNNEJCGgYTvpgnY1IJWg5RzfqLgvcIgktX0i8dmMlFA8qCQ5L0Z/WObPLUxT1i4lWSYDISoEfBYGvM+LlMQQdkLHoWRRZ8zYQI62Thswe5WTORGwNXDcGjqeOA9AF7B8rhzsxMBEoJ8oJKaqPu4hblHMCMPwl9XeNWyb8xkB/DDGYKfMAE6aFL7xesZ389JlgG3XHEMI6UPDOP6JHHu67T2pwNPI69mCP4rEaBDUAJaKc/AOuXiwH07VCS3w5+UQMAuF/WqGI+yFIwVNBwemBD4r0wgQiKoFZa00sEYTwss32lA1tPwVxtc8jQ5/gWCwmGCyUD8vRT0sHBFW4GJDvZmrJFWRY1EkrGA6ZB8/10fOZSSj0E6F+BSP7xidiIzhBmKB09lEwHPkG+UQIyEN44EBiT5vrv2uJXyPQqSqO930fxvcvwbR/+JAkD9EfASgI9EHlp6YiHO4W+cAB20SnrFqxBbNljiXf1Pl1K2S0HCWfiog3YlAD5RGwwxK6oUjTweuVigLjyB0mX410mAFnMoVK1lvvUvgt8fUJH0JVyjuvcmg4dE5mUiFtD24AZ4qBVELxXKS+pMxN43kSdzNwudJ+bQbLlmnxvPOQoCugSap1GnSRoG8KOiKbH+rIA0lEeSAg3y6eeQ6XI2nrYnrPM89bUTgI0Pdqvl50vlNbtZxDUBcLBK0kPd5jPziyLdojJIN0pq5/mdzwL4UVvVInV5ncQEPNOUxa9d0TU+CW5l+FoI0GSDKHVVSOs+0KOsZoxwOzSZNFGv0mQ9avyLCh2Hpm+70Y0YJoJVgmQv822wnDC8Miq6VjJ5IFed0QD1YiAbT+nQE8v/RMZfmgmcCRHIIu7Bmcp39oM9fqEychcA747KxQ/AEyqQonl7hATtJmnhO2XYtgcia01aSbVMenAXrIomPcLgEBA4liGBzFZAT8zBYqW6brI67wg8sFVhxBhwLwBP2+tqBQqqK7VJKGh/BRrfTr6nWL7nYBaZdBJHqrX3kPEPap56xwE/GvjJTRMADeMCdcGpGXL1Xh4ZL8BDOlWkUpegfi0CeDzeA5YITzEnddv+IXL+UYCmqIvqC9UlUC/ki9FipwVjunL3yX7dOTLeXmVMAhbsGporPfyOBTm/BJ23gTVehsvXRnSewagUfpBXF3p5pygKS7OceqTjb7h2vjr/XKm0ZofKSI2Q/J102wHzatZkJPYQ5JoKsuK+EoHJakVzubzuLQDepCKllTZi9AG0DYg9ZLxhFaZsOu7bvlmVI5oPXJMQJcHxHClSln1apFTvAimeg48u0RWFeZW4lVcjbQWZuIQK1KozZfIDO6CSQmQQXdpBaiKZyEWThVK1uEc6v7V7uK0ysduExPZx4vysDR+4SelhBYm0R6LBuR4PXts8MYMcJPsINo4YZCDLj0sgB0/vLpPXvA2Tn42Cv5rsLulGubzW0sEd3d4W/mJt2Kck+DzDMijfPLOjyrDhXSh852B+OvflqAkoyXO1cYfujtc/i3jJSAwhgfFlp20laMLOku/bC7prgqW7lCn4auE5NhcXPd3M7x70+IceSgZvNljCd9k3fLjYsPElqLR14PXQZqD2ZNkkrAB79UeJUebFQmXpf8ZcAQt2XrMQdyNUVBqZoUzAFyp3V3xi/MubUA/mCT4Fhf038PC8XplhWnCmnK/ZzyC2BSTRSqKVOuY2kB8Jia0lvvRIVoP+vVWJbYarf6p655E2/nANBMCWkgD49DA0VAMyI1OLFMYCXiU9bmzi9/y5i/vsaTpHPHidTofzLbM65vMPva9HlovgXp0AvjtaqYMfDD0/4mAsYE92pxa+9k1QgCnRVObCpojpzsKTPvayPetTEgBdwnssjuc0kOBFX+q3HwRQxdrOLAqeYRjkMk/trTSu2Z9Lik7CfF0AvjtqAhS4NHobGXUnB5DQs8hG8p/wMX1r4+8xkmyvQ50JVq72TVeXbz3HvpWaQJi57hJYTw4kGbtS+C2TigQUtZUX+X27QQq2ePBZBru/0lxTm8fOOQ5yaZOZMAV+he4FqIMB+LQB0UgMSajANX29j+vbmly8ipRvHeSQoQOkM5iFXcPQCVwDMs5RBCQmaPOyvbNd6uwvQJ183BZQG3Zc+Eiv7vQOKu8YeDmMcJlt2ckyftVeMIGLBCmdMHl/tFILYwGPjXWO3zOfSq/+om+oa7Mlh2fpSsRGLp7RAW3FUVjNHgiMhyE6zBFjM2BdkdJGO7nP1kJXWAtBuBpPIAu7f+hhu7bFXIuC5xWrf0X2xreykOsUyKkF2gwadbrXDcXrfKxR43zGcSj4t/cCgr+a1iy6EjE5GYktUCl9fwfMeylyooGF48bN2IGLTw8x7StS7sj8TF9FmPGWQhm3rRR+o9lhvjJvSYAdfDUevI1M6bnX/OwWaDMOQ8RPgKRo0eulBTdT8AW2kl8e9L7UHghHwMfLiZPNoSpx0yugpQZaFqKWqxVSM3a2pN1SAhC2jf94I7ybBI7EL5A2Wvu5ht3xsoEt4+Ay/abXgCQAxyOeDsDlTCQzy75ohcGgv9Tra9uiymRUYTLrswOLlCdfAQf7HPDQQ4ErAH5EDXB9cMxWYpjtXApRncojS0sbV/cCgHTHwGNBJy+1PQE2x56FpaVR7wfQGZ37V+V+19EiHNvR6q1fRUjqvbjbMq1/qfHxbTrE10ePY2gPFk48D2CVMTf1AF4PXvyYR9dV6Wf7H413m3xTWQvYGhQ7mfYwA5mAX+18Vue05v/8jG/fZX/IW5MKPKtjSYlt0ellxh+/BOCPAwYaeVr0QofZFxJWVWC8znG70au6llVmktsF0bfHF6k8fvZ5esZJbwHwwnjg59tXz6sL/P0NUZDuSNu1mnJ8Vab17+cy005A9wtOpp3i0bZdpJLUil00semAwN45LgEViZYe3amNye0B6A9chviSlzXVsFtyN5/1H3gaNmMpn8Fz0GpYFp6Zw615H/LpUuRQQDMCL82n5DpBSawkvzIdN2ypiT8nSLth8Pk9jnjwdFzH3W4XW6KMBfwB569NdcGX93mC16tTflcArcYUc/mFuYbV+8zY0SAjAVoNErNgWjtwumJ3wbn/HlBFYdxHvSkJJEc+Ngal9opSwyo9YlITX2C/P/+gf8sxURSLR+mcZUmeqaS9wrh6vxW5zxFCOqFi90RbDWq/YwZmnu1+a6OvdpvRqkNxxe44lyl4OobEnpKA6Uox5EfH9xzPs/HRKrTPWdIQrK1VZDU7ETiD3Obpl+8wPPCRBbkbwNtpW9AbBe5L1SMlj3tdTxk/9W47JUmqS5HU+JzYymUKXjtWVmT9RenIhgXc+nroWLyxXJhmL112OdB8GCsk4f8oZJucnvmmtR85mBn10GZ0EKSCMUSAR3ukcXd5s7LvLD3me61WkuTCpJzYAyRurMB44EdEJzTfU271lUJC03YjXJXzYOGZwN4D8eB5jlfLrdWfzGRW7icMPfiSO6Oe7s20bmhdgLX4Z23B+s3JgQESzUDiMboSzDMHFpNMwccGePauhfwjzwnI2wu9zKGgEFg80jcZ7MHllk07s1H+5yojtUQTlH4nFdLKTGwDmPbIklOb1L1zO4T6N8NCuDLFLS/C63c0eNRimZ++s5BMBHxU11jHchI9oFVUxRh/eMDzHEzGYu0Lg8gJ7oS/tFCwoic44fyUtix0n/46vP4bf+//BRgAYwDDar4ncHIAAAAASUVORK5CYII=">
    </div> -->

        <!-- 聊天对话框 -->
        <!-- <transition name="bounce"> -->
            <chatDialog  :class="isShowChat?'':'bottom_index'" v-show="clientType == 'pc'" />
        <!-- </transition> -->
        <!-- 最小化聊天 -->
        <div v-if="!isShowChat" class="min_chat" @click="$store.commit('getIsShowChat', true)">
            <!-- :hidden="item == 0" -->
            <el-badge :value="redcount" :hidden="redcount == 0" :max="99">
                <img
                    style="
                        width: 40px;
                        height: 40px;
                        margin-right: 5px;
                        border-radius: 40px;
                    "
                    :src="userInfo.head_img"
                    alt=""
                />
            </el-badge>
            <span>{{ userInfo.nick_name }}</span>
        </div>
        <!-- 换肤模块 -->
        <transition name="bounce">
            <div
                class="layui-layer layui-layer-page"
                style="
                    z-index: 19891024;
                    position: fixed;
                    top: 457px;
                    left: 382px;
                    background: #fff;
                "
                v-if="isShowSkin"
            >
                <div class="layui-layer-content">
                    <div class="bg_list">
                        <div
                            class="item"
                            @click="checkSkin(item.value)"
                            v-for="(item, index) in skinList"
                            :key="index"
                        >
                            <img :src="item.src" alt="" />
                        </div>
                    </div>
                </div>
                <span class="closeBtn" @click="isShowSkin = false">x</span>
            </div>
        </transition>
        <!-- 登录模块 -->
        <transition name="bounce">
            <login v-if="isShowLogin" @closeLogin="isShowLogin = false" />
        </transition>
        <!-- 注册模块 -->
        <transition name="bounce"
            ><reg v-if="isShowReg" @closeReg="isShowReg = false"
        /></transition>
        <!-- 课程安排 -->
        <class v-if="showClass" @closeClass="showClass = false" />
        <!-- 产品介绍 -->
        <chanpin v-if="showchanPin" @closeChanPin="showchanPin = false" />
        <!-- 财经日历 -->
        <rili v-if="showRiLi" @closeRiLi="showRiLi = false" />
        <!-- 服务体系 -->
        <server v-if="showServer" @closeSever="showServer = false" />
        <!-- 手机直播 -->
        <shoujizhibo v-if="showShoujizhibo" @closeMobile="showShoujizhibo =false" />
        <!-- 名师指导 -->
        <teacher v-if="showTeacher" @closeTeacher="showTeacher = false" />
        <!-- 修改密码 -->
        <changePwd v-if="showChangePwd" @closePwd="showChangePwd = false" />
        <!-- 个人资料 -->
        <infoCenter v-if="showInfoCener" @closeInfoCenter="showInfoCener = false" />
        <!-- 首页广告 -->
        <indexDialog v-if="showIndexAd && clientType == 'pc' && userInfo.user_type != 1" @closeIndex="showIndexAd = false"/>
        <!-- 大转盘 -->
        <turnTable @closeTurnTable="closeTurnTables" v-if="showZhuanPan" class="zhuna_pai"/>
        <!-- 签到 -->
        <sginIn @closeSignIn="showSignIn = false" v-if="showSignIn" />
        <!-- 抽奖 -->
        <chouJiang @closeChouJiang="showChouJiang = false" v-if="showChouJiang" />
		<!-- 邀请红包 -->
		<redResult  :money="userInfo.red_num" :invitation_url="userInfo.invitation_url" v-if="showRegRedDialog" @closeRegRes="showRegRedDialog = false" />
        <!-- 观看时间结束弹窗 -->
        <timeEnd v-if="showTimeEnd" @closeTimeEnd="showTimeEnd = false"></timeEnd>
    </div>
</template>
<script>
import { Notification } from 'element-ui'

import {  getTurnTableInfoApi } from "@/apis/index.js";
import { Alert, MessageBox } from "element-ui";
import { mapGetters, mapState } from "vuex";
export default {
    data() {
        return {
            isLoignTip: false, // 登录提示
            isShowMask: false, // 遮罩层
            isShowSkin: false, // 换肤
            isShowLogin: false, // 登录
            isShowReg: false, // 注册
            showChangePwd: false, // 修改密码
            showInfoCener: false, // 用户个人资料
            showSignIn:false,// 签到
            showZhuanPan: false,
            lookTimeEnd: true,
            showClass: false,
            showUserInfo: false,
            showchanPin: false,
            showRiLi: false,
            showServer: false,
            showShoujizhibo: false,
            showTeacher: false,
            showIndexAd: true,
            showChouJiang:false,
            look_times: "",
            showTimeEnd:false,
			showRegRedDialog:false,
            bgc: require("@/assets/img/ys_6_1.jpg"),
        };
    },
    computed: {
        ...mapState(["djs_time", "clientType"]),
        ...mapGetters(["redcount"]),
        applyList() {
            let arr = [
                "课程安排",
                // "产品介绍",
                "服务体系",
                "财经日历",
                "名师风采",
                // "手机直播",
            ];
            let iconArr = [
                "iconfont icon-kecheng-",
                // "iconfont icon-chanpinjieshao",
                "iconfont icon-fuwu",
                "iconfont icon-rili",
                "iconfont icon-chengweijiangshi",
                "iconfont icon-shouji",
            ];
            let arr3 = [];
            let id = 1;
            for (var i = 0; i < arr.length; i++) {
                let obj = new Object();
                obj.title = arr[i];
                obj.icon = iconArr[i];
                arr3.push(obj);
                id++;
            }
            return arr3;
        },

        carouselList() {
            let imgSrc = [];
            return imgSrc;
        },

        skinList() {
            let arr = [];
            for (var i = 1; i < 7; i++) {
                let obj = new Object();
                obj.src = require(`@/assets/img/skin/ys_${i}.jpg`);
                obj.value = require(`@/assets/img/skin/ys_${i}_1.jpg`);
                arr.push(obj);
            }
            return arr;
        },
    },
    methods: {
		// showregreds
				    // 展示注册红包收益弹窗
		showregreds () {
		  this.showRegRedDialog = true
		},
         // 打开签到
        openQianDao () {
        if (this.userInfo.isYk) {
            this.isShowLogin = true;
            }else {
            this.showSignIn = true
            }
        },
        // 保存到桌面
        saveDesktop() {
            window.open("/api/saveDesktop");
        },
        // 关闭抽奖
        closeTurnTables() {
            this.showZhuanPan = false;
        },
        // 使用chat组件中的方法开发发送红包弹窗
        openChatModelsRedDialog (){
            this.$refs.chatModels.openRedDialog()
        },
        openMh () {
        if (this.userInfo.isYk) return this.isShowLogin = true;
            this.showChouJiang = true
        },
        // 打开大转盘
        async openDaZhuanPan() {
            if (this.userInfo.isYk) {
                MessageBox.alert("请注册会员后参与抽奖", "温馨提示", {
                    confirmButtonText: "联系客服",
                    callback: async () => {
                       this.$store.dispatch("getQQApi");
                    },
                });
            } else {
                const { data: res } = await getTurnTableInfoApi();
                if (res.code == 201) return this.$toast(res.msg);
                this.showZhuanPan = true;
            }
        },
        // 注册弹窗
        openReg() {
            this.isShowReg = true;
        },
        // 坐着tab栏弹窗
        showDialog(item) {
            switch (item.title) {
                case "课程安排":
                    this.showClass = true;
                    break;
                case "产品介绍":
                    this.showchanPin = true;
                    break;
                case "服务体系":
                    this.showServer = true;
                    break;
                case "财经日历":
                    this.showRiLi = true;
                    break;
                case "名师风采":
                    this.showTeacher = true;
                    break;
                // case "手机直播":
                //     this.showShoujizhibo = true;
                //     break;

                default:
                    break;
            }
        },
        // 聊天弹窗
        showChatMethods() {
            this.isShowChat = true;
        },

        headMenu2Click(id) {
            switch (id) {
                case 1:
                    this.showUserInfo = true;
    
                    break;
                case 2:
                    //  this.isShowSkin = true
                    break;
                case 3:
                    this.isShowLogin = true;
                    break;
                case 4:
                    if (this.roomInfo.is_open_reg == 0) {
                        MessageBox.alert("请联系QQ客服", "温馨提示", {
                            confirmButtonText: "确定",
                            showClose: false,
                            callback: (action) => {
                                this.lookTimeEnd = false;
                            },
                        });
                    } else {
                        this.isShowReg = true;
                    }
                    break;

                default:
                    break;
            }
        },
        // 重载页面
        reloadPage () {
            window.location.reload()
        },
        // 换肤
        checkSkin(value) {
            //             console.log(value);
            // this.$nextTick (()=>{
            // this.$refs.bgImg.style.backgroundImage = value
            // console.log(this.$refs.bgImg.style.backgroundImage);

            // })

            this.bgc = value;
        },
        // 以下方法都是弹窗操作
        closeUserInfos() {
            this.showUserInfo = false;
        },
        // 修改密码
        showChangePwds() {
            this.showChangePwd = true;
        },
        // 用户中心
        showInfoCeners() {
            this.showInfoCener = true;
        },
            openRedDialog () {
        if (this.userInfo.isYk) return this.$emit('openLogin')
        if (this.userInfo.jifen < 0) return this.$toast('积分不足')
         this.showRedDialog = true 
    },
        getLookTime(seconds) {
            let isNumber = (typeof seconds == 'number')
            if ( !isNumber) {
                this.roomInfo.video_url = "";
                this.showTimeEnd =true 
            }
            let [day, hour, minute, second] = ["00", "00", "00", "00"];
            var timer = setInterval(() => {
                if (seconds < 0) {
                    this.roomInfo.video_url = "";
                    this.showTimeEnd =true
                    clearInterval(timer);
                } else {
                    day = Math.floor(seconds / (60 * 60 * 24));
                    if (day < 10) day = `0${day}`;
                    hour = Math.floor(seconds / (60 * 60)) - day * 24;
                    if (hour < 10) hour = `0${hour}`;
                    minute =
                        Math.floor(seconds / 60) - day * 24 * 60 - hour * 60;
                    if (minute < 10) minute = `0${minute}`;
                    second =
                        Math.floor(seconds) -
                        day * 24 * 60 * 60 -
                        hour * 60 * 60 -
                        minute * 60;
                    if (second < 10) second = `0${second}`;
                    this.look_times = `剩余观看时长：${day}天 ${hour}小时${minute}分${second}秒`;
                    seconds--;
                }
            }, 1000);
        },
    },
    components: {
        chatDialog: () => import("@/components/diaLog/chatDialog2.vue"),
        login: () => import("@/components/diaLog/login.vue"),
        reg: () => import("@/components/diaLog/reg.vue"),
        chat: () => import("@/components/chat2.vue"),
        class: () => import("../components/diaLog/class.vue"),
        chanpin: () => import("../components/diaLog/chanpin.vue"),
        rili: () => import("../components/diaLog/rili.vue"),
        server: () => import("../components/diaLog/server.vue"),
        shoujizhibo: () => import("../components/diaLog/shoujizhibo.vue"),
        teacher: () => import("../components/diaLog/teacher.vue"),
        userInfo: () => import("../components/userInfo/userInfo.vue"),
        changePwd: () => import("../components/userInfo/changePwd.vue"),
        infoCenter: () => import("../components/userInfo/infoCenter.vue"),
        turnTable: () => import("../components/turnTable.vue"),
        indexDialog: () => import("../components/diaLog/indexDialog.vue"),
        sginIn: () => import("../components/diaLog/sginIn.vue"),
        chouJiang: () => import("../components/diaLog/choujiang.vue"),
		redResult: ()=>import('@/components/diaLog/redResult.vue'),
		timeEnd: ()=>import('@/components/diaLog/TimeEnd.vue'),
    },
    created() {

    },
    mounted() {
        if (!this.utoken && this.clientType == "pc") {
            MessageBox.confirm(
                "您需要登录后才能参与抽奖，您现在登录吗",
                "温馨提示",
                {
                    confirmButtonText: "确定",
                    cancelButtonText: "取消",
                    type: "warning",
                }
            )
                .then(() => {
                    this.isShowLogin = true;
                })
                .catch(() => {});
        }
    },
    watch: {
        "$store.state.djs_time": function (newVal, oldVal) {
            if (newVal) {
                this.getLookTime(newVal);
            }
        },
    },
};
</script>


<style lang="scss" scoped>
.youke {
    width: 50px;
    height: 50px;
    margin-top: -10px;
    margin-right: 10px;
}
.bg_imgs {
    width: 100%;
    height: 100%;
    margin: 0;
    top: 0;
}
.scroll_styles::-webkit-scrollbar {
    width: 7px;
    height: 7px;
    background-color: #f5f5f5;
}
.pore {
    position: relative;
}
/*定义滚动条轨道 内阴影+圆角*/
.scroll_styles::-webkit-scrollbar-track {
    box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.3);
    -webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.3);
    border-radius: 10px;
    background-color: #f5f5f5;
}

/*定义滑块 内阴影+圆角*/
.scroll_styles::-webkit-scrollbar-thumb {
    border-radius: 10px;
    box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.1);
    -webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.1);
    background-color: #c8c8c8;
}
.marsk {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100vh;
    background: rgba(0, 0, 0, 0.5);
    z-index: 99;
}

.dialog5minute {
    width: 624px;
    height: 600px;
    position: absolute;
    top: 15vh;
    left: 30%;
    z-index: 100;
}

.dialog5minute .absolute {
    position: absolute;
    left: 0;
    bottom: 0;
    width: 100%;
}

.dialog5minute .absolute .item {
    width: 50%;
    height: 85px;
    float: left;
}
.drag {
    width: 100px;
    height: 100px;
    position: absolute;
    top: 0;
    left: 0;
    background-color: red;
}
// .min_chat {
//     position: absolute;
//     left: 45%;
//     bottom: 35px;
//     transform: translateX(-50%);
//     background-color: #f5f5f5;
//     z-index: 9;
//     width: 150px;
//     box-sizing: border-box;
//     display: flex;
//     justify-content: space-between;
//     align-items: center;
//     padding: 5px 10px;
//     line-height: 40px;
//     cursor: pointer;
    
//     display: flex;
//     flex-direction: row;
//     flex-wrap: nowrap;
//     span{
//         display: inline-block;
//         text-overflow: ellipsis;
//         white-space: nowrap;
//         width:100px;
//         overflow:hidden;
//     }
// }
.min_chat {
    // position: fixed;
    // right: 0;
    // top: 30%;
    // transform: translateY(-35%);
    // background-color: #f5f5f5;
    // z-index: 9;
    // width: 60px;
    // box-sizing: border-box;
    // justify-content: space-between;
    // align-items: center;
    // padding: 5px 10px;
    // line-height: 20px;
    // cursor: pointer;
    // display: flex;
    // flex-direction: column;
    // span{
    //     word-break:break-all;
    //     display: flex;
    //     justify-content: center;
    //     width:10px;
    //     line-height: 100%;
    //     text-align: center;
    //     margin-top: 5px;
    // }
      position: fixed;
  left: 50%;
  transform: translateX(-50%);
  bottom: 30px;
  background-color: #f5f5f5;
  z-index: 9;
  width: 60px;
  box-sizing: border-box;
  align-items: center;
  padding: 5px 10px;
  line-height: 20px;
  cursor: pointer;
  display: flex;
  width: 160px;
  span {
    margin-left: 10px;
    width: 80px;
    overflow: hidden; //超出的文本隐藏
    text-overflow: ellipsis; //溢出用省略号显示
    white-space: nowrap; //溢出不换行
  }
}
.bg_list {
    display: flex;
    flex-direction: row;
    flex-wrap: wrap;
    position: relative;
}

.bg_list .item {
    margin: 10px;
    cursor: pointer;
}

.bg_list .item img {
    width: 70px;
    height: 35px;
}
.closeBtn {
    background: #fff;
    font-family: Georgia, "Times New Roman", Times, serif;
    font-size: 20px;
    width: 30px;
    height: 30px;
    display: inline-block;
    border-radius: 50%;
    text-align: center;
    line-height: 30px;
    color: #666;
    position: absolute;
    right: -18px;
    top: -16px;
    cursor: pointer;
}
.flex_box {
    cursor: pointer;
    background-color: #222d31;
    color: #fff;
    img {
        width: 45px;
        height: 45px;
        margin-right: 30px;
    }
    .item {
        padding: 10px;
        border-bottom: 1px solid #3c4049;
        display: flex;
        align-items: center;
        padding-left: 10px;
    }
}
.login_reg {
    width: 95px !important;
    height: 30px !important;
}
.save_desktop {
    font-size: 18px;
    text-align: center;
    cursor: pointer;
    color: #fff;
    font-weight: 600;
    .icon-yunzhuomian {
        font-size: 25px;
        vertical-align: middle;
    }
}
.fn35 {
    font-size: 35px;
    margin-right: 30px;
}
.is_login_f_right {
    color: white;
    display: block;
    width: auto;
    display: flex;
    /* justify-content: space-around; */
    justify-content: flex-end;
    padding-top: 20px;
    padding-right: 35px;
}
.poab_user_info {
    position: absolute;
    right: 20px;
    top: 65px;
    z-index: 9;
}
.zhuna_pai {
    position: absolute;
    left: 20%;
    top: 22%;
    z-index:10;
}
.prze_close {
    position: absolute;
    left: 55%;
    top: 25%;
    font-size: 28px;
    color: red;
}
.bottom_index{
    z-index: -99999!important;
}

    .jifen {
        background-color: #F64F47;
        color: #fff;
        display: flex;
        justify-content: center;
        align-items: center;
        padding: 3px 10px;
        height: 20px;
        width: 70px;
        border-radius: 5px;
    }
.felx_red {
    display: flex;
    flex-direction: column;
    justify-content: center;    
    align-items: center;
    box-sizing: border-box;
    padding-top: 10px!important;
    img {
        width: 40px;
    }
}
.hover_gray:hover{
    color: #777;
}
</style>