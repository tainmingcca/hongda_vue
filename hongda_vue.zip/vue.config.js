
module.exports = {
outputDir: "dist",
publicPath: "./",
assetsDir: "assets",
productionSourceMap: false,
devServer: {
  proxy: {
    "/api": {
       target: "https://hdccavide.xyz",
      ws: true,
      changeOrigin: true,
      secure: false,
      pathRewrite: {
        "^/api": "/api",
      },
      headers: {
        Referer: ''
      }
    },
  },
  open: true,
  // port: 8888,
},
};