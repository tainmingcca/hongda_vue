<?php
return [
    'accessid' => 'LTAI5tKgsM359ZSEqgaqaZsy',
    'accesskey' => 'AdbWBao1GXLf7RA8FbSrm94mlDsLfp',
    'Bucket' => 'zhibooss2',
    //'Endpoint' => 'oss-accelerate.aliyuncs.com',
    'Endpoint' => 'oss-cn-zhangjiakou.aliyuncs.com',
    'baseDir'=>'minzhong',
];