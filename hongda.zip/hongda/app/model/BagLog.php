<?php


namespace app\model;


use think\Model;

class BagLog extends Model
{
    public function user(){
        return $this->belongsTo(User::class,'uid')->bind(['mobile']);
    }

}