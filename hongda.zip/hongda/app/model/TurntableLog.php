<?php
/**
 * 中奖记录
 */

namespace app\model;

use think\Model;
class TurntableLog extends Model
{
    public function user(){
        return $this->belongsTo(User::class,'uid');
    }
}