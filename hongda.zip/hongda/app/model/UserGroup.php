<?php


namespace app\model;
use think\Model;

class UserGroup  extends Model
{
    public static function onBeforeUpdate($data)
    {
        $modelName = __CLASS__;
        $oldData = $modelName::find($data->id);
        if (strpos($oldData->group_icon, 'http') === false && $oldData->group_icon != $data->group_icon) @unlink(".{$oldData->group_icon}");
    }
    public static function onAfterUpdate($data)
    {
        (new User())->where(['user_type'=>2,'group_id'=>$data->id])->save(['group_name'=>$data->group_name,'group_icon'=>$data->group_icon]);
    }
}