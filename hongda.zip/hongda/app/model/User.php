<?php


namespace app\model;

use think\Model;


class User extends Model
{
    public static function onBeforeUpdate($data)
    {
        $modelName = __CLASS__;
        $oldData = $modelName::find($data->id);
        if (strpos($oldData->head_img, 'http') === false && $oldData->head_img != $data->head_img && strpos($oldData->head_img,'head_img.png') === false) @unlink(".{$oldData->head_img}");
    }
    
    
    public function checkToken($token)
    {
        //p($token);
        if (!empty(trim($token))) {
            $userinfo = $this->where(['sess_id' => $token])->order('id asc')->find();
            if(!empty($userinfo)) return $userinfo;
        }
        //检测同设备5秒内防止重复注册游客
        $userinfo = $this->where([
            'user_type'=>2,
            'group_id'=>1,
            'reg_ip'=>getRealIP(),
            'from_url'=>request()->domain(true),
        ])->whereBetween('create_time',[time()-5,time()])->order('id asc')->find();
        if(!empty($userinfo)) return $userinfo;
        return $this->registerYouKe();
    }
    /**
     * 注册游客
     */
    public function registerYouKe()
    {
        $roomInfo = (new Room())->where(['room_no' => env('room_no')])->field('room_no,default_bg')->find();
        $usernameCheck = true;
        do {
            $sj = random_int(3333333, 9999999);
            $user_name = "guest_" . $sj;
            $count = $this->where(['user_name' => $user_name])->count();
            if ($count <= 0) $usernameCheck = false;
        } while ($usernameCheck);
        $nick_name = "游客" . $sj;
        //获取im客服id
        $imInfo = $this->getNextIm();
        $imUid = !empty($imInfo) ? $imInfo->id : 1;
        $qqInfo = $this->getNextQQ();
        $bind_qq = !empty($qqInfo) ? $qqInfo->qq_account : '';
        $userGroupInfo = (new UserGroup())->where(['group_name' => '游客'])->find();
        $data = [
            'room_no' => $roomInfo->room_no,
            'user_bg' => $roomInfo->default_bg,
            'admin_uid' => $imUid,
            'user_name' => $user_name,
            'nick_name' => $nick_name,
            'head_img' => "/static/default/head_img.png",
            'user_type' => '2',
            'group_id' => $userGroupInfo->id,
            'group_name' => $userGroupInfo->group_name,
            'group_icon' => $userGroupInfo->group_icon,
            'look_time' => time() + $userGroupInfo->look_time * 60,
            'from_url' => request()->domain(true),
            'login_time' => time(),
            'login_ip' => getRealIP(),
            'reg_ip' => getRealIP(),
            'is_online' => 1,
            'sess_id' => createToken($user_name),
            'bind_qq' => $bind_qq,
            'user_status' => 1,
            'can_sendmsg'=>1,
            'is_robot'=>0
        ];
        $this->save($data);


        //绑定im客服
        $imInfo = $this->getNextIm();
        $imUid = !empty($imInfo) ? $imInfo->id : 1;
        if (!empty($imInfo)) {
            (new User())->where(['id' => $imUid])->update(['jd_sort' => $this->id]);
        }
        $this->admin_uid = $imUid;


        //绑定qq客服
        $qqInfo = $this->getNextQQ();
        $bind_qq = !empty($qqInfo) ? $qqInfo->qq_account : '';
        if (!empty($qqInfo)) {
            (new Qqkf())->where(['id' => $qqInfo->id])->update(['jd_sort' => $this->id]);
        }
        $this->bind_qq = $bind_qq;

        return $this;
    }

    /**
     * 获取IM客服id
     */
    public function getNextIm()
    {
        $imInfo = $this->where([
            "room_no" => env('room_no'),
            "user_type" => 1,
            "group_id" => 2,
            "user_status" => 1,
            "is_online" => 1,
            "im_auth" => 1,
        ])->field("id,nick_name,head_img")
            ->order("jd_sort asc,id asc")
            ->find();
        if (empty($imInfo)) {
            $imInfo = $imInfo = $this->where([
                "room_no" => env('room_no'),
                "user_type" => 1,
                "group_id" => 1,
            ])
                ->field("id,nick_name,head_img")
                ->find();
        }
        return !empty($imInfo) ? $imInfo : [];
    }

    /**
     * 获取qq客服id
     */
    public function getNextQQ()
    {
        $qqInfo = (new Qqkf())
            ->where(["room_no" => env('room_no'), 'is_yx' => 1])
            ->order("jd_sort asc,id asc")
            ->find();
        return !empty($qqInfo) ? $qqInfo : [];
    }
}