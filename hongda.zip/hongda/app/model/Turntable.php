<?php
/**
 * 大转盘配置
 */

namespace app\model;

use think\Model;
class Turntable extends Model
{
    protected $json = ['prize_config','prize_gailv'];
    protected $jsonAssoc = true;
    public static function onBeforeUpdate($data)
    {
        $modelName = __CLASS__;
        $oldData = $modelName::find($data->id);
        if (strpos($oldData->bg_img, 'http') === false && $oldData->bg_img != $data->bg_img) @unlink(".{$oldData->bg_img}");
    }
}