<?php


namespace app\model;

use think\Model;

class ChatMsg extends Model
{
    /**
     * 处理返回的信息
     */
    public function returnMsg($list)
    {
        if (empty($list)) {
            return [];
        }
        $newList = [];
        foreach ($list as $k => $item) {
            $newList[$k]['id'] = $item['id'];
            $newList[$k]['uid'] = $item['uid'];
            $newList[$k]['group_icon'] = imgDomain($item['group_icon']);
            $newList[$k]['content'] = strpos($item['content'], "script") === false ? htmlspecialchars_decode($item['content']) : $item['content'];
            $newList[$k]['status'] = $item['status'];
            $newList[$k]['send_time'] = date("H:i", is_numeric($item['update_time']) ? $item['update_time'] : strtotime($item['update_time']));
            $newList[$k]['nick_name'] = $item['nick_name'];
            $newList[$k]['ip'] = $item['ip'];
            //$newList[$k]['admin_nickname'] = !empty($item['admin_nickname']) ? $item['admin_nickname'] : ($item['is_true_user'] ? '真实会员' : '');
            $newList[$k]['admin_nickname'] = $item['admin_nickname'];
            $newList[$k]['admin_group_name'] = $item['admin_group_name'];
            $newList[$k]['is_true_user'] = $item['is_true_user'] ? $item['is_true_user'] : 0;
            $newList[$k]['is_red'] = $item['is_red'] ? $item['is_red'] : 0;
            $is_bao=(isset($item['is_bao']) && !empty($item['is_bao'])) ? $item['is_bao'] : 0;
            $newList[$k]['is_bao'] = $is_bao;
            if ($is_bao==1){
                $newList[$k]['remark'] = (new SendRed())->where(['id'=>$item['red_id']])->value('remark');
                $newList[$k]['is_bao_true'] = (new SendRed())->where(['id'=>$item['red_id']])->value('status');
            }
        }
        return $newList;
    }
}