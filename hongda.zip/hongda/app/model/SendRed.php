<?php


namespace app\model;


use think\Model;

class SendRed extends Model
{
    public function user(){
        return $this->belongsTo(User::class,'uid')->bind(['mobile','nick_name','head_img']);
    }

}