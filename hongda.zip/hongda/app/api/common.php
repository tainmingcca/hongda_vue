<?php
function getSocketUrl()
{
    $scheme = request()->isSsl() ? 'wss' : 'ws';
    $host = request()->host();
    return "{$scheme}://{$host}/socket.io";
}

function createToken($user_id)
{
    $token = time() . $user_id . substr(rand(10000000, 99999999), 2, 8);
    return md5($token);
}

function isYk($userinfo)
{
    if (empty($userinfo) || ($userinfo->user_type == 2 && $userinfo->group_id == 1)) {
        return true;
    }
    return false;
}

/**
 * 是否是移动端访问
 * @desc 判断是否是移动端进行访问
 * @方法三：判断是否有HTTP_USER_AGENT信息是否是手机发送的客户端标志，有则一定是移动设备。
 * @return bool
 * $Author: Zhihua_W
 */
function isMobile()
{
    if (isset ($_SERVER['HTTP_USER_AGENT'])) {
        $clientkeywords = array('nokia', 'sony', 'ericsson', 'mot',
            'samsung', 'htc', 'sgh', 'lg', 'sharp',
            'sie-', 'philips', 'panasonic', 'alcatel',
            'lenovo', 'iphone', 'ipod', 'blackberry',
            'meizu', 'android', 'netfront', 'symbian',
            'ucweb', 'windowsce', 'palm', 'operamini',
            'operamobi', 'openwave', 'nexusone', 'cldc',
            'midp', 'wap', 'mobile'
        );
        // 从HTTP_USER_AGENT中查找手机浏览器的关键字
        if (preg_match("/(" . implode('|', $clientkeywords) . ")/i", strtolower($_SERVER['HTTP_USER_AGENT']))) {
            return true;
        } else {
            return false;
        }
    } else {
        return false;
    }
}

function imgDomain($src)
{
   if(empty($src)) $src = '/static/default/head_img.png';
    elseif (strpos($src, 'http') === false) $src = request()->domain().$src;
    //$src = env('app.host') . $src;
    return $src;
}

//获取奖品
function getPrize($prize_arr)
{
    $result = [];
    //抽奖开始
    foreach ($prize_arr as $key => $val) {
        $arr[$val['id']] = $val['v'];
    }
    $rid = getRand($arr); //根据概率获取奖项id
    $res = $prize_arr[$rid - 1]; //中奖项
    $min = $res['min'];
    $max = $res['max'];
    if ($res['id'] == 7) { //七等奖
        $i = mt_rand(0, 5);
        $result['angle'] = mt_rand($min[$i], $max[$i]);
    } else {
        $result['angle'] = mt_rand($min, $max); //随机生成一个角度
    }
    $result['prize'] = $res['prize'];
    $result['index'] = $res['id']-1;
    return $result;
}

//根据概率获取奖项
function getRand($proArr)
{
    $result = '';
    //概率数组的总概率精度
    $proSum = array_sum($proArr);
    //概率数组循环
    foreach ($proArr as $key => $proCur) {
        $randNum = mt_rand(1, $proSum);
        if ($randNum <= $proCur) {
            $result = $key;
            break;
        } else {
            $proSum -= $proCur;
        }
    }
    unset ($proArr);
    return $result;
}

