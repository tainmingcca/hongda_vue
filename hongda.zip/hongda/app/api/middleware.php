<?php
// 中间件配置
return [
    \app\api\middleware\CheckIp::class
];
