<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006~2018 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: liu21st <liu21st@gmail.com>
// +----------------------------------------------------------------------
use think\facade\Route;

Route::miss(function() {
    return redirect('/');
});
Route::get('test', 'Test/index');
Route::get('index', 'index/index');
Route::post('login', 'Login/login');
Route::post('reg', 'Login/reg');
//上传
Route::post('upload', 'Index/upload')->middleware('apiAuth');
Route::post('get_oss_policy/:dir', 'Index/getOssPolicy')->middleware('apiAuth');


Route::get('getOnlineUser', 'Index/getOnlineUser');
Route::get('getQQ', 'Index/getQQ')->middleware('apiAuth');
Route::get('saveDesktop', 'Index/saveDesktop');
Route::get('getVideo', 'Index/getVideo');
Route::get('setBg', 'Index/setBg')->middleware('apiAuth');
Route::get('product', 'Index/product')->middleware('apiAuth');
Route::get('get_nav', 'Index/getNavData');
Route::get('product_page', 'Index/productPage');
Route::get('teacherList', 'Index/getTeacherList');
Route::get('zanTeacher', 'Index/zanTeacher')->middleware('apiAuth');
Route::get('getTurnTableInfo', 'Index/getTurnTableInfo')->middleware('apiAuth');
Route::post('luckDraw', 'Index/luckDraw')->middleware('apiAuth');
Route::get('userSign', 'Index/userSign')->middleware('apiAuth');
Route::get('getSignList', 'Index/getSignList')->middleware('apiAuth');
Route::get('sendMusic', 'Index/sendMusic')->middleware('apiAuth');

Route::get('get_hdmsg', 'Chat/getHdMsg')->middleware('apiAuth');
Route::post('send_hdMsg', 'Chat/sendHdMsg')->middleware('apiAuth');
Route::post('contextMenu', 'Chat/contextMenu')->middleware('apiAuth');




Route::get('im_friendList', 'Im/getFriendList')->middleware('apiAuth');
Route::get('im_historyMsg', 'Im/getHistoryMsg')->middleware('apiAuth');
Route::post('im_sendMsg', 'Im/sendMsg')->middleware('apiAuth');
Route::rule('im_setWelcomeMsg', 'Im/changeWelcomeMsg','get|post')->middleware('apiAuth');
Route::get('im_getKjhf', 'Im/getKjhf')->middleware('apiAuth');
Route::post('im_addKjhf', 'Im/addKjhf')->middleware('apiAuth');
Route::get('im_delKjhf', 'Im/delKjhf')->middleware('apiAuth');



Route::post('editPass', 'User/editPass')->middleware('apiAuth');
Route::post('profile', 'User/profile')->middleware('apiAuth');
Route::post('changeImg', 'User/changeImg')->middleware('apiAuth');
Route::post('sendRedBag', 'User/sendRedBag')->middleware('apiAuth');
Route::get('shouRedBao', 'User/shouRedBao')->middleware('apiAuth');
Route::get('redBagLog', 'User/redBagLog')->middleware('apiAuth');
Route::get('getUserBagLog', 'User/getUserBagLog')->middleware('apiAuth');
Route::get('getUserInfo', 'User/getUserInfo')->middleware('apiAuth');
Route::get('logOut', 'User/logOut');


