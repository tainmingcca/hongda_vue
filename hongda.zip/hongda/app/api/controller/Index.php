<?php

namespace app\api\controller;

use app\model\AdminGroup;
use app\model\AdList;
use app\model\Notice;
use app\model\Teacher;
use app\model\Turntable;
use app\model\TurntableLog;
use app\model\Qqkf;
use app\model\TeacherZan;
use app\model\User;
use app\service\Aliyunoss;
use app\exception\ErrorException;
use app\model\Sign;
use GatewayClient\Gateway;


class Index extends Base
{
    public function __construct()
    {
        parent::__construct();
        Gateway::$registerAddress = config('gateway_worker.registerAddress');
    }
    public function index()
    {
        
        $userToken = request()->header("token", "");
        $userInfo = (new User())->checkToken($userToken);
        //p($userInfo->toArray());
        if ($userInfo->user_status != '1') throw new ErrorException(['msg' => "账户已被停用，请联系客服"]);
        $userInfo['head_img'] = imgDomain($userInfo['head_img']);
        $userInfo['group_icon'] = imgDomain($userInfo['group_icon']);
        // $userInfo['user_bg'] = imgDomain($userInfo['user_bg']);
        $userInfo['user_bg'] = $this->room->default_bg;
        //判断用户是否是游客，并复制
        $userInfo->isYk = isYk($userInfo);
        $userInfo->is_login_admin = 0;//用户是否可以登录后台
        $userInfo->is_audit = 0;//用户是否有审核互动信息的权限
        if ($userInfo->user_type == 1) {
            $groupInfo = (new AdminGroup())->find($userInfo->group_id);
            $userInfo->is_login_admin = $groupInfo->is_login_admin;
            $userInfo->is_audit = $groupInfo->is_audit;
        }
        //处理直播视频观看问题
        //echo('<script>alert("免费观看时间已用完，请注册成为会员继续观看!");</script>');
        //echo('<script>alert("观看时间已用完，请联系客服处理!");</script>');
        if ($userInfo->user_type == 2) {
            $chaTime = $userInfo->look_time - time();
            $userInfo->djs_time = $chaTime;
            if ($chaTime <= 0) {
                $this->room->video_url = "";
                $userInfo->djs_time = 0;
            }else{
                
                // $this->room->video_url = '<iframe height="498" width="510" src="'.url("Index/getVideo",['id'=>$userInfo->id]).'" frameborder="0" allowfullscreen="true"></iframe>';
                $this->room->video_url = '<iframe height="498" width="510" src="https://open.talk-fun.com/liveout.php?code=eyJyb29taWQiOiIxMjUyOTcxIiwic2lnbiI6IjZjMzI0YTkxYjYzNTNmNDdhMjUyYmMyZmQyMmViMWY3In0=" frameborder="0" allowfullscreen="true"></iframe>';
            }
        } else {
            $userInfo->djs_time = 365*24*60*60;
            
            //$this->room->video_url = strpos($this->room->video_url, '[uid]') === false ? $this->room->video_url : str_replace('[uid]', $userInfo->id, $this->room->video_url);
            // $this->room->video_url = '<iframe height="498" width="510" src="'.url("Index/getVideo",['id'=>$userInfo->id]).'" frameborder="0" allowfullscreen="true"></iframe>';
            $this->room->video_url = '<iframe height="498" width="510" src="https://open.talk-fun.com/liveout.php?code=eyJyb29taWQiOiIxMjUyOTcxIiwic2lnbiI6IjZjMzI0YTkxYjYzNTNmNDdhMjUyYmMyZmQyMmViMWY3In0=" frameborder="0" allowfullscreen="true"></iframe>';
        }
        unset($userInfo['passwd']);


        //获取机器人
        $robotList = [];
        if ($userInfo->user_type == 1) {
            $robotList = (new User)->where(['room_no' => $this->room_no, 'admin_uid' => $userInfo->id, 'is_robot' => '1'])
                ->field('id,nick_name,group_name')
                ->cache("robotList{$userInfo->id}", 24 * 3600)
                ->order('group_id desc')->select();
        }
        //获取banner
        $bannerList = (new AdList())->where(['room_no' => $this->room_no, 'is_show' => 1])->cache('banner', 24 * 3600)->select();
        foreach ($bannerList as $item) $item->ad_url = imgDomain($item->ad_url);

        //获取公告
        $notice = (new Notice())->where(['room_no' => $this->room_no])->order('id desc')->cache('notice', 24 * 3600)->value('content');

        //获取讲师
        $teacherImg = (new Teacher())->where(['room_no' => $this->room_no,'is_recommend'=>1])->order('update_time desc')->cache('teacher', 24 * 3600)->value('intro_img');

        //获取交易数据
        $tradeData = (new \app\model\Room())->where(['room_no' => $this->room_no])->value('trade_data');
        $tradeData = explode("\n", $tradeData);
        $tradeList = [];
        $temp = [];
        foreach ($tradeData as $k => $item) {
            if ($k > 0 && $k % 4 == 0) {
                $tradeList[] = $temp;
                $temp=[];
            }
            $temp[] = $item;
        }
        $tradeList[] = $temp;
        $tradeList[] = $temp;
        $is_button=0;
        if ($userInfo['user_type']==1)  $is_button=1;
        // $userInfo['invitation_url']= request()->domain(true)."/#/register?invitation=".$userInfo['invitation'];
        $userInfo['invitation_url']= request()->domain(true)."?invitation=".$userInfo['invitation'];
        return json(['code' => 200, 'msg' => 'ok', 'data' => [
            'roomInfo' => $this->room,
            'robotList' => $robotList,
            'bannerList' => $bannerList,
            'notice' => $notice,
            'tradeList'=>$tradeList,
            'userInfo' => $userInfo,
            'teacherImg' => imgDomain($teacherImg),
            'turnopen'=>(new Turntable())->where(['room_no' => $this->room_no])->value('is_open'),
        ]]);
    }
    public function getVideo($id){
        $userId=intval($id);
        if(empty($userId)) return "";
        $host = request()->server('http_host');
        $origin = request()->server('http_referer');
        $arr = parse_url($origin);
        if(!isset($arr['host']) || empty($arr['host']) || $host!==$arr['host']) return "";
        //p($this->userinfo);
        $videoUrl = strpos($this->room->video_url, '[uid]') === false ? $this->room->video_url : str_replace('[uid]', $userId, $this->room->video_url);
        preg_match('/<iframe[^>]*\s+src="([^"]*)"[^>]*>/is', $videoUrl, $matched);
        return file_get_contents($matched[1]);
    }

    //获取在线用户列表
    public function getOnlineUser()
    {
        $where = [
            'room_no' => $this->room_no,
            'user_type' => '2',
            'is_online' => '1',
            'is_robot' => '0',
        ];
        $count = (new User())->where($where)->count();
        $list = (new User)->where($where)
            ->field("id,nick_name,head_img,user_type,group_icon")
            // ->limit(100)
            ->order("is_online desc,update_time desc")
            //->cache(2 * 3600)
            ->select();
        foreach ($list as $item) {
            $item['head_img'] = imgDomain($item['head_img']);
        }
        $totalUser = $this->room->online_num + $count;
        return json(['code' => 200, 'msg' => 'ok', 'data' => ['list' => $list, 'totalUser' => $totalUser]]);
    }


    //获取客服qq
    public function getQQ()
    {
        // if (empty($this->userinfo->bind_qq)) {
        //     $kfInfo = (new User)->getNextQQ();
        // } else {
        //     //检查客服qq有没有被删除了
        //     $kfInfo = (new Qqkf())->where(['qq_account' => $this->userinfo->bind_qq])->find();
        //     if (empty($kfInfo)) $kfInfo = (new User)->getNextQQ();
        // }
        // if (empty($kfInfo)) throw new ErrorException(['msg' => "很抱歉，当前暂无客服在线"]);
        // $this->userinfo->save(['bind_qq' => $kfInfo->qq_account]);

        $kfInfo = (new User)->getNextQQ();
        if (empty($kfInfo)) throw new ErrorException(['msg' => "很抱歉，当前暂无客服在线"]);
        return json(['code' => 200, 'msg' => 'ok', 'data' => $kfInfo->qq_account]);
    }


    //保存桌面
    public function saveDesktop()
    {
        header('Content-type: text/html');
        header('Content-Disposition: attachment; filename="' . $this->room->room_name . '.html"');
        exit('<script language="javascript">location.href="' . $this->room->main_domain . '";</script>');
    }

    //设置皮肤
    public function setBg()
    {
        $num = request()->post('num/s', '');
        $src = $this->room->default_bg;
        if (!empty($num) && in_array($num, [1, 2, 3, 4, 5, 6, 7, 8])) {
            $src = "/static/index/bg/ys_{$num}.jpg";
        }
        $user_id = $this->userinfo->id;
        (new User)->cache("userInfo{$user_id}")->where(['id' => $user_id])->update(['user_bg' => $src]);
        return json(['code' => 200, 'msg' => 'ok', 'data' => []]);
    }

    //获取教师列表
    public function getTeacherList()
    {
        $list = (new Teacher())->where(['room_no' => $this->room_no])->select();
        return json(['code' => 200, 'msg' => 'ok', 'data' => $list]);
    }

    //老师点赞
    public function zanTeacher($id)
    {
        $id = request()->param('id/d', 0);
        if (empty($id)) throw new ErrorException(['msg' => "参数错误"]);
        if ($this->userinfo->isYk) throw new ErrorException(['msg' => "很抱歉，系统不允许游客点赞，请登录"]);
        $info = (new TeacherZan())->where([
            "uid" => $this->userinfo->id,
            "teacher_id" => $id
        ])->whereDay("create_time")->find();
        if (!empty($info)) throw new ErrorException(['msg' => "您今天已经点过赞了，请不要重复点赞"]);
        $teacherInfo = (new Teacher())->where(['id' => $id, 'room_no' => $this->room_no])->find();
        $teacherInfo->zan_nums++;
        $teacherInfo->save();
        $res = (new TeacherZan())->save([
            'room_no' => $this->room_no,
            "uid" => $this->userinfo->id,
            "teacher_id" => $id
        ]);
        if ($res !== false) return json(['code' => 200, 'msg' => "点赞成功，感谢您的支持", 'data' => $teacherInfo->zan_nums]);
        throw new ErrorException(['msg' => "啊哦，点赞失败了，请刷新页面重新来一次"]);
    }

    //获取左侧导航
    public function getNavData()
    {
        $type = request()->param('type/s', '');
        if (!empty($type)) {
            if ($type == 'kcb') {
                return json(['code' => 200, 'msg' => '', 'data' => ['type' => 'img', 'url' => imgDomain($this->room->kcb_url)]]);
            }
            if ($type == 'product') {
                return json(['code' => 200, 'msg' => '', 'data' => ['type' => 'iframe', 'url' => (string)url('Index/productPage')]]);
            }
            if ($type == 'service') {
                return json(['code' => 200, 'msg' => '', 'data' => ['type' => 'img', 'url' => imgDomain('/static/theme1/images/fwtx.png')]]);
            }
            if ($type == 'caijing') {
                return json(['code' => 200, 'msg' => '', 'data' => ['type' => 'iframe', 'url' => 'https://rili-d.jin10.com/open.php?new=0.012113788980271378']]);
            }
        }
        throw new ErrorException(['msg' => "参数错误"]);
    }

    public function productPage()
    {
        return view('pages/product');
    }

    //获取大转盘、中奖记录信息
    public function getTurnTableInfo()
    {
        
        $turntableInfo = (new Turntable())->find(1);
        $turntableInfo->bg_img = imgDomain($turntableInfo->bg_img);
        if ($turntableInfo->is_open == 0) throw new ErrorException(['msg' => "大转盘处于关闭状态，请联系客服了解开放时间！"]);
        //历史中奖记录
        //$prizeList = (new TurntableLog())->limit(50)->select();
        //$prizeList = (new TurntableLog())->hasWhere('user', ['user_type' => 2])->limit(50)->select();
        $key = env('cache_redis.prefix', '') . 'prizeList';
        $prizeList = cache($key);
        if (empty($prizeList)) {
            $prizeList = [];
            $robotList = (new User())->where([['is_robot', '=', 1], ['group_id', '>', 1]])->field('id,nick_name')->select();
            foreach ($robotList as $k => $item) {
                $nums = mt_rand(0, count($turntableInfo->prize_config) * 2);
                $prizeList[] = [
                    'nick_name' => $item->nick_name,
                    'prize' => $turntableInfo->prize_config[$nums] ?? '[谢谢参与]',
                ];
            }
            cache($key, $prizeList, 12 * 60 * 60);
        }
        return json(['code' => 200, 'msg' => 'ok', 'data' => ['turntableInfo' => $turntableInfo, 'prizeList' => $prizeList]]);
    }

    //抽奖方法
    public function luckDraw()
    {
        
        $turntableInfo = (new Turntable())->find(1);
        //halt($turntableInfo->toArray());
        if ($turntableInfo->is_open == 0) throw new ErrorException(['msg' => "大转盘处于关闭状态，请联系客服了解开放时间！"]);
        //今天是否抽奖过了
         $userPrizeLog = (new TurntableLog())->where(['room_no' => $this->room_no, 'uid' => $this->userinfo->id])->whereDay("create_time")->find();
        //$userPrizeLog = (new TurntableLog())->where(['room_no' => $this->room_no, 'uid' => $this->userinfo->id])->find();
        if (!empty($userPrizeLog)) throw new ErrorException(['msg' => "您已经抽过奖！"]);


        //获取奖品并初始化
        $prize_arr = [];
        foreach ($turntableInfo->prize_config as $k => $item) {
            $prize_arr[$k] = [
                'id' => $k + 1,
                'min' => ($k + 1) * 30 - 20,
                'max' => ($k + 1) * 30 - 10,
                'prize' => $item,
                'v' => mt_rand(1, mt_rand(20, 50))
            ];
            if ($turntableInfo->prize_gailv[$k] == 0) $prize_arr[$k]['v'] = 0;
        }
    
        try {
            $data['info'] =[
                'nick_name' => $this->userinfo->nick_name,
                'mobile' => $this->userinfo->mobile,
                'user_qq' => $this->userinfo->user_qq,
                'create_time' => date("Y-m-d H:i:s")
            ];
            $prizeLog = [
                'room_no' => $this->room_no,
                'uid' => $this->userinfo->id,
                'nick_name' => $this->userinfo->nick_name,
                'mobile' => $this->userinfo->mobile,
                'user_qq' => $this->userinfo->user_qq,
            ];
            if ($this->userinfo->prize_id=== null){
                $result = getPrize($prize_arr);
                $prizeLog['prize'] = $result['prize'];
                $data['index'] =  $result['index'] - 1;
                $data['prize'] =   $result['prize'];
                $data['angle'] =  $result['angle'];
            }else{
                $data['index'] = $this->userinfo->is_prize - 1;
                $data['prize'] =   $this->userinfo->yu_prize;
                $data['angle'] =  20;
                $prizeLog['prize'] = $turntableInfo['prize_config'][$this->userinfo->prize_id];
            }
            $res = (new TurntableLog())->save($prizeLog);
            if ($res) return json(['code' => 200, 'msg' => "", 'data' =>$data]);
        } catch (\Exception $e) {
            throw new ErrorException(['msg' => "系统开小差了，请您再次尝试"]);
        }
    }
    
      /*
     * 用户签到
     */
    public function userSign(){
       
        if ($this->userinfo->isYk) throw new ErrorException(['msg' => "很抱歉，系统不允许游客签到，请登录"]);
        $info = (new Sign())->where([
            "uid" => $this->userinfo->id,
            "room_no" => env('room_no')
        ])->whereDay("create_time")->find();
        if (!empty($info)) throw new ErrorException(['msg' => "您今天已经签到过，请不要重复签到"]);
        $rule = (new Sign())->save([
            "uid" => $this->userinfo->id,
            "mobile" => $this->userinfo->mobile,
            "nick_name" => $this->userinfo->nick_name,
            "room_no" => env('room_no'),
            "moth" => date('m',time()),
            "day" => date('d',time()),
        ]);
        if ($rule!= false)  return json(['code' => 200, 'msg' => '签到成功', 'data' => ['money'=>10]]);
        throw new ErrorException(['msg' => "签到失败,请联系管理"]);
    }
    /*
     * 签到列表
     */
    public function getSignList(){
        $user_id =$this->userinfo->id;
        $moth = date('m',time());
        $list = (new Sign())->where(['uid'=>$user_id,'moth'=>$moth])->select();
        return json(['code' => 200, 'msg' => 'ok', 'data' => $list]);
    }
     /*
    播放语音
    */
    public function sendMusic(){
        $type = request()->get('type/d',0); //播放语音选择
        if ($type==0)throw new ErrorException(['msg'=>"非法请求"]);
        if (  $this->userinfo->group_id  !=1  && $this->userinfo->group_id  !=3) throw new ErrorException(['msg'=>"您当前没有播放权限"]);
        Gateway::sendToAll(json_encode([
            'type' => 'audio',
            'data' => ['type'=>$type]
        ]));
        return json(['code' => 200, 'msg' => '播放成功']);
    }

    //oss上传策略
    public function getOssPolicy()
    {
        $dir = request()->param("dir/s", 'temp');
        $aliyunoss = new Aliyunoss();
        $res = $aliyunoss->aliossPolicy($dir);
        return json(['code' => 200, 'msg' => 'ok', 'data' => $res]);
    }
     public function upload()
    {
         //p($this->userinfo->user_type);
        // exit;
       
       
        
         if($this->userinfo->user_type == 2) throw new ErrorException(['msg' => "参数错误"]);
        
        if (!request()->isPost()) throw  new ErrorException(['msg' => "参数错误"]);
        $files = request()->file('file');
         $dir = request()->param('dir','temp');
        try {
            validate(['file' => 'fileSize:2048000|fileExt:jpg,jpeg,gif,png'])->check(['file' => $files]);
            $savename = \think\facade\Filesystem::disk('public')->putFile($dir, $files);
            if (empty($savename)) throw  new ErrorException(['msg' => '上传失败']);
            if ($dir == 'im') return json(['code' => 0, 'msg' => '上传成功', 'data' => ['src' => "/upload/" . $savename]]);
            return json(['code' => 200, 'msg' => '', 'data' => ['src' => "/upload/" . $savename]]);
        } catch (\think\exception\ValidateException $e) {
            throw  new ErrorException(['msg' => $e->getMessage()]);
        }
    }
}
