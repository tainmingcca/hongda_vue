<?php


namespace app\api\controller;

use app\model\ImMsg;
use think\facade\Cache;
use app\exception\ErrorException;
use app\model\ChatMsg;
use app\model\User;
use app\model\Imkjhf;
use GatewayClient\Gateway;

class Im extends Base
{
    public function __construct()
    {
        parent::__construct();
        Gateway::$registerAddress = config('gateway_worker.registerAddress');
    }

    public function getFriendList()
    {
        $field = 'id,nick_name,head_img,is_online,login_ip';
        
        if ($this->userinfo->user_type != 1) {
            $where = ['id' => $this->userinfo->admin_uid];
            if ($this->userinfo->admin_uid <= 0) {
                $where = ['room_no' => $this->room_no, 'user_type' => 1, 'group_id' => 1];
            }
            $chatList = (new User)->where($where)->field($field)->select();
            foreach ($chatList as $k => $item) {
                //$item->is_online = 0;
                $item->head_img = imgDomain($item->head_img);
                $item->noReadCount = (new ImMsg())->where([
                    ['send_uid', '=', $item->id],
                    ['receive_uid', '=', $this->userinfo->id],
                    ['is_read', '=', 0]
                ])->count();
                $item->sign = "1.32.251.255 香港 香港移动";
                unset($item['login_ip']);
            }
        } else {
            $uidList = Gateway::getAllUidList();
            $uids = array_values($uidList);
            $chatList = (new User)->where(['admin_uid' => $this->userinfo->id])
                ->whereIn('id',$uids)
                ->field($field)
                ->order('is_online desc,update_time desc')
                // ->limit(300)
                ->select();
            //$chatList->update(['is_online' => 1]);
            foreach ($chatList as $k => $item) {
                $item->is_online = 1;
                $item->head_img = imgDomain($item->head_img);
                $item->noReadCount = (new ImMsg())->where([
                    ['send_uid', '=', $item->id],
                    ['receive_uid', '=', $this->userinfo->id],
                    ['is_read', '=', 0]
                ])->count();
                $hdNums = false ? (new ChatMsg())->where(['uid' => $item->id])->count():0;
                $item->sign = "{$hdNums}条；{$item->login_ip}";
                unset($item['login_ip']);
            }
            $chatList = array_values($chatList->order('noReadCount','desc')->toArray());
        }
        return json(['code' => 200, 'msg' => 'ok', 'data' => $chatList]);
    }

    /**
     * 获取历史消息
     */
    public function getHistoryMsg()
    {
        $userId = $this->userinfo->id;
        $friendId = request()->param("friend_id/d", 0);
        $lastTime = request()->param("last_time", 0);
        if (empty($lastTime)) $lastTime = time();
        if (empty($friendId)) return json(['code' => 201, "msg" => '没有聊天对象', "data" => []]);
        //消息已读
        (new ImMsg())->where([
            ["send_uid", "=", $friendId],
            ["receive_uid", "=", $userId],
        ])->save(['is_read' => 1]);

        $list = (new ImMsg())->where([
            ['create_time', "<", $lastTime]
        ])->where(function ($query) use ($userId, $friendId) {
            $query->whereOr([
                [
                    ["send_uid", "=", $userId],
                    ["receive_uid", "=", $friendId],
                ], [
                    ["send_uid", "=", $friendId],
                    ["receive_uid", "=", $userId],
                ]
            ]);
        })->field('send_uid,send_nickname,content,is_read,msg_type,create_time')
            ->order("create_time desc")->limit(10)->fetchSql(false)->select();
        // halt($list);
        $send_headimg = (new User())->where(['id' => $friendId])->value("head_img");
        $send_headimg = imgDomain($send_headimg);
        foreach ($list as $item) {
            if ($item->send_uid != $userId) $item->send_headimg = $send_headimg;
            $item->last_time = $item->getData("create_time");
        }
        return json(['code' => 200, "msg" => "ok", "data" => $list]);
    }

    //发送聊天消息
    public function sendMsg()
    {
        $userId = $this->userinfo->id;
        $friendId = request()->param("friend_id", 0, 'intval');
        $content = request()->param("content", "", "htmlspecialchars,strip_tags");
        $msg_type = request()->param("msg_type", 1, 'intval');
        if (empty($friendId)) return json(['code' => 201, "msg" => '没有聊天对象', "data" => []]);
        if (empty($content)) return json(['code' => 201, "msg" => '发送内容为空', "data" => []]);
        if ($userId == $friendId) return json(['code' => 201, "msg" => '不能给自己发送消息', "data" => []]);

        $userInfo = (new \app\model\User())->where(['id' => $userId])->field("id,nick_name,head_img")->find();
        $friendInfo = (new \app\model\User())->where(['id' => $friendId])->field("id,nick_name,head_img")->find();

        //消息已读
        (new ImMsg())->where([
            ["send_uid", "=", $friendId],
            ["receive_uid", "=", $userId],
        ])->save(['is_read' => 1]);

        //插入聊天记录
        $msgId = (new ImMsg())->insertGetId([
            'room_no' => $this->room_no,
            'send_uid' => $userId,
            'send_nickname' => $this->userinfo->nick_name,
            'receive_uid' => $friendId,
            'receive_nickname' => $friendInfo->nick_name,
            'content' => $content,
            'user_type' => $this->userinfo->user_type,
            "is_read" => 0,
            "msg_type" => $msg_type,
            'create_time' => time()
        ]);
        if ($msgId) {
            //发送socket消息
            Gateway::sendToUid($friendId, json_encode([
                'type' => 'imMsg',
                'data' => [
                    'send_uid' => $userId,
                    'send_nickname' => $userInfo->nick_name,
                    'send_headimg' => $userInfo->head_img,
                    'content' => $content,
                    'msg_type' => $msg_type,
                    'create_time' => date("Y-m-d H:i:s"),
                    'last_time' => time(),
                ]
            ]));
            return json(['code' => 200, "msg" => "success", "data" => []]);
        }
        return json(['code' => 201, "msg" => '发送失败', "data" => []]);
    }


    /**
     * 修改默认欢迎语言
     */
    public function changeWelcomeMsg()
    {
        if ($this->userinfo->user_type != 1) throw new ErrorException(['msg' => "非法请求"]);
        if (request()->isPost()) {
            $content = request()->post('content', '', 'trim,htmlspecialchars');
            $res = (new Imkjhf())->where(['uid' => $this->userinfo->id, 'type' => 1, 'room_no' => $this->room_no])->update(['content' => $content]);
            if ($res !== false) return json(['code' => 200, 'msg' => "保存成功", 'data' => []]);
            throw new ErrorException(['msg' => "保存失败"]);
        }
        if(request()->isGet()){
            $info = (new Imkjhf())->where(['uid' => $this->userinfo->id, 'type' => 1, 'room_no' => $this->room_no])->find();
            if (empty($info)) {
                $content = '';
                (new Imkjhf())->save(['room_no' => $this->room_no, 'uid' => $this->userinfo->id, 'type' => 1, 'content' => $content]);
            } else {
                $content = htmlspecialchars_decode($info->content);
            }
            return json(['code' => 200, 'msg' => 'ok', 'data' => $content]);
        }
    }

    /**
     * 获取快捷回复
     */
    public function getKjhf()
    {
        if ($this->userinfo->user_type != 1) throw new ErrorException(['msg' => "非法请求"]);
        $list = (new Imkjhf())->where(['uid' => $this->userinfo->id, 'type' => 2, 'room_no' => $this->room_no])->select();
        return json(['code' => 200, 'msg' => 'ok', 'data' => $list]);
    }

    /**
     * 添加快捷回复
     */
    public function addKjhf()
    {
        if ($this->userinfo->user_type != 1) throw new ErrorException(['msg' => "非法请求"]);
        $content = request()->post('content', '', 'trim,htmlspecialchars');
        $data = ['room_no' => $this->room_no, 'uid' => $this->userinfo->id, 'type' => 2, 'content' => $content];
        $res = (new Imkjhf())->save($data);
        if ($res !== false) return json(['code' => 200, 'msg' => "保存成功", 'data' => []]);
        throw new ErrorException(['msg' => "保存失败"]);
    }

    /**
     * 删除快捷语句
     */
    public function delKjhf()
    {
        $id = request()->param('id/d',0);
        if (empty($id)) throw new ErrorException(['msg' => "参数错误"]);
        if ($this->userinfo->user_type != 1) throw new ErrorException(['msg' => "非法请求"]);
        (new Imkjhf())->where(['id' => intval($id)])->delete();
        return json(['code' => 200, 'msg' => 'ok', 'data' => []]);
    }
}