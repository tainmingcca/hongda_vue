<?php


namespace app\api\controller;

use app\exception\ErrorException;
use app\exception\SuccessException;
use app\model\BagLog;
use app\model\ChatMsg;
use app\model\ImMsg;
use app\model\SendRed;
use think\Cache;
use think\facade\Db;
use GatewayClient\Gateway;
use think\Model;
class User extends Base
{
    public function __construct()
    {
        parent::__construct();
        Gateway::$registerAddress = config('gateway_worker.registerAddress');
    }
    //修改密码
    public function editPass()
    {
        $pwd = request()->post('pwd', '');
        $pwd1 = request()->post('pwd1', '');
        $pwd2 = request()->post('pwd2', '');
        if (strlen($pwd) < 6 || strlen($pwd1) < 6 || strlen($pwd2) < 6) throw new ErrorException(['msg' => "密码格式错误"]);
        if ($pwd == $pwd1) throw new ErrorException(['msg' => "新密码和原密码一样，无需修改"]);
        if (md5($pwd1) != md5($pwd2)) throw new ErrorException(['msg' => "两次输入的新密码不一致"]);
        $passwd = (new \app\model\User())->where(['id' => $this->userinfo->id])->value("passwd");
        if ($passwd != md5($pwd)) throw new ErrorException(['msg' => "原始密码错误"]);
        $this->userinfo->passwd = md5($pwd1);
        $res = $this->userinfo->save();
        if ($res !== false) return json(['code' => 200, 'msg' => '修改成功，再次登录需要使用新密码', 'data' => []]);
        throw new ErrorException(['msg' => "修改密码失败"]);
    }


    //修改个人资料
    public function profile()
    {
        $user_sex = request()->post("user_sex", "男");
        $user_qq = request()->post("user_qq", "");
        $this->userinfo->user_sex = $user_sex;
        $this->userinfo->user_qq = $user_qq;
        $res = $this->userinfo->save();
        if ($res !== false) return json(['code' => 200, 'msg' => '保存成功', 'data' => []]);
        throw new ErrorException(['msg' => "保存失败"]);
    }

    //更换头像
    public function changeImg()
    {
        if (request()->isPost()) {
            $id = request()->post('id', 0, 'intval');
            $info = (new Headimg())->find($id);
            $this->userinfo->head_img = $info->img_url;
            $res = $this->userinfo->save();
            if ($res !== false) {
                return json(['code' => 200, 'msg' => '保存成功', 'data' => []]);
            } else {
                throw new ErrorException(['msg' => "保存失败"]);
            }
        }
        $imgList = (new Headimg())->where(['is_use' => 1])->select();
        View::assign("imgList", $imgList);
        return View::fetch();
    }

    //退出登录
    public function logOut()
    {
        // p($this->userinfo);
        // $this->userinfo->save(['is_online' => 0]);
        return json(['code' => 200, 'msg' => '已经安全退出']);
    }
    /*
     * 用户发送红包
     */
    public function sendRedBag(){
        $moeny = request()->post('money',0);
        $num = request()->post('num',1);
        $robot_id = request()->post('robot_id/d',1);  //机器人ID
        $remark = request()->post('remark/s','');
        $this->userinfo->isYk = isYk($this->userinfo);
        if ($this->userinfo->isYk) throw new ErrorException(['msg'=>"游客不能发送红包,请登陆后再试!"]);
        if ($moeny < 1) throw new ErrorException(['msg'=>'红包金额最少不能低于1元']);
        if ($num < 1) throw new ErrorException(['msg'=>'红包个数最少不能低于1位']);
         $totalMoney = bcmul($moeny,$num,2);
        if ($this->userinfo->jifen < $totalMoney) throw new ErrorException(['msg'=>'积分不足']);
        $userNickName = $this->userinfo->nick_name;
        if (!empty($robot_id)){
            $userNickName = (new \app\model\User())->where(['id'=>$robot_id])->value('nick_name');
        }
        $data = [
            'room_no'=>env('room_no'),
            'uid'=>$robot_id ? $robot_id : $this->userinfo->id,
            'money'=>$totalMoney,
            'num'=>$num,
            'remark'=>htmlspecialchars($remark),
        ];
        // 启动事务
        Db::startTrans();
        try {
            $sendRedModel = (new SendRed());
            $sendRedModel->save($data);
            $this->userinfo->jifen = $this->userinfo->jifen -$totalMoney;
            $this->userinfo->save();
            $msg=[
                'room_no' => env('room_no'),
                'uid' => $robot_id ? $robot_id : $this->userinfo->id,
                'nick_name' => $userNickName,
                'group_icon' => $this->userinfo->group_icon,
                'admin_nickname' => $this->userinfo->user_type == 1 ? $this->userinfo->nick_name : '',
                'admin_group_name' => $this->userinfo->group_name,
                'from_app' => isMobile() ? "WAP" : 'PC',
                'ip' => getRealIP(),
                'status' => 1,
                'content' => '',
                'is_true_user' => 1,
                'is_red' => 0,
                'red_id' => $sendRedModel->id,
                'is_bao' => 1,
            ];
            $icon=( new \app\model\User())->where(['id'=>$msg['uid']])->value('group_icon');
            $msg['group_icon'] = $icon;
            $cashMsg =  new ChatMsg();
            $cashMsg->save($msg);
            $msg['create_time'] = time();
            $msg['update_time'] = time();
            $msg['send_time'] = date("H:i");
            $msg['id'] = $cashMsg->id;
            $msg['remark'] = htmlspecialchars($remark);
            Gateway::sendToAll(json_encode([
                'type' => 'hd_msg',
                'data' => $msg
            ]));
            // 提交事务
            Db::commit();
        } catch (\Exception $e) {
            // 回滚事务
            Db::rollback();
            throw new ErrorException(['msg'=>$e->getMessage()]);
        }
        return json(['code'=>200,'msg'=>"发送成功"]);
    }
    /*
     * 用户领取红包
     */
    public function shouRedBao()
    {
        $id = request()->get('id/d',1);
        $robot_id = request()->get('robot_id/d',1);  //机器人ID
        $this->userinfo->isYk = isYk($this->userinfo);
        if ($this->userinfo->isYk) throw new ErrorException(['msg'=>"游客不能抢红包!请登陆后再试"]);
        $chaMsgInfo = (new ChatMsg())->where(['id'=>$id])->field('id,red_id')->find();
        $redBaoInfo = (new SendRed())->where(['id'=>$chaMsgInfo['red_id']])->find();
        if (empty($redBaoInfo)) throw new ErrorException(['msg'=>"系统错误!"]);
        if ($redBaoInfo['status']==1)  return json(['code'=>202,'msg'=>'红包已领完','data'=>$redBaoInfo['id']]);
        $key = "hongbao_".$redBaoInfo['id'];
        $counLog = (new BagLog())->where(['red_id'=>$redBaoInfo['id']])->count();
        $getUserBaoInfo = (new BagLog())->where(['red_id'=>$redBaoInfo['id'],'uid'=>$this->userinfo->id])->find();
        if (!empty($getUserBaoInfo))  return json(['code'=>201,'msg'=>'您已领取','data'=>$getUserBaoInfo['money'],'id'=>$redBaoInfo['id']]);
        if ($counLog == $redBaoInfo['num']) {
            $redBaoInfo->status= 1;
            $redBaoInfo->save();
            $userBao=(new BagLog())->where(['red_id'=>$redBaoInfo['id'],'uid'=>$this->userinfo->id])->value('money');
            return json(['code'=>201,'msg'=>'ok','data'=>$userBao]);
        }
        $randBao= \think\facade\Cache::store('redis')->get($key);
        if (empty($randBao)){
            $rule = $this->rand_section($redBaoInfo['money'],$redBaoInfo['num']);
            \think\facade\Cache::store('redis')->set($key,$rule);
            $randBao= \think\facade\Cache::store('redis')->get($key);
        }
        $count = count($randBao);

        $money=0;
        if ($count > 1){
            $money =$randBao[$count];
            unset($randBao[$count]);
            \think\facade\Cache::store('redis')->set($key,$randBao);
        }elseif($count==1){
            $money =$randBao[$count];
            unset($randBao[$count]);
            \think\facade\Cache::store('redis')->set($key,$randBao);
        }else{
            \think\facade\Cache::store('redis')->delete($key);
            $money=0;
        }
        $userNickName = $this->userinfo->nick_name;
        if (!empty($robot_id)){
            $userNickName = (new \app\model\User())->where(['id'=>$robot_id])->value('nick_name');
        }
       if ($money > 0) {
           (new BagLog())->save([
               'room_no'=>env('room_no'),'uid'=>$robot_id ? $robot_id : $this->userinfo->id,'nick_name'=>$userNickName,'money'=>$money,'red_id'=>$redBaoInfo['id'],
               'head_img'=>$this->userinfo->head_img
           ]);
           $this->userinfo->jifen =  $this->userinfo->jifen + $money;
           $this->userinfo->save();
           $sendUserInfo = (new \app\model\User())->where(['id'=>$redBaoInfo['uid']])->field('id,nick_name')->find();

           $msg=[
               'room_no' => env('room_no'),
               'uid' => $robot_id ? $robot_id : $this->userinfo->id,
               'nick_name' => '系统消息',
               'group_icon' => "/static/default/site.png",
               'admin_nickname' => $this->userinfo->user_type == 1 ? $this->userinfo->nick_name : '',
               'admin_group_name' => $this->userinfo->group_name,
               'from_app' => isMobile() ? "WAP" : 'PC',
               'ip' => getRealIP(),
               'status' => 1,
               'content' => "\"{$userNickName}\""."领取了"."\"{$sendUserInfo['nick_name']}\""."的红包",
               'is_true_user' => 1,
               'is_red' => 1,
           ];
           $cashMsg =  new ChatMsg();
           $cashMsg->save($msg);
           $msg['create_time'] = time();
           $msg['update_time'] = time();
           $msg['send_time'] = date("H:i");
           $msg['id'] = $cashMsg->id;
           $msg['is_bao'] =0;
           Gateway::sendToAll(json_encode([
               'type' => 'hd_msg',
               'data' => $msg
           ]));
           return json(['code' => 200, 'msg' => '领取成功','data'=>$money,'id'=>$redBaoInfo['id']]);
       }
    }
    /*
   * 红包领取记录
   */
    public function redBagLog(){
        $id =request()->get('id/d',1);
        //$chaMsgInfo = (new ChatMsg())->where(['id'=>$id])->field('id,red_id')->find();
        $list=(new BagLog())->where(['red_id'=>$id])->order('id desc')->select();
        if ($list->isEmpty())  return json(['code'=>200,'msg'=>"ok",'data'=>[]]);
        return json(['code'=>200,'msg'=>"ok",'data'=>$list]);
    }
    /*
     * 个人领取记录
     */
    public function getUserBagLog(){
        $page =request()->get('page/d',1);
        $limit =request()->get('limit/d',15);
        $list=(new BagLog())->where(['uid'=>$this->userinfo->id])->field('id,money,create_time')->page($page,$limit)->order('id desc')->select();
        if ($list->isEmpty())  return json(['code'=>200,'msg'=>"ok",'data'=>[]]);
        $count = (new BagLog())->where(['uid'=>$this->userinfo->id])->count();
        $data=[
            'list'=>$list,
            'count'=>count($list),
            'total'=>(new BagLog())->where(['uid'=>$this->userinfo->id])->sum('money'),
        ];
        return json(['code'=>200,'msg'=>"ok",'count'=>$count,'data'=>$data]);
    }
    /** 实现随机红包
     * @param $total 红包总金额
     * @param $num   红包个数
     * @return array
     */
    public function rand_section($total,$num)
    {
        $min = 0.01;//每个人最少能收到0.01元
        $data = [];
        for ($i = 1; $i < $num; $i++) {
            $safe_total = ($total - ($num - $i) * $min) / ($num - $i);//随机安全上限
            $money = mt_rand($min * 100, $safe_total * 100) / 100;
            $total =bcsub( $total ,$money,2);
            $data[$i] = $money;
        }
        $data[$num] = $total;
        return $data;
    }
     public function getUserInfo(){
        $data= [
            'jifen'=>$this->userinfo->jifen,
        ];
        return json(['code'=>200,'msg'=>"ok",'data'=>$data]);
    }
}