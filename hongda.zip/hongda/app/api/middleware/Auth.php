<?php

namespace app\api\middleware;

use app\exception\TokenException;
use app\exception\ErrorException;
use app\model\User;
class Auth
{
    public function handle($request, \Closure $next)
    {
        $userToken = $request->header("token", "");
        if (empty($userToken)) throw new TokenException();
        //p($userToken);
        $userInfo = (new User)->where(['sess_id' => $userToken])->order('id asc')->find();
        if (empty($userInfo)) throw new TokenException();
        //判断用户状态
        if ($userInfo->user_status != '1') throw new ErrorException(['msg' => "账户已被停用，请联系客服"]);

        $request->userInfo = $userInfo;
        return $next($request);
    }
}