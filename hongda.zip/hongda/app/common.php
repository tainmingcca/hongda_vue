<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006-2016 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: 流年 <liu21st@gmail.com>
// +----------------------------------------------------------------------
function p($data)
{
    echo "<pre style='color: red;'>";
    print_r($data);
    exit("</pre>");
}

// 应用公共文件
function writeLog($file, $data)
{
    $path = root_path() . '/logs/' . $file . '/' . date('Ymd') . '.log';
    $dir = dirname($path);
    if (!is_dir($dir)) {
        mkdir($dir, 0777, true);
    }
    file_put_contents($path, str_repeat("=====", 40) . "\n", FILE_APPEND);
    file_put_contents($path, date("Y-m-d H:i:s") . "\n", FILE_APPEND);
    if (is_array($data))
        file_put_contents($path, var_export($data, true) . "\n", FILE_APPEND);
    else
        file_put_contents($path, $data . "\n", FILE_APPEND);
    file_put_contents($path, str_repeat("=====", 40) . "\n\n", FILE_APPEND);
}

function getRealIP()
{
    $forwarded = request()->header("x-forwarded-for");
    if ($forwarded) {
        $ip = explode(',', $forwarded)[0];
    } else {
        $ip = request()->ip();
    }
    return $ip;
}

function checkMobile($mobile)
{
    if (preg_match("/^1[3456789]{1}\d{9}$/", $mobile)) {
        return true;
    } else {
        return false;
    }
}


//生成邀请码
function randStr($uid, $len = 6, $format = 'ALL')
{
    switch ($format) {
        case 'ALL':
            $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
            break;

        case 'CHAR':
            $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
            break;

        case 'HIGHER':
            $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
            break;

        case 'LOWER':
            $chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
            break;

        case 'NUMBER':
            $chars = '0123456789';
            break;

        default:
            $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-@#~';
            break;
    }
    mt_srand((double)microtime() * 1000000 * $uid);
    $password = "";
    while (strlen($password) < $len) $password .= substr($chars, (mt_rand() % strlen($chars)), 1);
    return $password;
}


//打乱数组
function random_arr($array)
{
    $count = count($array['choice']);     //获取数组的长度
    $arr = array();
    while (count($arr) < $count) {
        $num = rand(0, $count - 1);
        $arr[] = $array['choice'][$num];  //重新进行组装
        $arr = array_unique($arr);        //去除重复的
    }
    $arr = array_merge($arr);      //下标重新进行排序
    $result['choice'] = $arr;     //转换成二位的数组，重新返回回去
    return $result;
}


function curl_get($url, $timeout = 30)
{
    $return_msg = array();
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 5.1; zh-CN; rv:1.9) MicroMessenger Gecko/2008052906 Firefox/3.0');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_BINARYTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
    $result = curl_exec($ch);
    $statusCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $return_msg['output'] = $result;
    $return_msg['response_code'] = $statusCode;
    curl_close($ch);
    unset($ch);
    return $return_msg;
}


function curl_post($url, $data = '', $timeout = 30)
{
    $return_msg = array();
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HEADER, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
    curl_setopt($ch, CURLOPT_REFERER, "");
    $result = curl_exec($ch);
    $statusCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $return_msg['output'] = $result;
    $return_msg['response_code'] = $statusCode;
    curl_close($ch);
    unset($ch);
    return $return_msg;
}



