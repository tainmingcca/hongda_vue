<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006~2018 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: liu21st <liu21st@gmail.com>
// +----------------------------------------------------------------------
use think\facade\Route;
Route::get('login', 'Login/index');
Route::get('login2', 'Login/login2');
Route::get('logout', 'Login/logout');


Route::get('/', 'Index/index');
Route::get('Index/main', 'Index/main');
Route::get('Index/getMainData', 'Index/getMainData');



Route::get('Admin/index', 'Admin/index');
Route::rule('Admin/add', 'Admin/add');
Route::post('Admin/changePass', 'Admin/changePass');




Route::get('Admingroup/index', 'Admingroup/index');
Route::rule('Admingroup/add', 'Admingroup/add');
Route::rule('Admingroup/edit', 'Admingroup/edit');



Route::get('Headimg/index', 'Headimg/index');
Route::rule('Headimg/add', 'Headimg/add');
Route::rule('Headimg/edit', 'Headimg/edit');



Route::get('Imkf/index', 'Imkf/index');
Route::rule('Imkf/add', 'Imkf/add');
Route::rule('Imkf/edit', 'Imkf/edit');
Route::get('Imkf/changeOnline', 'Imkf/changeOnline');



Route::get('Immsg/index', 'Immsg/index');






Route::get('Interact/index', 'Interact/index');
Route::get('Interact/tongji', 'Interact/tongji');






Route::get('Myrobot/index', 'Myrobot/index');
Route::rule('Myrobot/addUser', 'Myrobot/addUser');
Route::rule('Myrobot/addYk', 'Myrobot/addYk');



Route::get('Notice/index', 'Notice/index');
Route::rule('Notice/edit', 'Notice/edit');



Route::get('Qqkf/index', 'Qqkf/index');
Route::rule('Qqkf/add', 'Qqkf/add');
Route::rule('Qqkf/edit', 'Qqkf/edit');
Route::get('Qqkf/changeOnline', 'Qqkf/changeOnline');



Route::get('Robot/index', 'Robot/index');
Route::rule('Robot/edit', 'Robot/edit');


Route::rule('Room/index', 'Room/index');



Route::get('AdList/index', 'AdList/index');
Route::post('AdList/add', 'AdList/add');
Route::rule('AdList/edit', 'AdList/edit');
Route::get('AdList/adIsShow', 'AdList/adIsShow');



Route::get('Teacher/index', 'Teacher/index');
Route::rule('Teacher/add', 'Teacher/add');
Route::rule('Teacher/edit', 'Teacher/edit');



Route::get('Driver/index', 'Driver/index');
Route::get('Driver/myUser', 'Driver/myUser');
Route::rule('Driver/add', 'Driver/add');
Route::rule('Driver/edit', 'Driver/edit');
Route::rule('Driver/fpim', 'Driver/fpim');
Route::get('Driver/changeStatus', 'Driver/changeStatus');
Route::rule('Driver/changRemark', 'Driver/changRemark');
Route::get('Driver/getIsOnline', 'Driver/getIsOnline');



Route::get('Usergroup/index', 'Usergroup/index');
Route::rule('Usergroup/add', 'Usergroup/add');
Route::rule('Usergroup/edit', 'Usergroup/edit');


Route::get('Yk/index', 'Yk/index');
Route::get('Yk/myYk', 'Yk/myYk');
Route::get('Yk/onlineUser', 'Yk/onlineUser');
Route::get('Yk/changeJinyan', 'Yk/changeJinyan');
Route::get('Yk/killUser', 'Yk/killUser');

Route::rule('upFile','Base/upFile');







