<?php

namespace app\admin\controller;


use app\exception\ErrorException;
use app\model\AdminGroup;
use think\facade\View;

/*
 * 客服
 */

class Imkf extends Base
{
    public function __construct(\app\model\User $userModel)
    {
        parent::__construct();
        $this->_model = $userModel;
    }
    /*
     * im列表
     */
    public function index()
    {
        if (request()->isAjax()) {
            $data = request()->param();
            $where = $this->_createWhere();
            $count = $this->_model->where($where)->count();
            $list = $this->_model->where($where)->page($data['page'], $data['limit'])->order('id desc')->select();
            return json(['code' => 0, 'msg' => '', 'data' => $list, 'count' => $count]);
        }
        return View::fetch();
    }

    private function _createWhere()
    {
        $where = [
            ['room_no', '=', $this->room_no],
            ['user_type', '=', 1],
            ['group_id', '=', 2],
        ];
        return $where;
    }

    /*
     * 添加im
     */
    public function add()
    {
        if (request()->isPost()) {
            $data = request()->post();
            if (strlen($data['passwd']) < 6 && strlen($data['passwd']) < 12) {
                throw new ErrorException(['msg' => '密码不得低于6位.不得超过12位']);
            }
            if (md5($data['passwd']) != md5($data['passwd2'])) {
                throw new ErrorException(['msg' => '两次输入密码不一致,请重新输入']);
            }
            $count = (new \app\model\User())->where(['user_name' => $data['user_name']])->count();
            if ($count > 0) {
                throw new ErrorException(['msg' => '该账号已存在,请重新输入']);
            }
            $admin_group = (new AdminGroup())->where(['id' => 2])->find();
            $res = $this->_model->save([
                'room_no' => $this->room_no,
                'user_name' => $data['user_name'],
                'nick_name' => $data['nick_name'],
                'user_sex' => $data['user_sex'],
                'passwd' => md5($data['passwd']),
                'user_type' => 1,
                'group_id' => $admin_group->id,
                'group_name' => $admin_group->group_name,
                'group_icon' => $admin_group->group_icon,
                'user_qq' => $data['user_qq'],
                'end_time' => $data['end_time'] ? $data['end_time'] : '0000-00-00',
                'admin_fenpei' => 1,
                'head_img'=>'/static/default/head_img.png'
            ]);
            if ($res) {
                return json(['code' => 200, 'msg' => '添加成功']);
            }
            return json(['code' => 201, 'msg' => '添加失败']);
        }
        return View::fetch();
    }

    /*
     * 编辑im
     */
    public function edit()
    {
        $id = request()->param('id', 0, 'intval');
        $im_info = $this->_model->where(['id' => $id])->find();
        if (request()->isPost()) {
            $data = request()->post();
            if (empty($data['passwd'])) {
                unset($data['passwd']);
            } else {
                $data['passwd'] = md5($data['passwd']);
            }
            $data['end_time'] = $data['end_time'] ? $data['end_time'] : '0000-00-00';
            $res = $im_info->save($data);
            if ($res) {
                return json(['code' => 200, 'msg' => '修改成功']);
            }
            return json(['code' => 201, 'msg' => '修改失败']);
        }
        View::assign(['im_info' => $im_info]);
        return View::fetch();
    }

    public function changeOnline(){
        $id = request()->get('id', 0, 'intval');
        $user_info = $this->_model->where(['id' => $id])->field('id,is_online')->find();
        if ($user_info->is_online == 1) {
            $user_info->is_online = 0;
        } else {
            $user_info->is_online = 1;
        }
        $res = $user_info->save();
        if ($res) {
            return json(['code' => 200, 'msg' => '修改成功']);
        }
        return json(['code' => 201, 'msg' => '修改失败']);
    }
}