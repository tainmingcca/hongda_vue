<?php


namespace app\admin\controller;
use think\facade\View;

class Headimg extends Base
{
    public function __construct(\app\model\Headimg $headimgModel)
    {
        parent::__construct();
        $this->_model = $headimgModel;
    }

    /*
     * 常用头像列表
     */
    public function index()
    {
        if (request()->isAjax()) {
            $data = request()->param();
            $where = $this->_createWhere();
            $count = $this->_model->where($where)->count();
            $list = $this->_model->where($where)->page($data['page'], $data['limit'])->order('id desc')->select();
            return json(['code' => 0, 'msg' => '', 'data' => $list, 'count' => $count]);
        }
        return View::fetch();
    }
    private function _createWhere()
    {
        $where = [
            ['room_no', '=', $this->room_no],
        ];
        return $where;
    }

    public function add()
    {
        if (request()->isPost()) {
            $data = request()->post();
            $data['room_no']=$this->room_no;
            $res = $this->_model->save($data);
            if ($res) {
                return json(['code' => 200, 'msg' => '修改成功']);
            }
            return json(['code' => 201, 'msg' => '修改失败']);
        }
        return View::fetch();
    }

    public function edit()
    {
        $id = request()->param('id', 0, 'intval');
        $head_info = $this->_model->where(['id' => $id])->find();
        if (request()->isPost()) {
            $data = request()->post();
            $res = $head_info->save($data);
            if ($res) {
                return json(['code' => 200, 'msg' => '修改成功']);
            }
            return json(['code' => 201, 'msg' => '修改失败']);
        }

        View::assign(['head_info' => $head_info]);
        return View::fetch();
    }
    public function isShow(){
        $id=request()->get('id/d',0);
        $head_info=$this->_model->where(['id'=>$id])->find();
        if ($head_info->is_show==1){
            $head_info->is_show=0;
        }else{
            $head_info->is_show=1;
        }
        $res=$head_info->save();
        if ($res) {
            return json(['code' => 200, 'msg' => '修改成功']);
        }
        return json(['code' => 201, 'msg' => '修改失败']);
    }
}