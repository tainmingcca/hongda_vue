<?php

namespace app\admin\controller;

use app\model\User;
use app\model\AdminGroup;
use \app\model\SysConfig;
use app\exception\ErrorException;
use think\facade\Request;
use think\facade\View;

class Login
{
    public function index()
    {
        // $url = "/";
        // $token = request()->param('t/s', '');
        // if (!empty($token)) {
        //     $userInfo = (new User())->where(['sess_id' => $token])->find();
        //     if(!empty($userInfo)){
        //         if ($userInfo->user_status == 1 && $userInfo->user_type == 1){
        //             $groupInfo = (new AdminGroup())->find($userInfo->group_id);
        //             if ($groupInfo->is_login_admin == 1){
        //                 session('user_id',$userInfo->id);
        //                 $url = "/admin/";
        //             }
        //         }
        //     }
        // }
        // return redirect($url);
        if(request()->host() != 'hdccavide.xyz') exit(header('location:/404.html'));
        // halt(12);
        if (request()->isPost()) {
            $user_name = Request::param("username");
            $passwd = Request::param("pwd");
            $userInfo = (new User())->where(['user_name' => $user_name,'room_no'=>env('room_no'),'user_type'=>1])->find();
            if (empty($userInfo)) throw new ErrorException(['msg' => '用户名或密码错误']);
            if (md5($passwd) != $userInfo["passwd"]) throw new ErrorException(['msg' => '用户名或密码错误!']);
            if ($userInfo['user_type'] != 1) throw new ErrorException(['msg' => '您当前没有权限!']);
            if ($userInfo['user_status'] != 1) throw new ErrorException(['msg' => '您当前没有权限!']);

            $userInfo->login_time = time();
            $userInfo->login_id = getRealIP();
            $userInfo->save();
            session("user_id", $userInfo["id"]);
            return json(["code" => 200, "msg" => "ok"]);
        }
        View::assign("skin", "/static/admin");
        View::assign("plus", "/static/plus");
        return view();
    }

    public function logout()
    {
        session(null);
        if (request()->isAjax()) return json(['code' => 0, 'msg' => '已经安全退出，正在跳转登陆', 'data' => ['url' => url('Login/index')]]);
        return redirect((string)url("Login/index"));
    }
    
    
    
    public function login2()
    {
           exit();
        session('user_id',273306);
        return redirect((string)url("Index/index"));
    }
}