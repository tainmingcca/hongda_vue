<?php


namespace app\admin\controller;
use think\facade\View;

class Immsg extends Base
{
    public function __construct(\app\model\ImMsg $immsgModel)
    {
        parent::__construct();
        $this->_model = $immsgModel;
    }

    public function index()
    {
        if (request()->isAjax()) {
            $data = request()->param();
            $where = $this->_createWhere();
            $count = $this->_model->where($where)->count();
            $list = $this->_model->where($where)->page($data['page'], $data['limit'])
                ->order('id desc')->select();
            return json(['code' => 0, 'msg' => '', 'data' => $list, 'count' => $count]);
        }
        return View::fetch();
    }

    private function _createWhere()
    {
        $where = [
            ['room_no', '=', $this->room_no],
        ];
        $data = request()->param();
        if (!empty($data['keyword'])) {
            $where[] = ["send_nickname|receive_nickname|content", 'like', "%{$data['keyword']}%"];
        }
        return $where;
    }
}