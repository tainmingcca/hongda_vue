<?php
/**
 * 互动管理
 * Class Interact
 * @package app\admin\controller
 */

namespace app\admin\controller;

use think\facade\Cache;
use app\exception\ErrorException;
use app\model\ChatMsg;
use app\model\ImMsg;
use think\facade\View;


class Interact extends Base
{
    public function __construct(\app\model\ChatMsg $chatmsgModel)
    {
        parent::__construct();
        $this->_model = $chatmsgModel;
    }
    public function index()
    {
        if (request()->isAjax()) {
            $data = request()->param();
            if (!empty($data['date'])){
                $titme_data=explode("~",$data['date']);
                $start_date=$titme_data[0];
                $end_date=$titme_data[1];
                $where = $this->_createWhere();
                $count = $this->_model->where($where)->count();
                $list = $this->_model->where($where)->whereBetweenTime('create_time', $start_date, $end_date)->page($data['page'], $data['limit'])
                    ->order('id desc')->field('id,nick_name,status,content,create_time,uid')->select();
                foreach ($list as $item) {
                    $item['content'] = htmlspecialchars_decode($item['content']);
                    $item['chatCount'] = $this->_model->where(['uid'=>$item['uid']])->count();
                }
                return json(['code' => 0, 'msg' => '', 'data' => $list, 'count' => $count]);
            }else{
                $where = $this->_createWhere();
                $count = $this->_model->where($where)->count();
                $list = $this->_model->where($where)->page($data['page'], $data['limit'])
                    ->order('id desc')->field('id,nick_name,status,content,create_time,uid')->select();
                foreach ($list as $item) {
                    $item['content'] = htmlspecialchars_decode($item['content']);
                    $item['chatCount'] = $this->_model->where(['uid'=>$item['uid']])->count();
                }
                return json(['code' => 0, 'msg' => '', 'data' => $list, 'count' => $count]);
            }

        }
        return View::fetch();
    }
    private function _createWhere()
    {
        $where = [
            ['room_no', '=', $this->room_no],
        ];
        $data = request()->param();
        if (!empty($data['keyword'])) {
            $where[] = ["nick_name|content", 'like', "%{$data['keyword']}%"];
        }
        return $where;
    }


    public function tongji()
    {
        if (request()->isAjax()) {
            set_time_limit(0);
            ini_set('memory_limit',-1);
            $date = request()->get('date/s','');
            if($date=='yesterday') $cacheKey = 'hdTongji_yestoday';
            $cacheKey = !empty($date)?"hdTongji_today":"hdTongji";
            if(!Cache::has($cacheKey)){
                $admin_list = (new \app\model\User())->where(['user_type' => 1,'room_no'=>$this->room_no])->field('id,nick_name')->select();
                foreach ($admin_list as $item) {
                    $ids=[];
                    $ids[] = $item->id;
                    $lowList = (new \app\model\User())->where([
                        ['room_no', '=', $this->room_no],
                        ['admin_uid','=',$item->id]
                    ])->field("id")->select();
                    foreach ($lowList as $item2){
                        $ids[]=$item2->id;
                    }
                    unset($lowList);
                    $item->count = $this->_model->whereIn('uid',$ids)->whereDay('create_time')->count();
                    if($date=='yesterday'){
                        $item->count = $this->_model->whereIn('uid',$ids)->whereDay('create_time',$date)->count();
                    }
                    unset($ids);
                }
                $admin_list = $admin_list->toArray();
                //Cache::set($cacheKey,$admin_list,10*60);
            }else{
                $admin_list = Cache::get($cacheKey);
            }
            return json(['code' => 0, 'msg' => '', 'data' => $admin_list, 'count' => 0]);
        }
        return View::fetch();
    }

}