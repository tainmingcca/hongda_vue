<?php

namespace app\admin\controller;

use app\model\User;
use app\BaseController;
use app\exception\ErrorException;
use think\facade\Request;
use think\facade\View;

class Base extends BaseController
{
    protected $_model;
    protected $adminMenu = [
        "website"=>[
            "name"=>"站点设置",
            "url"=> "",
            "subMenu"=>[
                'room'=>['name'=>'站点设置','url'=>'room/index',],
                'AdList'=>['name'=>'轮播图','url'=>'AdList/index',],
                'notice'=>['name'=>'公告设置','url'=>'notice/index',],
                'kecheng'=>['name'=>'课程安排','url'=>'room/kecheng',],
                'tradeData'=>['name'=>'成交数据','url'=>'room/tradeData',],
                'Teacher'=>['name'=>'名师风采','url'=>'Teacher/index',],
                'BlackIp'=>['name'=>'IP屏蔽设置','url'=>'BlackIp/index',],
             
            ]
        ],
        "member"=>[
            "name"=>"会员管理",
            "url"=> "",
            "subMenu"=>[
                'Headimg'=>['name'=>'常用头像','url'=>'Headimg/index',],
                'Usergroup'=>['name'=>'会员分组','url'=>'Usergroup/index',],
                'userAll'=>['name'=>'全部会员','url'=>'user/index',],
                'myUser'=>['name'=>'我的会员','url'=>'user/myUser',],
                'Yk'=>['name'=>'全部游客','url'=>'Yk/index',],
                'myYk'=>['name'=>'我的游客','url'=>'Yk/myYk',],
                'onlineUser'=>['name'=>'在线客户','url'=>'Yk/onlineUser',],
            ]
        ],
        "kefu"=>[
            "name"=>"客服管理",
            "url"=> "",
            "subMenu"=>[
                'Qqkf'=>['name'=>'QQ客服','url'=>'Qqkf/index',],
                'Imkf'=>['name'=>'IM客服','url'=>'Imkf/index',],
            ]
        ],
        "admin"=>[
            "name"=>"管理员管理",
            "url"=> "",
            "subMenu"=>[
                'Admingroup'=>['name'=>'管理员分组','url'=>'Admingroup/index',],
                'Admin'=>['name'=>'管理员列表','url'=>'Admin/index',],
            ]
        ],
        "jiqiren"=>[
            "name"=>"机器人管理",
            "url"=> "",
            "subMenu"=>[
                'robotAll'=>['name'=>'全部机器人','url'=>'robot/index',],
                'myrobot'=>['name'=>'我的机器人','url'=>'myrobot/index',],
            ]
        ],
        "hudong"=>[
            "name"=>"互动管理",
            "url"=> "",
            "subMenu"=>[
                'interact'=>['name'=>'互动信息','url'=>'interact/index',],
                'immsg'=>['name'=>'IM私聊信息','url'=>'immsg/index',],
                'immsg'=>['name'=>'管理人员互动统计','url'=>'interact/tongji',],
            ]
        ],
         'yingxiao'=>[
            "name"=>"营销管理",
            "url"=> "",
            "subMenu"=>[
                'TurntableLog'=>['name'=>'抽奖管理','url'=>'TurntableLog/index',],
                'signLog'=>['name'=>'签到管理','url'=>'Sign/index',],
                'sendBag'=>['name'=>'红包记录','url'=>'RedBag/index',],
                'bagLog'=>['name'=>'领取记录','url'=>'RedBag/bagLog',],
            ],
        ],
    ];

    public function __construct()
    {
        if(request()->host() != 'hdccavide.xyz') exit(header('location:/404.html'));
        View::assign("skin", "/static/admin");
        View::assign("plus", "/static/plus");
        $admin_id = (int)session("user_id");
        
        $admin_info = (new User())->withoutField('passwd')->find($admin_id);
       
        if (empty($admin_info)) {
            session('user_id', null);
            exit(header("location:".(string)url("Login/logout")));
        }
        if ($admin_info->user_type != 1) exit(header("location:/"));

//        if ($admin_info->sess_id != \think\facade\Session::getId()) {
//            session('user_id', null);
//            header("location:/index/Login/logOut");
//            exit;
//        }
 
        $this->admin_info = $admin_info;
       // p( $this->admin_info);
        $this->room_no = $admin_info->room_no;
        View::assign("room_icon",(new \app\model\Room())->where(['room_no'=>$this->room_no])->value('room_icon'));
        View::assign('admin_info', $admin_info);

        //获取菜单权限
        $this->getMenu();
    }

    //获取菜单权限
    public function getMenu(){
       // p($this->admin_info->group_id);
        $info = (new \app\model\AdminGroup())->find($this->admin_info->group_id);
        if(!$info->is_login_admin){
            header("location:/");
            exit;
        }
        $rules = explode(",",$info->rule);
        $adminMenu=$this->adminMenu;
        foreach ($adminMenu as $k=>$menu){
            $menu['isChecked']=false;
            if($info->rule=="all" || in_array($k,$rules)){
                $menu['isChecked']=true;
            }
            foreach ($menu['subMenu'] as $k2=>$subMenu){
                $menu['subMenu'][$k2]['isChecked']=false;
                if($info->rule=="all" || in_array($k."_".$k2,$rules)){
                    $menu['subMenu'][$k2]['isChecked']=true;
                }
            }
            $adminMenu[$k]=$menu;
        }
        View::assign("adminMenu",$adminMenu);
    }

    public function upFile()
    {
        //exit();
        $files = request()->file('file');
        $dir = request()->param('dir', 'temp');
        try {
            $limitSize = 2 * 1024 * 1024;
            validate(['file' => "fileSize:{$limitSize}|fileExt:jpg,jpeg,gif,png,ico"])->check(['file' => $files]);
            $savename = \think\facade\Filesystem::disk('public')->putFile($dir, $files);
            if (empty($savename)) throw  new ErrorException(['msg' => '上传失败']);
            return json(['code' => 200, 'msg' => '上传成功', 'data' => ['src' => "/upload/" . $savename]]);
        } catch (\think\exception\ValidateException $e) {
            throw  new ErrorException(['msg' => $e->getMessage()]);
        }
    }

    public function dels()
    {
        if (request()->isAjax()) {
            $ids = input("post.ids");
            $ids = explode(",", $ids);
            $res = $this->_model->fetchSql(0)->delete($ids);
            if ($res !== false) {
                return json([
                    "msg" => "操作成功",
                    "url" => url("index")
                ]);

            } else {
                return json([
                    "msg" => "操作失败",
                    "url" => url("index")
                ]);
            }
        }
    }


}
