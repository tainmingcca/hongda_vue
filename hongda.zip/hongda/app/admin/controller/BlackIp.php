<?php


namespace app\admin\controller;


use think\facade\View;

class BlackIp extends Base
{
    public function __construct(\app\model\Blackip $blackip)
    {
        parent::__construct();
        $this->_model = $blackip;
    }

    public function index(){
        if (request()->isAjax()){
            $data=request()->post();
            $count= (new \app\model\Blackip())->where(['room_no'=>$this->room_no])->count();
            $list= (new \app\model\Blackip())->where(['room_no'=>$this->room_no])->order('id desc')->select();
            return json(['code'=>0,'msg'=>'ok','count'=>$count,'data'=>$list]);
        }
        return View::fetch();
    }
    public function add(){
        $admin_id=$this->admin_info->id;
        if (request()->isPost()){
            $data=request()->post();
            $data['act_user_name']=(new \app\model\User())->where(['id'=>$admin_id])->value('user_name');
            $data['room_no']=$this->room_no;
            $res=(new \app\model\Blackip())->save($data);
            if ($res){
                return json(['code'=>200,'msg'=>'添加成功']);
            }else{
                return json(['code'=>200,'msg'=>'添加失败']);
            }
        }
        return View::fetch();
    }
}