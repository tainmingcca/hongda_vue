<?php


namespace app\admin\controller;


use think\facade\View;

class Sign extends Base
{
    public function __construct(\app\model\Sign $signModel)
    {
        parent::__construct();
        $this->_model = $signModel;
    }

    public function index(){
        if (request()->isAjax()) {
            $data = request()->param();
            $count = $this->_model->count();
            $list = $this->_model->page($data['page'], $data['limit'])->order('id desc')->select();
            return json(['code' => 0, 'msg' => '', 'data' => $list, 'count' => $count]);
        }
        return  View::fetch();
    }
}