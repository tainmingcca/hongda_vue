<?php

namespace app\admin\controller;

use app\model\Headimg;
use app\model\User;
use app\model\UserGroup;
use app\exception\ErrorException;
use think\facade\View;

class Myrobot extends Base
{
    public function __construct(User $userModel)
    {
        parent::__construct();
        $this->_model = $userModel;
    }


    public function index()
    {
        if (request()->isAjax()) {
            $data = request()->param();
            $where = $this->_createWhere();
            $where[] = ['admin_uid', '=', $this->admin_info->id];
            $count = $this->_model->where($where)->count();
            $list = $this->_model->where($where)->page($data['page'], $data['limit'])->order('create_time desc')->select();
            foreach ($list as $item) {
                $item['admin_uid'] =$this->_model->where(['id' => $item['admin_uid']])->value('user_name');
            }
            return json(['code' => 0, 'msg' => '', 'data' => $list, 'count' => $count]);
        }
        return View::fetch();
    }

    private function _createWhere()
    {
        $where = [
            ['room_no', '=', $this->room_no],
            ['is_robot', '=', 1]
        ];
        $data = request()->param();
        if (!empty($data['keyword'])) {
            $where[] = ["nick_name|group_name", 'like', "%{$data['keyword']}%"];
        }
        return $where;
    }

    public function addUser()
    {
        $admin_id = $this->admin_info->id;
        $user_group = (new UserGroup())->select();
        $head_img = (new Headimg())->select();
        if (request()->isPost()) {
            $data = request()->post();
            $user_group = (new UserGroup())->where(['id' => $data['group_id']])->find();
            $data = [
                'room_no' => $this->room_no,
                'nick_name' => $data['nick_name'],
                'admin_uid' => $admin_id,
                'user_type' => 2,
                'group_id' => $user_group->id,
                'group_name' => $user_group->group_name,
                'group_icon'=>$user_group->group_icon,
                'head_img' => (new Headimg())->where(['id' => $data['head_id']])->value('img_url'),
                'is_robot' => 1,
            ];
            $res = $this->_model->save($data);
            if ($res) {
                cache("robotList{$admin_id}",null);
                return json(['code' => 200, 'msg' => '添加成功']);
            } else {
                return json(['code' => 201, 'msg' => '添加失败']);
            }
        }
        View::assign(['user_group' => $user_group, 'head_img' => $head_img]);
        return View::fetch();

    }



    public function addYk()
    {
        $admin_id = session('user_id');
        if (request()->isPost()) {
            $num = request()->post('num/d', 0);
            $length = (int)$num;
            if ($length > 5) {
                throw new ErrorException(['msg' => '每次最多生成5个']);
            }
            $data = array(); //创建临时变量用以存储数据
            $user_group = (new UserGroup())->where(['id' => 1])->find();
            for ($i = 0; $i < $length; $i++) { //循环
                $usernameCheck = true;
                do {
                    $sj = random_int(3333333, 9999999);
                    $user_name = "yk".$sj;
                    $count = $this->_model->where(['user_name' => $user_name])->count();
                    if ($count <= 0) {
                        $usernameCheck = false;
                    }
                } while ($usernameCheck);
                $nick_name = "游客" .$sj;
                $data[$i]['room_no'] = $this->room_no;
                $data[$i]['user_name'] = $user_name;
                $data[$i]['nick_name'] = $nick_name;
                $data[$i]['admin_uid'] = $admin_id;
                $data[$i]['user_type'] = 2;
                $data[$i]['group_id'] = $user_group->id;
                $data[$i]['group_name'] = $user_group->group_name;
                $data[$i]['group_icon'] = $user_group->group_icon;
                $data[$i]['head_img'] = "/static/default/head_img.png";
                $data[$i]['is_robot'] = 1;
            }
            $res = $this->_model->saveAll($data);
            if ($res) {
                cache("robotList{$admin_id}",null);
                return json(['code' => 200, 'msg' => '添加成功']);
            }
            return json(['code' => 201, 'msg' => '添加失败']);
        }
        return View::fetch();
    }


}