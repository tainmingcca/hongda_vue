<?php


namespace app\admin\controller;


use app\model\BagLog;
use think\facade\View;
use think\Model;

class RedBag extends Base
{
    public function __construct(\app\model\SendRed $sendRedModel)
    {
        parent::__construct();
        $this->_model = $sendRedModel;
    }
    public function index(){
        if (request()->isAjax()) {
            $data = request()->param();
            $count = $this->_model->count();
            $list = $this->_model->with('user')->page($data['page'], $data['limit'])->order('id desc')->select();
            return json(['code' => 0, 'msg' => '', 'data' => $list, 'count' => $count]);
        }
        return  View::fetch();
    }
    public function bagLog(){
        if (request()->isAjax()) {
            $data = request()->param();
            $count = (new BagLog())->count();
            $list = (new BagLog())->with('user')->page($data['page'], $data['limit'])->order('id desc')->select();
            return json(['code' => 0, 'msg' => '', 'data' => $list, 'count' => $count]);
        }
        return  View::fetch();
    }

}