<?php

namespace app\admin\controller;

use app\service\Aliyunoss;
use think\facade\Db;
use think\facade\Console;
use app\model\User;
use app\model\Headimg;
use app\model\UserGroup;
use think\facade\View;
use app\exception\ErrorException;
use GatewayClient\Gateway;
use think\facade\Cache;

class Index extends Base
{
    public function __construct()
    {
        parent::__construct();
        Gateway::$registerAddress = config('gateway_worker.registerAddress');
    }

    public function index()
    {

        return View::fetch();
    }

    public function main()
    {
        $admin_id = $this->admin_info->id;
        $userModel = new User();


        //总会员 不含机器人
        $totalUser = $userModel->where([
            ['room_no', '=', $this->room_no],
            ['is_robot', "=", 0],
            ['user_type', '=', 2],
            ['group_id', '>', 1],
        ])->count();
        View::assign("totalUser", $totalUser);
        //今日注册  不含机器人
        $todayUser = $userModel->where([
            ['room_no', '=', $this->room_no],
            ['is_robot', "=", 0],
            ['user_type', '=', 2],
            ['group_id', '>', 1],
        ])->whereDay('create_time')->count();
        View::assign("todayUser", $todayUser);
        // $onlineUser = $userModel->where([
        //     ['room_no', '=', $this->room_no],
        //     ['is_robot', "=", 0],
        //     ['user_type', '=', 2],
        //     ['is_online', '=', 1]
        // ])->count();
         $onlineUser = Gateway::getAllUidCount();
        View::assign("onlineUser", $onlineUser);
        //机器人总数
        $totalRobot = $userModel->where([
            ['room_no', '=', $this->room_no],
            ['is_robot', "=", 1],
        ])->count();
        View::assign("totalRobot", $totalRobot);
        //常用头像
        $totalHeadimg = (new Headimg())->count();
        View::assign("totalHeadimg", $totalHeadimg);
        //最后登录时间
        $lastLoginTime = $userModel->where(['id' => $admin_id])->value('login_time');
        $lastLoginDate = date("Y-m-d H:i:s", $lastLoginTime);
        View::assign("lastLoginDate", $lastLoginDate);
        return View::fetch();
    }

    public function getMainData()
    {
        $date = date("Y-m-d");
        $endDate = date("Y-m-d", strtotime("{$date}-30day"));
        $sql = "select date_format(from_unixtime(create_time),'%Y-%m-%d') as date,count(id) as nums from zb_user where room_no={$this->room_no} and user_type='2' and group_id>1 and  is_robot='0' group by date_format(from_unixtime(create_time),'%Y-%m-%d')  having date >'{$endDate}'";
        $regNum = Db::query($sql);
        if (empty($regNum)) {
            for ($i = 30; $i > 0; $i--) {
                $regNum[] = [
                    'date' => $date,
                    'nums' => 0,
                ];
                $date = date("Y-m-d", strtotime("{$date}-1day"));
            }
        }

        //Cache::delete('admin_online_data');
        $onlineNum = [];
        $admin_online_data = [];
        $cacheKey = env('database.database').":admin_online_data";
        if (Cache::store("redis")->has($cacheKey)) {
            $admin_online_data = Cache::store("redis")->get($cacheKey);
        }
        // print_r($admin_online_data);exit;
        for ($i = 0; $i <= 23; $i++) {
            for ($j = 0; $j < 60; $j++) {
                $time = ($i < 10 ? "0{$i}" : $i) . ":" . ($j < 10 ? "0{$j}" : $j);
                $nums = 0;
                if (empty($admin_online_data)) {
                    $onlineNum[] = [
                        'time' => $time,
                        'nums' => $nums
                    ];
                } else {
                    $onlineNum[] = [
                        'time' => $time,
                        'nums' => isset($admin_online_data[$time]) ? $admin_online_data[$time] : 0
                    ];
                }
            }
        }


        $groupNum = [];
        $userGroupList = (new UserGroup())->where([['id', '>', 1]])->field('id,group_name')->select();
        $sql = "select group_id,group_name as name,count(id) as value from zb_user where room_no={$this->room_no} and user_type='2' and group_id>1 and  is_robot='0' group by user_type,group_id";
        $groupCounts = Db::query($sql);
        foreach ($userGroupList as $k => $item) {
            $groupNum[$k] = [
                'name' => $item->group_name,
                'value' => 0
            ];
            if (!empty($groupCounts))
                foreach ($groupCounts as $item2) {
                    if ($item['id'] == $item2['group_id']) {
                        $groupNum[$k]['value'] = $item2['value'];
                    }
                }
        }
        return json(['code' => 200, 'msg' => 'ok', 'data' => [
            'regNum' => $regNum,
            'onlineNum' => $onlineNum,
            'groupNum' => $groupNum,
        ]]);
    }


    public function clearCache()
    {
        $runtimePath = app()->getRootPath() . 'runtime' . DIRECTORY_SEPARATOR;
//        $cachePath = $runtimePath . "cache" . DIRECTORY_SEPARATOR;
//        $logPath = $runtimePath . "log" . DIRECTORY_SEPARATOR;
//        $adminLogPath = $runtimePath . "admin" . DIRECTORY_SEPARATOR . "log" . DIRECTORY_SEPARATOR;
//        $indexLogPath = $runtimePath . "index" . DIRECTORY_SEPARATOR . "log" . DIRECTORY_SEPARATOR;
        try {
            Console::call('clear', ["--cache", "--dir"]);
            Console::call('clear', ["--log", "--dir"]);
        } catch (\Exception $e) {
            throw new ErrorException(['msg' => $e->getMessage()]);
        }
        return json(['code' => 200, 'msg' => "清除缓存成功", 'data' => []]);
    }



    public function getOssPolicy()
    {
        $dir = request()->param("dir/s",'temp');
        $aliyunoss = new Aliyunoss();
        $res = $aliyunoss->aliossPolicy($dir);
        return json(['code'=>200,'msg'=>'ok','data'=>$res]);
    }

    public function uploadSrc($type, $src)
    {
        if ($type == 'default_bg') (new \app\model\Room())->where(['room_no' => $this->room_no])->update(['default_bg' => $src]);
        if ($type == 'index_dialog_img') (new \app\model\Room())->where(['room_no' => $this->room_no])->update(['index_dialog_img' => $src]);
        if ($type == 'kcb_url') (new \app\model\Room())->where(['room_no' => $this->room_no])->update(['kcb_url' => $src]);
        if ($type == 'logo_url') (new \app\model\Room())->where(['room_no' => $this->room_no])->update(['logo_url' => $src]);
        // if ($type == 'room_icon') (new \app\model\Room())->where(['room_no' => $this->room_no])->update(['room_icon' => $src]);
        if ($type == 'room_icon') {
            $res = copy('.'.$src,'./favicon.ico');
            if($res) @unlink('.'.$src);
            (new \app\model\Room())->where(['room_no' => $this->room_no])->update(['room_icon' => $res?'/favicon.ico':$src]);
        }
        cache('room_info',null);
        return json(['code' => 200, 'msg' => '', 'data' => ['src' => $src]]);
    }
}

