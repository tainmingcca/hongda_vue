<?php


namespace app\admin\controller;
use app\model\Turntable;

use app\exception\ErrorException;
use think\facade\View;

class TurntableLog extends Base
{
    public function __construct(\app\model\TurntableLog $turntablelogModel)
    {
        parent::__construct();
        $this->_model = $turntablelogModel;
    }

    public function index()
    {
        if (request()->isAjax()) {
            $data = request()->param();
            $where = $this->_createWhere();
            $count = $this->_model->where($where)->count();
            $list = $this->_model->where($where)->page($data['page'], $data['limit'])->order('id desc')->select();
            return json(['code' => 0, 'msg' => '', 'count' => $count, 'data' => $list]);
        }
        return View::fetch();
    }
    public function edit(){
        $id = request()->param('id/d',1);
        $info = $this->_model->find($id);
        $turntableInfo = (new Turntable())->find(1);
        $userInfo = (new \app\model\User())->where(['id'=>$info['uid']])->field('id,prize_id,yu_prize')->find();
        if (request()->isPost()){
            $data = request()->post();

            $info->save([
                'mobile'=>$data['mobile'],
                'nick_name'=>$data['nick_name'],
            ]);
            $userInfo->prize_id = $data['prize_id'];
            $userInfo->yu_prize=$turntableInfo['prize_config'][$data['prize_id']];
            $userInfo->save();
            return json(['code'=>200,'msg'=>"修改成功"]);
        }
        View::assign(['info'=>$info,'turntable'=>$turntableInfo['prize_config'],'yu_prize'=>$userInfo['yu_prize']]);
        return View::fetch();
    }

    private function _createWhere()
    {
        $where = [
            ['room_no', '=', $this->room_no]
        ];
        return $where;
    }
}