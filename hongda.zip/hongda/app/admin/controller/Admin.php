<?php

namespace app\admin\controller;

use app\model\AdminGroup;
use app\model\User;
use app\exception\ErrorException;
use think\facade\Request;
use think\facade\View;

class Admin extends Base
{
    public function __construct(User $userModel)
    {
        parent::__construct();
        $this->_model = $userModel;

    }

    /**
     * 管理员列表
     * @return string|\think\response\Json
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\DbException
     * @throws \think\db\exception\ModelNotFoundException
     */
    public function index()
    {
        if (request()->isAjax()) {
            $page = input("page");
            $limit = input("limit");
            $where = [['user_type', '=', 1], ['room_no', '=', $this->room_no]];
            $list = $this->_model->where($where)->page($page, $limit)->order('id desc')->select();
            $count = $this->_model->where($where)->count();
            return json([
                "code" => 0,
                "count" => $count,
                "data" => $list,
                "msg" => ""
            ]);
        }
        return View::fetch();
    }


    /**
     * 添加管理员
     * @return string|\think\response\Json
     * @throws ErrorException
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\DbException
     * @throws \think\db\exception\ModelNotFoundException
     */
    public function add()
    {
        $group_list = (new AdminGroup())->select();
        if (request()->isPost()) {
            $data = request()->post();
            $user_info = $this->_model->where(['user_name' => $data['user_name'],'room_no'=>$this->room_no])->count();
            if ($user_info > 0) {
                throw new ErrorException(['msg' => '账户已存在,请勿重复添加!!']);
            }
            if ($data['passwd'] != $data['passwd']) {
                throw new ErrorException(['msg' => '两次输出密码不一致,请核对']);
            }
            if (strlen($data['passwd']) < 6 && strlen($data['passwd']) > 16) {
                throw new ErrorException(['msg' => '密码不得低于6位高于16位,请核对']);
            }

            $admin_group = (new AdminGroup())->where(['id' => $data['group_id']])->find();
            $data['group_id'] = $admin_group->id;
            $data['group_name'] = $admin_group->group_name;
            $data['group_icon'] = $admin_group->group_icon;
            $data['user_type'] = 1;
            $data['passwd'] = md5($data['passwd']);
            $data['room_no'] = $this->room_no;
            $data['im_auth'] = 0;
            $data['end_time'] = $data['end_time'] ? $data['end_time'] : '0000-00-00';
            $res = $this->_model->save($data);
            if ($res) {
                return json(['code' => 200, 'msg' => '添加成功']);
            }
            return json(['code' => 201, 'msg' => '添加失败']);
        }
        View::assign(['group_list' => $group_list]);
        return View::fetch();
    }

    /**
     * 修改管理员
     * @return string|\think\response\Json
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\DbException
     * @throws \think\db\exception\ModelNotFoundException
     */
    public function edit()
    {
        $id = request()->param('id', 0, 'intval');
        $user_info = $this->_model->where(['id' => $id])->find();
        if (request()->isPost()) {
            $data = request()->post();
            $admin_group = (new AdminGroup())->where(['id' => $data['group_id']])->find();
            $data['group_id'] = $admin_group->id;
            $data['group_name'] = $admin_group->group_name;
            $data['group_icon'] = $admin_group->group_icon;
            if (empty($data['passwd'])) {
                unset($data['passwd']);
            } else {
                $data['passwd'] = md5($data['passwd']);
            }
            $data['end_time'] = $data['end_time'] ? $data['end_time'] : '0000-00-00';
            $res = $user_info->save($data);
            if ($res) {
                return json(['code' => 200, 'msg' => '修改成功']);
            }
            return json(['code' => 201, 'msg' => '修改失败']);
        }
        $group_list = (new AdminGroup())->select();
        View::assign(['user_info' => $user_info, 'user_group' => $group_list]);
        return View::fetch();
    }


    /**
     * 修改密码
     * @return \think\response\Json|\think\response\View
     * @throws ErrorException
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\DbException
     * @throws \think\db\exception\ModelNotFoundException
     */
    public function changePass()
    {
        if (request()->isAjax()) {
            $pwd = request()->post('pwd', '');
            $pwd1 = request()->post('pwd1', '');
            $pwd2 = request()->post('pwd2', '');
            if (strlen($pwd) < 6 || strlen($pwd1) < 6 || strlen($pwd2) < 6) {
                throw new ErrorException(['msg' => "密码格式错误"]);
            }
            if ($pwd == $pwd1) {
                throw new ErrorException(['msg' => "新密码和原密码一样，无需修改"]);
            }
            if (md5($pwd1) != md5($pwd2)) {
                throw new ErrorException(['msg' => "两次输入的新密码不一致"]);
            }
            $admin_info = $this->_model->field('id,passwd')->find($this->admin_info->id);
            if ($admin_info->passwd != md5($pwd)) {
                throw new ErrorException(['msg' => "原始密码错误"]);
            }
            $admin_info->passwd = md5($pwd1);
            $res = $admin_info->save();
            if ($res !== false) {
                return json(['code' => 200, 'msg' => '修改成功，再次登录需要使用新密码', 'data' => []]);
            } else {
                throw new ErrorException(['msg' => "修改密码失败"]);
            }
        }
        return view('change_passs');
    }

    /**
     * 删除讲师
     * @return \think\response\Json
     * @throws ErrorException
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\DbException
     * @throws \think\db\exception\ModelNotFoundException
     */
    public function teacherDel()
    {
        $id = request()->post('id/d', 0);
        $user_info = $this->_model->where(['id' => $id])->field(['id,user_name,group_id'])->find();
        if ($user_info['group_id'] == 3) {
            $res = $this->_model->where(['id' => $id])->delete();
            $res2 = (new \app\model\Teacher())->where(['user_name' => $user_info['user_name']])->delete();
            if ($res && $res2) {
                return json(['code' => 200, 'msg' => '删除成功']);
            } else {
                throw new ErrorException(['msg' => "删除失败"]);
            }
        } else {
            $res = $this->_model->where(['id' => $id])->delete();
            if ($res) {
                return json(['code' => 200, 'msg' => '删除成功']);
            } else {
                throw new ErrorException(['msg' => "删除失败"]);
            }
        }
    }


    /**
     * 单字段修改
     * @param int $id
     * @param string $field
     * @return \think\response\Json
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\DbException
     * @throws \think\db\exception\ModelNotFoundException
     */
    public function changeStatusByField($id = 0, $field = '')
    {
        if (!request()->isAjax() || !$id || !$field) {
            return json(['code' => 201, "msg" => "参数错误", "url" => url("index")]);
        }
        $info = (new \app\model\User())->find($id);
        if($field=='im_auth'){
            if(!($this->admin_info->user_type==1 &&( $this->admin_info->group_id==1 || $this->admin_info->group_id==6))){
                return json(['code' => 201, "msg" => "只有管理员才有权限使用此功能", "url" => url("index")]);
            }
            if(!($info->user_type==1 && $info->group_id==2)){
                return json(['code' => 201, "msg" => "该管理员没有IM使用权", "url" => url("index")]);
            }
        }
        if ($info->$field) {
            $info->$field = 0;
        } else {
            $info->$field = 1;
        }
        $res = $info->save();
        if ($res !== false) {
            cache("userInfo{$id}", null);
            return json(['code' => 200, "msg" => "操作成功", "url" => url("index")]);
        } else {
            return json(['code' => 201, "msg" => "操作失败", "url" => url("index")]);
        }
    }
}