<?php
namespace app\exception;

/**
 * token验证失败时抛出此异常
 */
class TokenException extends BaseException
{
    public $statusCode = 401;
    public $errorCode = 401;
    public $msg = 'Token已过期或无效Token';

}