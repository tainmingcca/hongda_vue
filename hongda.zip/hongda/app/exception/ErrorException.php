<?php
namespace app\exception;

/**
 * Class SuccessException
 * 通用参数类异常错误
 */
class ErrorException extends BaseException
{
    public $statusCode = 200;            //  httpCode
    public $errorCode = 201;
    public $msg = "操作失败";
}