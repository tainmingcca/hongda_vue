<?php

namespace app\work;

use app\model\ImMsg;
use think\facade\Db;
use GatewayWorker\Lib\Gateway;
use Workerman\Worker;
use Workerman\Lib\Timer;
use think\facade\Cache;
use think\worker\Application;

/**
 *
 * cd /www/wwwroot/xxxxxxx
 * php think work:gateway stop
 * php think work:gateway start
 * php think clearsql
 * Class Events
 * @package app\index\work
 */
class Events
{
    /**
     * onWorkerStart 事件回调
     * 当businessWorker进程启动时触发。每个进程生命周期内都只会触发一次
     *
     * @access public
     * @param \Workerman\Worker $businessWorker
     * @return void
     */
    public static function onWorkerStart(Worker $businessWorker)
    {
        $app = new Application;
        $app->initialize();
        Timer::add(10, function () {
            $cacheKey = env('database.database') . ":admin_online_data";
            if (Cache::store("redis")->has($cacheKey)) {
                $onlineNum = Cache::store("redis")->get($cacheKey);
            } else {
                $onlineNum = [date("H:i") => 0];
            }
            $data = [date('H:i') => Gateway::getAllUidCount()];
            $onlineNum = array_merge($onlineNum, $data);
            Cache::store("redis")->set($cacheKey, $onlineNum, new \DateTime(date('Y-m-d 23:59:59')));
        });
    }

    /**
     * onConnect 事件回调
     * 当客户端连接上gateway进程时(TCP三次握手完毕时)触发
     *
     * @access public
     * @param int $client_id
     * @return void
     */
    public static function onConnect($client_id)
    {
        // Gateway::sendToCurrentClient("Your client_id is $client_id");
    }

    /**
     * onWebSocketConnect 事件回调
     * 当客户端连接上gateway完成websocket握手时触发
     *
     * @param integer $client_id 断开连接的客户端client_id
     * @param mixed $data
     * @return void
     */
    public static function onWebSocketConnect($client_id, $data)
    {
        //if (!isset($data['server']['HTTP_ORIGIN']) || strpos($data['server']['HTTP_ORIGIN'], env('app.host')) === false) {
            // Gateway::closeClient($client_id);
        //}
    }


    /**
     * onMessage 事件回调
     * 当客户端发来数据(Gateway进程收到数据)后触发
     *
     * @access public
     * @param int $client_id
     * @param mixed $data
     * @return void
     */
    public static function onMessage($client_id, $data)
    {
        $message = json_decode($data, true);
        if (!isset($message['type'])) return Gateway::sendToCurrentClient(json_encode(['type' => 'error', "data" => ["msg" => "数据格式错误"]]));
        switch ($message['type']) {
            case 'login':
                try {
                    $token = isset($message['token']) && !empty($message['token']) ? $message['token'] : '';
                    if (empty($token)) return Gateway::closeClient($client_id);
                    $userinfo = Db::name('user')->where(['sess_id' => $token])->field("id,room_no,admin_uid,user_name,nick_name,user_sex,user_type,is_online,online_time,head_img,group_icon")->order('id asc')->find();
                    if (empty($userinfo)) return Gateway::closeClient($client_id);
                    // 将当前链接与uid绑定
                    Gateway::bindUid($client_id, $userinfo['id']);
                    Db::name('user')->where(['id' => $userinfo['id']])->update(['is_online' => 1]);
                    $userinfo['is_online'] = 1;
                    $_SESSION['userinfo'] = $userinfo;

                    if ($userinfo['user_type'] == 2) {
                        //发送欢迎语
                        $content = Db::name('imkjhf')->where(['uid' => $userinfo['admin_uid'], 'type' => 1])->value('content');
                        $content = htmlspecialchars_decode(trim($content));
                        if (!empty($content)) {
                            $imInfo = Db::name('user')->where(['id' => $userinfo['admin_uid']])->field("id,user_name,nick_name,user_sex,user_type,admin_uid,is_online,online_time,head_img")->find();
                            //查看五分钟内又没有发过快捷消息
                            $isSendKjMsg = (new ImMsg())->where(['room_no'=>env('room_no'),'send_uid'=>$imInfo['id'],'receive_uid'=>$userinfo['id'],'is_welcome_msg'=>1])
                                ->whereTime('create_time','-1 hours')
                                ->find();
                            if(empty($isSendKjMsg)){
                                //插入聊天记录
                                (new ImMsg())->save([
                                    'room_no' => env('room_no'),
                                    'send_uid' => $imInfo['id'],
                                    'send_nickname' => $imInfo['nick_name'],
                                    'receive_uid' => $userinfo['id'],
                                    'receive_nickname' => $userinfo['nick_name'],
                                    'content' => $content,
                                    'user_type' => $userinfo['user_type'],
                                    "is_read" => 0,
                                    "msg_type" => 1,
                                    'is_welcome_msg'=>1,
                                ]);
                            }


                            $send_headimg = $imInfo['head_img'] ? $imInfo['head_img'] : '/static/default/head_img.png';
                            if (strpos($send_headimg, 'http') === false) $send_headimg = env('app.host') . $send_headimg;
                            $data = [
                                'type' => 'imMsg',
                                'data' => [
                                    'send_uid' => $imInfo['id'],
                                    'send_nickname' => $imInfo['nick_name'],
                                    'send_headimg' => $send_headimg,
                                    'content' => $content,
                                    'msg_type' => 1,
                                    'create_time' => date("Y-m-d H:i:s"),
                                    'last_time' => time(),
                                ]];
                            Gateway::sendToUid($userinfo['id'], json_encode($data));
                        }
                        
                        
                        //通知IM客服该用户上线
                        $send_headimg = $userinfo['head_img'] ? $userinfo['head_img'] : '/static/default/head_img.png';
                        if (strpos($send_headimg, 'http') === false) $send_headimg = env('app.host') . $send_headimg;
                        $data = [
                            'type' => 'imMsg',
                            'data' => [
                                'send_uid' => $userinfo['id'],
                                'send_nickname' => $userinfo['nick_name'],
                                'send_headimg' => $send_headimg,
                                'content' => $userinfo['nick_name'] . "上线了",
                                'msg_type' => 1,
                                'create_time' => date("Y-m-d H:i:s"),
                                'last_time' => time(),
                            ]];
                        Gateway::sendToUid($userinfo['admin_uid'], json_encode($data));

                        
                        
                        //通知所有用户上线
                        $data = [
                            'type' => 'online_status',
                            'data' => [
                                'id' => $userinfo['id'],
                                'nick_name' => $userinfo['nick_name'],
                                'head_img' => $userinfo['head_img'],
                                'online_status' => 'online',
                                'content' => $userinfo['nick_name'] . "已上线",
                            ],
                        ];
                        Gateway::sendToAll(json_encode($data));
                    }
                } catch (\Exception $e) {
                    Gateway::sendToCurrentClient(json_encode(['type' => 'error', "data" => ["msg" => $e->getMessage()]]));
                }
                break;
            case 'ping':
                $userinfo = isset($_SESSION['userinfo']) ? $_SESSION['userinfo'] : [];
                if (!empty($userinfo)) {
                    $userinfo['online_time'] += 0.5;
                    Db::name('user')->where(['id' => $userinfo['id']])->update(['online_time' => $userinfo['online_time'], 'is_online' => 1]);
                    $_SESSION['userinfo'] = $userinfo;
                }
                Gateway::sendToCurrentClient(json_encode(['type' => 'pong']));
                break;
            default:
                Gateway::closeClient($client_id);
        }
    }

    /**
     * onClose 事件回调 当用户断开连接时触发的方法
     * @param integer $client_id 断开连接的客户端client_id
     * @return void
     */
    public static function onClose($client_id)
    {
        $userinfo = isset($_SESSION['userinfo']) ? $_SESSION['userinfo'] : [];
        //file_put_contents('socket.log',var_export($_SESSION,true));
        if (!empty($userinfo)) {
            Db::name('user')->where(['id' => $userinfo['id']])->update(['is_online' => 0]);
            //通知所有用户下线
            $data = [
                'type' => 'online_status',
                'data' => [
                    'id' => $userinfo['id'],
                    'nick_name' => $userinfo['nick_name'],
                    'head_img' => $userinfo['head_img'],
                    'online_status' => 'offline',
                    'content' => $userinfo['nick_name'] . "已下线",
                ],
            ];
            Gateway::sendToAll(json_encode($data));
        }
    }

    /**
     * onWorkerStop 事件回调
     * 当businessWorker进程退出时触发。每个进程生命周期内都只会触发一次。
     *
     * @param \Workerman\Worker $businessWorker
     * @return void
     */
    public static function onWorkerStop(Worker $businessWorker)
    {
        echo "WorkerStop\n";
    }
}