$('.hovertree').fireworks({
    sound: false, // sound effect
    opacity: 0.3, 
    width: '100%', 
    height: '100%' 
  });