var chatcontainer;
$(document).ready(function () {
    //初始化互动部分
    getHdMsg();
    //Hide contextmenu:
    $(document).click(function () {
        $("#contextmenu").hide();
    });
    $("#contextmenu>li").click(function () {
        var name = $(this).attr("name");
        var msgId = $(this).attr("msgId");
        var nickname = $(this).attr("nickname");
        if (name == 'aite') {
            var txt = "<font style='color:red;font-weight: bold;'>对【" + nickname + "】说：</font>";
            $("#sendMsgInput").prepend(txt);
        } else {
            $.post('/index/contextMenu', {name: name, id: msgId}, function (res) {
                if (res.code == 200) {
                    if (name == 'del') {
                        $("#chat_" + msgId).remove();
                    }
                    if (name == 'pass') {
                        $("#chat_" + msgId).remove();
                    }
                }
            })
        }
    })

    chatcontainer = new ChatContainer();
    chatcontainer.create(".topiccontent", "#topicbox", 50);
    chatcontainer.scrollToLast();


    //显示表情
    $('#bt_face').qqFace({
        id: 'facebox',
        assign: 'sendMsgInput',
        bottom: -167,
        nums: 15,
        path: '/static/index/face/arclist/'	//表情存放的路径
    });
    //点击彩条
    $('#bt_caitiao').on('click', function () {
        $('#caitiao').show();
    });

    //清屏
    $('#bt_qingping').on('click', function () {
        chatcontainer.clear();
    });
    //滚动
    $('#bt_gundong').on('click', function () {
        chatcontainer.dynamicscroll = !chatcontainer.dynamicscroll;
        var isSelect = $(this).attr('select');
        $(this).attr('select', isSelect == 'true' ? 'false' : 'true');
    });
    //绑定粘贴事件 Ctrl+V
    bindPaste();
    //监听回车键盘
    $('#sendMsgInput').keypress(function (e) {
        if (e.which == 13 || e.which == 10) {
            $('#caitiao').hide();
            $("#facebox").remove();
            sendMsg()
        }
    });
    $("#sendMsgInput").click(function () {
        $("#facebox").remove();
    })
    $(".sub_btn").click(function () {
        $("#facebox").remove();
    })
    $(document).bind('mouseup', function (e) {
        $('#caitiao').hide();
    });


    //IM点击
    $(".imkf").click(function () {
        if ($(this).data("open") == 0) {
            $(".layui-layer-content>span").trigger("click");
            //OpenIM();
            $(this).data('open', 1).hide(500);//已经打开私聊
            $(".layui-layer-min").click(function () {
                $(".imkf").data('open', 0).show();
            })
            $(".layui-layer-close1").click(function () {
                $(".imkf").data('open', 0).show();
            })
        }
    });


})


//发送消息
function sendMsg() {
    var sendContent = $("#sendMsgInput").html();
    if ((sendContent.length == 0)) {
        $("#sendMsgInput").html('');
        alert('内容不能为空');
        return false;
    }
    var isDanmu = 0;
    var robotId = 0;
    var user_type = $("#user_type").val();
    if (user_type == 1) {
        robotId = $("#robot").val();
        isDanmu = $("input[name='danmu']:checked").val() == "on" ? 1 : 0;
    }
    $.post("/index/sendChat_msg", {content: sendContent, robotId: robotId, isDanmu: isDanmu}, function (res) {
        if (res.code == 200) {
            chatcontainer.scrollToLast();
            $("#sendMsgInput").html("");
        } else {
            layui.layer.msg(res.msg, {icon: 5});
        }
    }, "json");
}

//发送彩条
function sendCaitiao(obj) {
    var img = $(obj).find("img").clone();
    $("#sendMsgInput").html(img);
    sendMsg();
}


//打开私聊
function OpenIM() {
    $(".imkf i").removeClass("xxts layui-anim layui-anim-fadein layui-anim-loop");
    layer.open({
        type: 2,
        title: ['我的私聊'],
        shade: false,
        maxmin: false,
        resize: false,//是否允许拉伸
        shadeClose: false, //开启点击遮罩关闭层
        area: ['750px', '580px'],
        zIndex: 99999999,
        content: ['/index/im/user_center.html?ver=1.1', 'no'], //iframe的url  'no'是禁用滚动条
        end: function () {
            $(".imkf", $(parent.document)).data('open', 0).show(500);
        }
    });
}

//加载互动消息
function getHdMsg() {
    $.getJSON('/index/getHd_msg?t=' + new Date().getTime(), {}, function (res) {
        appendHdMsg(res.data.list);
        $("#topicbox .talk_content img").click(function(){
            var src = this.src;
            layui.layer.open({
                type:1,
                title:false,
                area:"auto",
                shadeClose:true,
                content:'<img src="'+src+'" style="width: 100%;">'
            })
        })
    });
}

function delHdMsg(id) {
    $("#chat_" + id).remove();
}

function appendHdMsg(list) {
    var html = "";
    $(list).each(function (index, item) {
        var desc = item.nick_name;
        if (user_type == 1) {
            (item.admin_nickname != '') && (desc = "<span style='color:red;font-weight: 700;'>【" + item.admin_nickname + '】</span>' + item.nick_name);
            if (item.admin_nickname == "") {
                desc += '<font style="color:red;font-weight:bold;">(' + item.ip + ')</font>';
            } else {
                desc += '<font>(' + item.ip + ')</font>';
            }
            //desc += '(' + item.ip + ')';
            (item.status == '0') && (desc += '<font style="color:red;font-weight:bold;" class="talk_status_' + item.id + '">(待审核)</font>');
        }

        html += '<div id="chat_' + item.id + '"' +
            ' data-id="' + item.id + '"' +
            ' data-nickname="' + item.nick_name + '"' +
            ' data-status="' + item.status + '"' +
            ' class="talk">' +
            '    <div class="talk_time">' + item.send_time + '</div>' +
            '    <img class="roleimg" src="' + item.group_icon + '">' +
            '    <span class="talk_name">' + desc + '</span>';
        if (item.is_red) {
            html += '    <div class="talk_content" style="color:red;font-weight: bold;">' + item.content + '</div>\n';
        } else {
            html += '    <div class="talk_content">' + item.content + '</div>\n';
        }
        html += '    <div class="clearfix"></div></div>';
    })
    $("#topicbox").append(html);
    is_audit === "1" && addListenHdMsg();
    chatcontainer.scrollToLast();
}


function appendHdMsg2(msg) {
    var html = '<div id="chat_' + msg.id + '" class="talk2">\n' +
        '    <div class="talk_time">' + msg.create_time + '</div>\n' +
        '    <span class="talk_name" style="background: red;">系统消息</span>\n' +
        '    <div class="talk_content">' + msg.content + '</div>\n' +
        '    <div class="clearfix"></div>\n' +
        '</div>';
    $("#topicbox").append(html);
    chatcontainer.scrollToLast();
}

//监听右键
function addListenHdMsg() {
    $("#topicbox>.talk").contextmenu(function (e) {
        //Get window size:
        var winWidth = $(document).width();
        var winHeight = $(document).height();
        //Get pointer position:
        var posX = e.pageX;
        var posY = e.pageY;
        //Get contextmenu size:
        var menuWidth = $(".contextmenu").width();
        var menuHeight = $(".contextmenu").height();
        //Security margin:
        var secMargin = 10;
        //Prevent page overflow:
        if (posX + menuWidth + secMargin >= winWidth
            && posY + menuHeight + secMargin >= winHeight) {
            //Case 1: right-bottom overflow:
            posLeft = posX - menuWidth - secMargin + "px";
            posTop = posY - menuHeight - secMargin + "px";
        } else if (posX + menuWidth + secMargin >= winWidth) {
            //Case 2: right overflow:
            posLeft = posX - menuWidth - secMargin + "px";
            posTop = posY + secMargin + "px";
        } else if (posY + menuHeight + secMargin >= winHeight) {
            //Case 3: bottom overflow:
            posLeft = posX + secMargin + "px";
            posTop = posY - menuHeight - secMargin + "px";
        } else {
            //Case 4: default values:
            posLeft = posX + secMargin + "px";
            posTop = posY + secMargin + "px";
        }
        //Display contextmenu:
        $("#contextmenu").css({
            "left": posLeft,
            "top": posTop
        }).show();
        if ($(this).data('status')) {
            $("#contextmenu").find("li[name='pass']").hide();
        } else {
            $("#contextmenu").find("li[name='pass']").show();
        }
        $("#contextmenu>li").attr('msgId', $(this).data('id')).attr('nickname', $(this).data('nickname'));
        //Prevent browser default contextmenu.
        return false;
    });

    $(".talk_content").find('img').click(function () {
        var src = $(this).attr('src');
        layui.layer.open({
            type: 1,
            title: false,
            area: ['auto'],
            content: '<img src="' + src + '">',
        })
    })
}


//绑定粘贴事件
function bindPaste() {
    //定义变量存储获取的图片内容
    var blob;
    //获取body对象
    var body = document.getElementById("sendMsgInput");
    //定义body标签绑定的粘贴事件处理函数
    var fun = function (e) {
        //获取clipboardData对象
        var data = e.clipboardData || window.clipboardData;
        //获取图片内容
        blob = data.items[0].getAsFile();
        //判断是不是图片，最好通过文件类型判断
        var isImg = (blob && 1) || -1;
        var reader = new FileReader();
        if (isImg >= 0) {
            //将文件读取为 DataURL
            reader.readAsDataURL(blob);

            //文件读取完成时触发
            reader.onload = function (event) {
                //获取base64流
                var base64_str = event.target.result;
                $("#sendMsgInput").html("");
            }
            $.post("/index/get_oss_policy/chat", function (res) {
                if (res.code == 200) {
                    var filedata = new FormData();
                    var key = res.data.dir + new Date().getTime() + '-' + (Math.random() + "").substring(2, 7) + '-' + blob.name;
                    filedata.append('key', key);
                    filedata.append('policy', res.data.policy);
                    filedata.append('OSSAccessKeyId', res.data.accessid);
                    filedata.append('signature', res.data.signature);
                    filedata.append('success_action_status', 200);
                    filedata.append('file', blob);
                    console.log(filedata.get('file'));
                    $.ajax({
                        url: res.data.host,
                        processData: false,
                        cache: false,
                        contentType: false,
                        type: 'POST',
                        data: filedata,
                        success: function () {
                            var img = new Image();
                            img.src = res.data.host + '/' + key;
                            $("#sendMsgInput").append(img);
                        },
                        error: function (e) {
                            console.log(e)
                        }
                    })

                } else {
                    layui.layer.msg('上传失败', {icon: 5});
                }
            }, "json")
        }
    }
    //通过body标签绑定粘贴事件，注意有些标签绑定粘贴事件可能出错
    body.removeEventListener('paste', fun);
    body.addEventListener('paste', fun);
}

function ChatContainer() {
    this.maxNum;
    this.container;
    this.scroolwrap;
    this.tabType; //public member private
    this.dynamicscroll;
    this.create = function (scroolwrap, containerid, max) {
        this.maxNum = max;
        this.tabType = 'public';
        this.container = $(containerid);
        this.scroolwrap = $(scroolwrap);
        this.dynamicscroll = true;

        this.scroolwrap.mCustomScrollbar({scrollButtons: {enable: true}});
    };

    this.push = function (msgItem) {
        this.container.append(msgItem);
        this.scrollToLast();
    }
    //滚动到底部
    this.scrollToLast = function () {
        this.scroolwrap.mCustomScrollbar("update");
        if (this.dynamicscroll) {
            this.scroolwrap.mCustomScrollbar("scrollTo", "bottom");
        }
    }

    //清屏
    this.clear = function () {
        this.container.empty();
    }
}
