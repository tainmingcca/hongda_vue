var WidthLevel = {'S': 480, 'M': 598, 'P': 880, 'L': 1366, 'B': 1600};
var scrollconf = {scrollButtons: {enable: true}};
var isPhone;

function danmu(text){
    var danmu = $('<marquee id="danmu" class="Barrage" direction="left" scrollamount="10" loop="2">'+text+'</marquee>');
    $("body").append(danmu);
}


function resize() {
    var windowHeight = $(window).height();
    var windowWidth = $(window).width();
    var headerHeight = $('header').height();
    var footerHeight = $('footer').height();
    var mmargin = mMargin();

    var $topic = $('#topic');
    var $main = $('#main');
    $main.height(windowHeight - headerHeight - footerHeight - mmargin * 2 - 6); //设置主体高度

    var noticeHeight = $('.notice').height();//房间通知跑马灯高度
    var chat_bottom = $('#chat_bottom').height();  //聊天输入块高度
    if (windowWidth > 1000) {
        $main.height(windowHeight - headerHeight - footerHeight - mmargin * 2);
        $(".bczm_div").show();
        $topic.height($main.height()); //聊天模块高度
        $('.topiccontent').height($topic.height() - noticeHeight - chat_bottom - 10); //聊天显示块高度
        $('#list_u').height($main.height() - $(".apply_list").height() - $("#hangqing").height() - 41); //用户列表高度
    } else if (windowWidth < 1000 && windowWidth > 880) {
        $(".bczm_div").hide();
        $topic.height($main.height()); //聊天模块高度
    } else if (windowWidth > WidthLevel.P) {
        $main.height(windowHeight);
        $topic.height($main.height()); //聊天模块高度
        $('.topiccontent').height($topic.height() - noticeHeight - chat_bottom - 10);//.css({'backgroundColor':'red'}); //聊天显示块高度
    } else {
        $main.height(windowHeight);
        $topic.height(windowHeight - $('#me_use').height() - footerHeight); //聊天模块高度
        $('.topiccontent').height($topic.height() - $(".m_header").height() - chat_bottom); //聊天显示块高度
    }
}

function mMargin() {//大屏间距10  小屏间距5
    var windowWidth = $(window).width();
    return windowWidth > WidthLevel.P ? 10 : 5;
}

/**
 * 时间对象的格式化;
 */
Date.prototype.format = function (format) {
    /*
     * eg:format="YYYY-MM-dd hh:mm:ss";
     */
    var o = {
        "M+": this.getMonth() + 1, // month
        "d+": this.getDate(), // day
        "h+": this.getHours(), // hour
        "m+": this.getMinutes(), // minute
        "s+": this.getSeconds(), // second
        "q+": Math.floor((this.getMonth() + 3) / 3), // quarter
        "S": this.getMilliseconds()
        // millisecond
    }

    if (/(y+)/.test(format)) {
        format = format.replace(RegExp.$1, (this.getFullYear() + "")
            .substr(4 - RegExp.$1.length));
    }
    for (var k in o) {
        if (new RegExp("(" + k + ")").test(format)) {
            format = format.replace(RegExp.$1, RegExp.$1.length == 1 ? o[k]
                : ("00" + o[k]).substr(("" + o[k]).length));
        }
    }
    return format;
}



//收藏页面
function AddFavorite(sURL, sTitle) {
    try {
        window.external.addFavorite(sURL, sTitle);
    } catch (e) {
        try {
            window.sidebar.addPanel(sTitle, sURL, "");
        } catch (e) {
            alert("加入收藏失败，请使用Ctrl+D进行添加");
        }
    }
}


function lookIP(e) {
    var ip = $(e).attr('ip');
    var uid = $(e).attr('uid');

    if (ip == 'undefined') {
        ip = $('#u_' + uid).attr('ip');
        if (!ip) {
            $.post(ip_url, {uid: uid}, function (data) {
                if (data.status) {
                    ip = data.ip;
                    window.open('http://www.ip.cn/index.php?ip=' + ip, 'newwindow', 'height=500,width=400,top=0,left=0,toolbar=no,menubar=no,scrollbars=no, resizable=no,location=no, status=no');
                } else {
                    alertBox('获取不到IP', 'error');
                }
            }, 'json');
        } else {
            window.open('http://www.ip.cn/index.php?ip=' + ip, 'newwindow', 'height=500,width=400,top=0,left=0,toolbar=no,menubar=no,scrollbars=no, resizable=no,location=no, status=no');
        }
    } else {
        window.open('http://www.ip.cn/index.php?ip=' + ip, 'newwindow', 'height=500,width=400,top=0,left=0,toolbar=no,menubar=no,scrollbars=no, resizable=no,location=no, status=no');
    }
    // alertBox(ip,'success');

}

function getRandom(n) {
    return Math.floor(Math.random() * n + 1);
}


function showLoginForm() {
    layui.layer.open({
        type: 1,
        title: "用户登录",
        area: ['350px', '320px'],
        content: $("#loginTpl").html(),
        success: function (layero, index) {
            layero.find("input[type='submit']").click(function () {
                var action = $(this).data("url");
                formAct(layero, action, true);
            })
        }
    })
}

function showRegForm() {
    //openQQKf();return;
    layui.layer.open({
        type: 1,
        title: "用户注册",
        area: ['350px', '410px'],
        content: $("#regTpl").html(),
        success: function (layero, index) {
            layero.find("input[type='submit']").click(function () {
                var action = $(this).data("url");
                formAct(layero, action, true);
            })
        }
    })
}

function formAct(layero, action, isReload) {
    var data = {};
    let inputs = layero.find(".val");
    inputs.each(function (index, item) {
        data[$(item).attr("name")] = $(item).val();
    })
    var loading = layui.layer.open({type:3});
    $.post(action, data, function (res) {
        layui.layer.close(loading);
        if(res.code==200){
            layui.layer.msg(res.msg);
            if (isReload === true) {
                window.setTimeout(function () {
                    window.location.reload();
                }, 1500);
            }
        }else{
            if(res.msg!=''){
                layui.layer.alert(res.msg);
            }
        }
    }, "json")
}


/**
 * 显示课程表
 */
function showKcb(img) {
    layui.layer.open({
        type: 1,
        title: false,
        area: ['803px', '623px'],
        content: "<img src='" + img + "' style='width:100%;'>",
    })
}

/**
 * 显示产品介绍
 */
function showProduct(url) {
    layui.layer.open({
        type: 2,
        title: false,
        area: ['1024px', '552px'],
        content: url,
    })
}

/**
 * 显示服务体系
 */
function showFwtx(img) {
    layui.layer.open({
        type: 1,
        title: false,
        area: ['707px', '650px'],
        content: "<img src='" + img + "' style='width:100%;'>",
    })
}

/**
 * 显示产品介绍
 */
function showCjrl() {
    layui.layer.open({
        type: 2,
        title: false,
        area: ['1024px', '600px'],
        content: "https://rili-d.jin10.com/open.php?new=0.012113788980271378",
    })
}

/**
 * 显示名师风采
 */
function showMsfc(url) {
    layui.layer.open({
        type: 2,
        title: false,
        area: ['800px', '450px'],
        content: url,
    })
}

/**
 * 显示手机直播二维码
 */
function showMobilQrcode() {
    layui.layer.open({
        type: 2,
        title: false,
        area: ['340px', '340px'],
        content: "/index/getQrcode",
    })
}


/**
 * 大转盘抽奖
 */
function openTurntable(){
    if( (user_type==1) || (user_type==2&& group_id>1)){
        layui.layer.open({
            type: 2,
            title: false,
            maxmin: false,
            shadeClose: true, //开启点击遮罩关闭层
            area: ['960px', '530px'],
            skin: 'layui-layer-nobg', //没有背景色
            content: ["/index/turntable","no"]
        });
    }else{
        openQQKf();
    }
}

/**
 * 获取QQ客服
 * @constructor
 */
function openQQKf() {
    $.post('/index/getQQ', {}, function (res) {
        if (res.code != 200) {
            layui.layer.msg('很抱歉，当前暂无客服在线', {icon: 5});
            return;
        }
        if (isPhone) {
            layui.layer.open({
                type: 2,
                title: false,
                maxmin: false,
                shadeClose: true, //开启点击遮罩关闭层
                area: ['600px', '400px'],
                skin: 'layui-layer-nobg', //没有背景色
                time: 5000,
                // content: ["http://wpa.qq.com/msgrd?v=3&uin=" + res.data.qq_account + "&site=qq&menu=yes"],
                content: ["mqqwpa://im/chat?chat_type=wpa&uin=" + res.data.qq_account + "&version=1&src_type=web&web_src=oicqzone.com"]
            });
        } else {
            window.location.href = "tencent://message/?uin=" + res.data.qq_account + "&Site=www.qq.com.cn&Menu=yes";
            // window.open("http://wpa.qq.com/msgrd?v=3&uin=" + res.data.qq_account + "&site=qq&menu=yes");
        }
    }, "json")
}


/**
 * 载入视频
 */
function loadVideo() {
    $.post("/index/getVideo", {}, function (res) {
        if(res.data.time=='timeout'){
            closeLiveTimeout();
        }else{
            Djs(res.data.time);
            $('#shiping').html(res.data.url);
        }
        res.data.video_bg && $('#shiping').append('<img src="'+res.data.video_bg+'" style="position:absolute;top:0;left:0;  width:100%;height: 100%;" onclick="this.style.display=\'none\';">');
    }, "json")
}

/**
 * 游客观看视频倒计时
 */
function Djs(intDiff) {
    var timer = window.setInterval(function () {
        var day = 0,
            hour = 0,
            minute = 0,
            second = 0;//时间默认值
        if (intDiff > 0) {
            day = Math.floor(intDiff / (60 * 60 * 24));
            hour = Math.floor(intDiff / (60 * 60)) - (day * 24);
            minute = Math.floor(intDiff / 60) - (day * 24 * 60) - (hour * 60);
            second = Math.floor(intDiff) - (day * 24 * 60 * 60) - (hour * 60 * 60) - (minute * 60);
        }
        if (minute <= 9) minute = '0' + minute;
        if (second <= 9) second = '0' + second;
        $("#look_time").html("剩余观看时长：" + day + " 天 " + hour + " 时 " + minute + " 分 " + second + " 秒");
        intDiff--;
        if (intDiff <= 0) {
            clearInterval(timer);
            closeLiveTimeout();
        }
    }, 1000);
}

/**
 * 游客观看时间到期
 */
function closeLiveTimeout() {
    $('#shiping').html("<div id='shiping-shelte'><p style='font-size: 22px;font-weight: 700;'>您的试看时间已满，请您<span style='color:red;margin:0 5px;display: inline-block;cursor: pointer;' onclick='openQQKf()'>注册</span>后顺畅观看</p></div>");
    $("#look_time").html("");
}


//弹出提示登录
function dialogShowTipLogin() {
    layui.layer.alert("您需要登录后才能参与抽奖，您现在登录吗", {
        time: 20000, //20s后自动关闭
        btn: ['登录', '取消']
    }, function (index) {
        showLoginForm();
        layui.layer.close(index);
    });
}

//打开用户中心
function userCenter() {
    var centerLeft = $(window).width() - 500;
    layui.layer.open({
        type: 2,
        title: "用户中心",
        area: ['500px', '350px'],
        offset: ['70px', centerLeft + 'px'],
        content: ['/index/userCenter', 'no']
    })
}

//初始化加载在线用户
function getOnlineUser() {
    $.getJSON('/index/getOnlineUser' + '?t=' + new Date().getTime(),{},function(res){
        appendUserOnlineList(res.data);
    })
}

function appendUserOnlineList(onlineList){
    var html = '';
    $("#usertotal").html(onlineList.totalUser);
    $(onlineList.list).each(function(index,data){
        html += '<li class="online_'+data.id+'"><span><img class="roleimg" src="'+data.head_img+'" onerror="this.src=\'/static/default/head_img.png\'"></span><a href="javascript:void(0)" class="f_left">'+data.nick_name+'</a></li>';
    })
    $("#all").append(html);
}

function appendUserOnline(data){
    var userTotal =  parseInt($("#usertotal").html());
    var html = '<li class="online_'+data.id+'"><span><img class="roleimg" src="'+data.head_img+'" onerror="this.src=\'/static/default/head_img.png\'"></span><a href="javascript:void(0)" class="f_left">'+data.nick_name+'</a></li>';
    if(data.status=='online'){
        $("#all").prepend(html);
        userTotal=userTotal+1;
        welcomeUser(data.nick_name);
    }else{
        $("#all").find(".online_"+data.id).remove();
        userTotal=userTotal-1;
    }
    $("#usertotal").html(userTotal)
}

function welcomeUser(nick_name) {
    if(isTelphone()) return false;
    var div = $('<div class="welcome">'+nick_name+'&nbsp;进入直播间</div>');
    $("#welcome").prepend(div);
    div.animate({left: '10px'}, 1000,function(){setTimeout(function () {div.animate({left: '-450px'}, 1000,function(){div.remove()});}, 1000)});
}
//根据浏览器判断客户端
function isTelphone() {
    if (/AppleWebKit.*Mobile/i.test(navigator.userAgent) || (/MIDP|SymbianOS|NOKIA|SAMSUNG|LG|NEC|TCL|Alcatel|BIRD|DBTEL|Dopod|PHILIPS|HAIER|LENOVO|MOT-|Nokia|SonyEricsson|SIE-|Amoi|ZTE/.test(navigator.userAgent))) {
        if (window.location.href.indexOf("?mobile") < 0) {
            try {
                if (/Android|Windows Phone|webOS|iPhone|iPod|BlackBerry|iPad/i.test(navigator.userAgent)) {
                    return true;
                }
            } catch (e) {
            }
        }
    }
    return false;
}

//数组乱序
function fnLuanXu(arr) {
    if (arr == null) return false;
    var num = arr.length;
    for (var i = 0; i < num; i++) {
        var iRand = parseInt(num * Math.random());
        var temp = arr[i];
        arr[i] = arr[iRand];
        arr[iRand] = temp;
    }
    return arr;
}







