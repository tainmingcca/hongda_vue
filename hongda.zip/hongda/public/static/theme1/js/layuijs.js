layui.extend({
    aliossUploader: '{/}/static/plus/aliyunoss/aliossUploader' // {/}的意思即代表采用自有路径，即不跟随 base 路径
})
layui.use(["layer", "carousel", "jquery", "aliossUploader"], function () {
    var layer = layui.layer;
    var carousel = layui.carousel;
    var $ = layui.jquery;
    var aliossUploader = layui.aliossUploader;

    if (!isPhone) {
        if (isYk) {
            dialogShowTipLogin();
        }
        //打开首页弹窗
        if (indexImg != '') {
            //var html = "<a href='" + indexUrl + "' target='_blank'><img src='" + indexImg + "'></a>";
            var html = "<a href='javascript:openQQKf();'><img src='" + indexImg + "'></a>";
            if (indexUrl == '') {
                html = "<img src='" + indexImg + "'>";
            }
            layer.open({
                type: 1,
                title: false,
                area: ['740px', '600px'],
                content: html,
            })
        }
    }

    $("#huanfu").click(function () {
        layer.open({
            title: false,
            type: 1,
            content: $("#huanTpl").html(),
            success: function (layero, index) {
                layero.find(".item").click(function () {
                    var index = $(this).data("index");
                    var src = "/static/index/bg/ys_" + index + "_1.jpg";
                    $.post("/index/setBg", {src: src}, function (res) {
                        if (res.code == 200) {
                            $("body").css({
                                "background": "url('" + src + "') 0 0 no-repeat",
                                "backgroundSize": "100% 100vh"
                            })
                        }
                        layer.close(index);
                    }, "json")
                })
            }
        })
    })


    //建造实例
    carousel.render({
        elem: '#test1',
        width: '100%', //设置容器宽度
        height: "170px",
    });

    //互动上传图片
    aliossUploader.render({
        elm: '#bt_myimage',
        policyUrl: '/index/get_oss_policy/chat',
        allUploaded: function (res) {
            console.log(res);
            var img = new Image();
            img.src=res[0].ossUrl;
            console.log(img);
            $("#sendMsgInput").append(img);
        },
        policyFailed: function (res) {
            layer.msg("上传失败");
        }
    });

});