//打开新页面
var openWin = function(title,url){
	layui.layer.open({
		type:2,
		title:title,
		fixed: true, //不固定
		maxmin: true,
		area: ["80%","95%"],
		content:url
	});
}

//编辑
var openEditWin = function(url){
	var pk='id';
	var checked_data = layui.table.checkStatus('table');
	if(checked_data.data.length==0){layui.layer.msg("请选择要编辑的信息");return false;}
	if(checked_data.data.length>1){layui.layer.msg("一次只能编辑一条信息");return false;}

	var id = checked_data.data[0][pk];
	var jumpurl = url+"?"+pk+"="+id;
	//alert(jumpurl);return false;
	openWin("编辑", jumpurl);
}


//删除
var delItem = function(url){
	var pk='id';
	layui.layer.confirm("确定删除吗？",function(index){
		var checked_data = layui.table.checkStatus('table');
		if(checked_data.data.length==0){layer.msg("请选择要删除的信息");return false;}
		var ids = new Array();
		for(var x in checked_data.data){
			ids.push(checked_data.data[x][pk]);
		}
		ids = ids.join(",");
		layui.jquery.post(url,{ids:ids},function(res){
			if(res.msg != ""){
				layui.layer.msg(res.msg, {time:1000}, function(){
					if(res.url != ""){
						window.location.href=res.url;
					}else{
						window.history.back();
					}
				});
			}
		});
	});
}




var autoRefresh= function(time){
	if(time<=0){return false;}
	setInterval(function(){
		window.location.reload();
	},time*1000);
}




var uploadFunc = function (idStr,dir,done) {
    // uploadByOss(idStr,dir,done);
    uploadByLocal(idStr,dir,done);
}

var uploadByOss = function (idStr,dir,done) {
    layui.aliossUploader.render({
        elm: '#' + idStr,
        policyUrl: "/admin/index/getOssPolicy/dir/"+dir,
        allUploaded: function (res) {
            if (res[0].ossUrl == '') return layui.layer.msg('上传失败');
            typeof done  == 'function' && done(res[0].ossUrl);
        },
        policyFailed: function (res) {
            layui.layer.msg("上传失败");
        }
    });
}
var uploadByLocal = function (idStr,dir,done) {
    layui.upload.render({
        elem: '#' + idStr,
        url: "/admin/index/upFile/dir/"+dir,
        done: function (res) {
            if (res.code != 200) return layui.layer.msg(res.msg);
            typeof done  == 'function' && done(res.data.src);
        },
        error: function (res) {
            layui.layer.msg("上传失败");
        }
    });
}